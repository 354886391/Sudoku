/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2024-09-19 14:20:13
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-10-25 09:40:48
 * @FilePath: \prizeDrop\assets\prizeDrop\src\ui\HPD_DropTool.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

// import HPD_BallCom from "../prizeDrop/src/ui/com/HPD_BallCom";
// import HPD_MainPanel from "../prizeDrop/src/ui/HPD_MainPanel";
import * as XLSX from 'xlsx';
const { ccclass, property } = cc._decorator;

@ccclass
export default class ExcelTool extends gea.abstracts.ui.OverModalBase {

    /**bundle 名称 */
    static get bundle(): string {
        return 'resources'
    }

    // LIFE-CYCLE CALLBACKS:

    onLoad() {

    }

    start() {

    }

    callbackAfterShow() {
        this.initFileInput()
    }

    //配置项
    /** 数据列表存储key */
    storageKey: string = "prizeDropPathExcexl"
    /** 数据表头存储key */
    storageKeepKey: string = "prizeDropPathExcexlKeep"
    /** 导出表格名字 */
    excelFileName: string = "表名"
    /** 导出表格 sheet 名字 */
    excelSheetName: string = "sheet"


    //=========================================================================
    saveToLocal() {
        gea.localStorage.setItem(this.storageKey, this._pathExlList)
        gea.localStorage.setItem(this.storageKeepKey, this.pathExlKeep)
    }
    getFromLocal() {
        return gea.localStorage.getItem(this.storageKey)
    }

    //配置====================================================================
    fileInput: any
    _pathExlList: any[] = []
    // /** 初始化，第一次无表格时创建一个默认的 */
    // createNewInfo() {
    //     this._pathExlList = [{ id: "0", key: "1-1-1-1", start: "1", mid1: "1", mid2: "1", result: "1", total_time: "6000", group_id: 0, datas: '[]' }]
    //     this.saveToLocal()
    // }

    initFileInput() {
        const fileInput = document.getElementById('fileInput');
        if (!fileInput) {
            return
        }
        fileInput.addEventListener('change', this.handleFile.bind(this));
        this.fileInput = fileInput
        this._pathExlList = this.getFromLocal()
        this.pathExlKeep = gea.localStorage.getItem(this.storageKeepKey)

    }

    pathExlKeep: any[] = []
    /** 导入 */
    handleFile(e: any) {
        const file = e.target.files[0];
        const reader = new FileReader();
        let self = this
        reader.onload = function (e) {
            const data = new Uint8Array(reader.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const json = XLSX.utils.sheet_to_json(worksheet);

            self.pathExlKeep = [json[0], json[1], json[2], json[json.length - 1]]
            // gea.log(JSON.stringify(json))
            self._pathExlList = json.slice(3, json.length - 1)
            self.saveToLocal()
            // gea.instance.dispatch(FishToolEvent.ON_LOAD_EXCEL_COMPLETE)
        };
        reader.readAsArrayBuffer(file);
    }

    //导出============================================================
    exportToExcel() {
        let fileName = this.excelFileName
        //排序
        this._pathExlList.sort((a, b) => {
            if (a.key == b.key) {
                return b.total_time - a.total_time
            }
            if (a.start == b.start && a.result == b.result) {
                if (a.mid1 != b.mid1) {
                    return a.mid1 - b.mid1
                }
                if (a.mid2 != b.mid2) {
                    return a.mid2 - b.mid2
                }
            }
            else if (a.start == b.start) {
                return a.result - b.result
            }

            return a.start - b.start
        })

        for (let i = 0; i < this._pathExlList.length; i++) {
            this._pathExlList[i].id = (i + 1)
        }

        let data: any[] = JSON.parse(JSON.stringify(this._pathExlList))
        // 插入表头
        data.unshift(this.pathExlKeep[2])
        data.unshift(this.pathExlKeep[1])
        data.unshift(this.pathExlKeep[0])
        data.push(this.pathExlKeep[3])

        // 将JSON数据转换为工作表
        const worksheet = XLSX.utils.json_to_sheet(data);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, this.excelSheetName);

        // 生成Excel文件（这里我们使用XLSX的write功能）
        // 并设置类型为二进制字符串(binary string)
        const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "binary" });

        // 为了确保兼容性，将字符串处理为八位无符号整数数组
        function s2ab(s) {
            const buffer = new ArrayBuffer(s.length);
            const view = new Uint8Array(buffer);
            for (let i = 0; i < s.length; i++) {
                view[i] = s.charCodeAt(i) & 0xFF;
            }
            return buffer;
        }

        // 创建一个Blob对象，并设置文件类型
        const blob = new Blob([s2ab(excelBuffer)], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8"
        });
        // 创建一个临时的a标签用于下载文件
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = fileName + ".xlsx";

        // 模拟点击a标签实现下载
        document.body.appendChild(link);
        link.click();
        // 清理并移除a标签
        document.body.removeChild(link);
    }
}
