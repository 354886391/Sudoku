/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 14:40:04
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-11-14 15:17:52
 * @Description: 大厅网络初始化设置. 网络设置都在这里
 */

if (!CC_EDITOR) {
    /**客户端的一些设置 */
    // 需要自己走链接登陆
    let urlParams: URLSearchParams
    let isLocal: boolean = false
    try {
        //index.html?game_id=0&domain=ws:192.168.99.16:10001&platform=&token=eyJhbGci
        const href: string = window.location.href
        if (href) {
            let content: string = href.slice(href.indexOf('?') + 1)
            urlParams = new URLSearchParams('?' + content)
            //线上必须有token
            if (urlParams.get("token")) {
                isLocal = false
                //设置语言码，APP模式的在app那边设置
                hlgame.systemInfo.language = urlParams.get("language")
                hlgame.startup(urlParams, gea.enums.hallMode.h5Mode)
            }
            else {
                isLocal = true
            }
        }
    } catch (e) {
        //本地开发模式
        isLocal = true
    }

    // 此处的设置只会在浏览器调试用到
    if (isLocal) {
        //服务器地址
        let domain: string = 'http://192.168.99.4:8091'
        //账号 默认每次设置随机
        let identifier: string = urlParams.get("identifier") || gea.localStorage.getItem("identifier")
        if (!identifier) {
            identifier = gea.instance.localTime.toString()
        }
        if (identifier && identifier != gea.localStorage.getItem("identifier")) {
            gea.localStorage.removeItem("identifier")
            gea.localStorage.removeItem("credential")
            gea.localStorage.setItem("identifier", identifier)
            gea.localStorage.setItem("identity_type", 1)
            hlgame.netConfig.identifier = identifier
        }
        // url带入服务器地址，这里只是本地调试使用，url 中domain填入服务器的http地址，从而获取到服务器的ws或者wss地址
        if (urlParams.get("domain")) {
            domain = urlParams.get("domain")
        }
        if (urlParams.get("api_domain")) {
            hlgame.systemInfo.api_domain = urlParams.get("api_domain")
        }
        else {
            hlgame.systemInfo.api_domain = domain
        }
    }
    //
    gea.net.setProtobufjs(require("protobufjs/minimal"))
}
