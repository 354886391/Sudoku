import { HMP_PBEnums } from "../monopoly/proto/HMP_PBEnums";

/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 10:24:41
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-11-14 16:12:39
 * @FilePath: \sub-game-project-creator\assets\script\Main.ts
 * @Description:
 */
const { ccclass, property } = cc._decorator;

@ccclass
export default class Main extends gea.abstracts.ui.ViewBase {
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    //
    private _states: number = 1
    private _txtNode: cc.Node
    private _subGameConfig: any = {
        game_id: 9999,//HMP_GameConfig.gameId,
        status: 1,
        type: gea.enums.bundle.subGame,
        isLocal: true,
        entrance_prefab: "res/GameEntrance",
        /** 横竖屏标识  1 竖屏 2 横屏 */
        orientation: 1,
        bundle: "monopoly"
    }

    start() {
        //加载大厅
        let self = this
        gea.game.requestBundleConfig().then((value) => {
            if (value) {
                self.loadHall()
            }
        })
    }

    loadHall() {
        let hallConfig: hlgame.interfaces.IConfig = gea.game.getBundleConfigByGameId(1)
        hallConfig.parent = gea.ui.getBundleLayer(null, gea.enums.ui.ui_type.view)
        gea.game.enterSubGame(hallConfig, true)

        hlgame.netConfig.gameId = this._subGameConfig.game_id
        hlgame.netConfig.waitEnterGameId = this._subGameConfig.game_id
        //游戏列表设置成只有本地子游戏
        gea.game.updateGameListInfo([this._subGameConfig])

        // //使用本地的协议，一般用于新游戏有新修改协议
        // gea.instance.on(gea.events.subGame.begin_enter_sub_game, () => {
        //     gea.net.parser.setMappingLocal(HMP_PBEnums.Mapping)
        // }, this)

        // gea.game.getBundleConfigByGameId(this._subGameConfig.game_id).url = ""
        // gea.game.getBundleConfigByGameId(this._subGameConfig.game_id).version = ""
    }
    // update (dt) {}
}
