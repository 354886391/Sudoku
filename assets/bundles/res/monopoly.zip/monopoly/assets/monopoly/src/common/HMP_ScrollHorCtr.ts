/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2023-10-17 18:20:21
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-04-29 17:09:03
 * @FilePath: \hall-project-creator\assets\hall\src\common\HallScrollHorCtr.ts
 * @Description: 水平 ScrollView管理
 */

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_ScrollHorCtr extends gea.abstracts.ui.ViewBase {

    @property(cc.Prefab)
    itemPrefab: cc.Prefab = null;
    @property(cc.Node)
    scrollView: cc.Node = null;
    @property(cc.Node)
    content: cc.Node = null;

    // @property
    // pageCount: number = 3;
    @property
    gap: number = 3;
    @property
    endGap: number = 100;
    @property
    baseX: number = 150;
    @property
    itemWidth: number = 500;
    // @property
    // itemClassName: string = "";

    // LIFE-CYCLE CALLBACKS:
    /** 当前需要显示的数量 */
    _endShowIndex: number = 0
    /** 当前已经显示的数量 */
    _starShowIndex: number = 0
    _inShowInit: boolean

    curPage: number = 0
    maxPage: number = 0
    pageCount: number = 0

    _itemPool: cc.Node[] = []
    _itemMap: {} = {}
    _itemList: any[] = []

    needTween: boolean = false
    initNum: number = 0
    // onLoad () {}

    start() {

    }

    setDataList(list: any[]) {
        this._itemList = list

        let viewWidth: number = this.scrollView.width
        this._endShowIndex = Math.ceil((viewWidth - this.gap) / this.itemWidth) + 1
        this.pageCount = this._endShowIndex
        this._endShowIndex = this._endShowIndex > this._itemList.length ? this._itemList.length : this._endShowIndex

        this._starShowIndex = 0
        this._inShowInit = true
        this.content.width = this._itemList.length * this.itemWidth + this.endGap + (this._itemList.length - 1) * this.gap
        this.maxPage = (this._itemList.length - this._endShowIndex) + 1

        this.curPage = -1
        this.lateUpdate(null)
    }

    lateUpdate(dt) {
        if (this._starShowIndex < this._endShowIndex && this._starShowIndex < this._itemList.length) {
            if (this._itemMap[this._starShowIndex] && this._itemMap[this._starShowIndex].parent) {
                this._starShowIndex++
                return
            }
            let node: cc.Node = this.getItemNode(this._starShowIndex)//cc.instantiate(this.HallShopItemComPrefab)
            node.parent = this.content
            node.getComponent(node.name).setData(this._itemList[this._starShowIndex])
            node.opacity = 255

            node.stopAllActions()
            node.x = this.baseX + this.itemWidth / 2 + this._starShowIndex * (this.itemWidth + this.gap)
            this._itemMap[this._starShowIndex] = node
            this._starShowIndex++
            if (this.needTween) {
                this.initNum++
                if (this.initNum < this.pageCount) {
                    let endX: number = node.x
                    node.x = -gea.ui.viewPort.width - this.itemWidth
                    cc.tween(node).to(1.5 - this._starShowIndex * 0.1, { x: endX + this.itemWidth / 2 }).to(0.8, { x: endX }).start()
                }
                else {
                    this.needTween = false
                }
            }
            // gea.log("this.content.childrenCount   ", this.content.childrenCount)
        }
        else {
            let page: number = this.getCurPage()
            if (page != this.curPage) {

                this._starShowIndex = page - 1
                this._starShowIndex = this._starShowIndex < 0 ? 0 : this._starShowIndex
                this._endShowIndex = this._starShowIndex + this.pageCount

                for (const key in this._itemMap) {
                    if (Object.prototype.hasOwnProperty.call(this._itemMap, key)) {
                        const child = this._itemMap[key];
                        let index: number = Number(key)
                        if (child && (index < this._starShowIndex || index > this._endShowIndex)) {
                            child.parent = null
                            this._itemPool.push(child)
                            this._itemMap[index] = null
                            delete this._itemMap[index]
                        }
                    }
                }
                this.curPage = page
            }
        }
    }

    getCurPage(): number {
        let page: number = Math.floor((-this.content.x - this.scrollView.width / 2 - this.itemWidth / 2) / this.itemWidth) + 1
        page = page >= 0 ? page : 0
        page = page > this.maxPage ? this.maxPage : page
        return page
    }

    getItemNode(index: number): cc.Node {
        if (this._itemPool.length > 0) {
            return this._itemPool.shift()
        }
        if (this._itemMap[index]) {
            return this._itemMap[index]
        }
        let node = cc.instantiate(this.itemPrefab)
        this.pushToReleaseList(node.getComponent(this.itemPrefab.name))
        return node
    }
    // update (dt) {}
}
