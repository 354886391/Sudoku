/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2023-11-4 18:52:43
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-11-14 16:14:13
 * @Description: 游戏加载界面
 */

import { HMP_ExlLoader } from "../../adapters/HMP_ExlLoader";
import { HMP_ExllangTableProvider } from "../../excelData/HMP_ExllangTable";
import { HMP_ExlloadingProvider } from "../../excelData/HMP_Exlloading";
import { HMP_PBEnums } from "../../proto/HMP_PBEnums";
import { HMP_Event } from "../common/HMP_Event";
import { HMP_GameConfig } from "../common/HMP_GameConfig";
import HMP_GameData from "../common/HMP_GameData";
import HMP_MainPanel from "../ui/HMP_MainPanel";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_PreLoading extends gea.abstracts.ui.PreLoadingBase {

    static get prefabUrl(): string {
        return 'res/prefab/loading/HMP_PreLoading'
    }
    /**bundle 名称 */
    static get bundle(): string {
        return HMP_GameConfig.bundle
    }

    static get excludeHideAll(): boolean {
        return true
    }

    @property({ type: cc.Label, tooltip: '进度文本' })
    txtProgress: cc.Label = null

    // LIFE-CYCLE CALLBACKS:

    /** 预加载资源列表 */
    private _preloadList: string[] = [

    ]
    _mainPreloadList: string[] = [
        "res/prefab/ui/HMP_MainPanel"
    ]
    private _dataInfo: HMP_GameData

    start() {
        super.start()
        this._dataInfo = gea.game.get(HMP_GameData)
    }
    updateProgress() {
        //进度只能增长
        if (this.progressBar.progress > this.curProgress / 100) {
            this.curProgress = Math.floor(this.progressBar.progress * 100)
        }
        this.curProgress = Math.min(this.curProgress, 100)
        this.progressBar.progress = this.curProgress / 100
        this.progressTxt.string = Math.floor(this.curProgress) + '%'
        this.nextUpdateTime = gea.net.serverTime + 1000
    }

    // 加载完成
    loadSuccess() {
        this.updateLoading(0, gea.enums.GameLoadingType.login)
        if (!this.slotInited) {
            this.initSlotReq()
        }
        else {
            this.onSlotInit()
        }
    }
    /** 游戏服务器初始化完成 */
    onSlotInit() {
        this.onShowTime = gea.net.serverTime + 1000
        this.slotInited = true
        // gea.instance.dispatch(gea.events.ui.game_loading_progress, 1, gea.enums.GameLoadingType.complete)
        gea.ui.show(this.mainPanel)
        // setTimeout((, 1000);
        // gea.timer.once(1000, this.doClose, this)
        // this.doClose()
    }
    callbackAfterShow() {
        super.callbackAfterShow()

        // gea.audioMgr.playBgMusic('res/sound/prizedropbgm', this.bundle)
    }
    //=========================需要复写的方法==========================
    /** 初始事件名 */
    get slot_init_event(): string {
        return HMP_Event.slot_init_event
    }
    get slot_init_failed(): string {
        return HMP_Event.slot_init_failed
    }
    /** gameid */
    get gameId(): number {
        return HMP_GameConfig.gameId
    }
    /** 配置类 */
    get ExlLoader(): any {
        return HMP_ExlLoader
    }
    /** 配置 loading类 */
    get ExlloadingProvider(): any {
        return HMP_ExlloadingProvider
    }
    /** 配置多语言类 */
    get ExllangTableProvider(): any {
        return HMP_ExllangTableProvider
    }
    /** 预加载列表 */
    get preloadList(): any {
        return this._preloadList
    }
    get mainPreloadList(): any {
        return this._mainPreloadList
    }
    get PreLoadingPane(): any {
        return HMP_PreLoading
    }
    get mainPanel(): gea.interfaces.ui.IUIClass {
        return HMP_MainPanel
    }

    get PBEnums(): any {
        return HMP_PBEnums
    }

    /**初始化游戏协议请求 */
    initSlotReq() {
        this._dataInfo.SendSlotInitReq()
    }

    testClick() {
        gea.net.send(HMP_PBEnums.Req_MonopolyInfo)
    }
    //-----------------------------------------------------------------
}
