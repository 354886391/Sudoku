import HMP_GameData from "../../common/HMP_GameData";
import HMP_MainPanel from "../HMP_MainPanel";
import HMP_BuildClickCom from "./HMP_BuildClickCom";

/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2024-11-07 11:11:26
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-11-14 14:54:13
 * @FilePath: \monopoly\assets\monopoly\src\ui\com\HMP_BuildIngBottomCom
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_BottomBuildIngCom extends gea.abstracts.ui.ViewBase {
    @property(cc.Prefab)
    buildCardPrefab: cc.Prefab = null;

    @property(cc.Node)
    buildCardCont: cc.Node = null;

    buildCardList: HMP_BuildClickCom[] = []
    mainCom: HMP_MainPanel

    onLoad() {
        let item: cc.Node
        for (let i = 0; i < 5; i++) {
            item = cc.instantiate(this.buildCardPrefab)
            item.parent = this.buildCardCont

            this.buildCardList.push(item.getComponent(HMP_BuildClickCom))

            // item.getComponent(HMP_BuildClickCom).setData({ Id: 1, Index: i + 1, Level: i + 1, isBroken: Math.floor(Math.random() * 4) - 1 })
        }
        this.buildCardCont.getComponent(cc.Layout).updateLayout()
        this.buildCardCont.removeComponent(cc.Layout)

        // this.buildCardCont.active = false
    }

    init(mainCom: HMP_MainPanel) {
        this.mainCom = mainCom

        let list = gea.get(HMP_GameData).monopolyInfoRes.Building
        for (let i = 0; i < this.buildCardList.length; i++) {
            this.buildCardList[i].setData(list[i])
        }
    }

    onCloseBuildClick() {
        this.mainCom.buildBottomCtl.hide()
        this.mainCom.onGotoChessBoard()
    }

    //====================================================================
    showTween: cc.Tween
    showTweenList: cc.Tween[] = []
    frameTime: number = 0.032
    delayTime: number = 1
    show() {
        this.node.y = -gea.ui.viewPort.halfHeight - 230
        this.node.active = true

        let item: cc.Node
        for (let i = 0; i < this.buildCardList.length; i++) {
            item = this.buildCardList[i].node
            item.opacity = 0
            item.scaleY = 0.5
            if (!this.showTweenList[i]) {
                this.showTweenList.push(
                    cc.tween(item).delay(this.delayTime + 3 * this.frameTime + i * this.frameTime).
                        to(this.frameTime, { opacity: 100 }).to(this.frameTime, { scaleY: 1.1, opacity: 255 }).to(this.frameTime, { scaleY: 1 })
                )
            }
            this.showTweenList[i].start()
        }

        if (!this.showTween) {
            this.showTween = cc.tween(this.node).delay(this.delayTime).to(this.frameTime * 4, { y: -gea.ui.viewPort.halfHeight }).to(this.frameTime * 4, { y: -gea.ui.viewPort.halfHeight - 41 })
        }
        this.showTween.start()
    }

    hideTween: cc.Tween
    hideTweenList: cc.Tween[] = []

    hide() {
        if (!this.hideTween) {
            this.hideTween = cc.tween(this.node).to(this.frameTime * 4, { y: -gea.ui.viewPort.halfHeight - 230 })
                .delay(3 * this.frameTime).to(this.frameTime * 4, { y: -gea.ui.viewPort.halfHeight - 600 }).call(this.hideComplete, this)
        }
        this.hideTween.start()

        let item: cc.Node
        for (let i = 0; i < this.buildCardList.length; i++) {
            item = this.buildCardList[i].node
            if (!this.hideTweenList[i]) {
                this.hideTweenList.push(
                    cc.tween(item).delay(this.frameTime + i * this.frameTime)
                        .to(this.frameTime, { scaleY: 0.9 }).to(this.frameTime, { scaleY: 0.8, opacity: 100 }).to(this.frameTime, { scaleY: 0.5, opacity: 0 })
                )
            }
            this.hideTweenList[i].start()
        }
    }

    hideComplete() {
        this.node.active = false
    }
}
