/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2023-01-14 09:55:19
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-11-14 15:27:38
 * @Description: 这里写你类描述
 */
export namespace HMP_GameConfig {
    /** gameId  与bundle名字统一 */
    export const gameId: number = 80002
    export const bundle: string = "monopoly"
}
