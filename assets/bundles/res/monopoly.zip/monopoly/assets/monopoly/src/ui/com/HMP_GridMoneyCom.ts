// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_GridMoneyCom extends gea.abstracts.ui.ViewBase {

    @property(cc.Label)
    moneyTxt: cc.Label = null;

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}
    showTween: cc.Tween
    start() {
        this.node.scale = 0
        this.node.active = false
    }

    showMoney(value: number) {
        let per = value > 0 ? "" : "-"
        this.moneyTxt.string = per + hlgame.utils.comUtil.getUnitedNumStr(Math.abs(value))

        this.node.scale = 0
        this.node.active = true
        if (!this.showTween) {
            this.showTween = cc.tween(this.node).to(6 * 0.032, { scale: 1.5, opacity: 255 }).delay(0.5).by(6 * 0.032, { y: 200, opacity: -255 })
        }
        this.showTween.stop()
        this.showTween.start()
    }

    // update (dt) {}
}
