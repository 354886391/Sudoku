import { HMP_pb } from "../../proto/HMP_pb";
import { HMP_PBEnums } from "../../proto/HMP_PBEnums";
import { HMP_CameraFollowCom } from "../common/HMP_CameraFollowCom";
import { HMP_Event } from "../common/HMP_Event";
import { HMP_GameConfig } from "../common/HMP_GameConfig";
import HMP_GameData from "../common/HMP_GameData";
import HMP_BottomBuildIngCom from "./com/HMP_BottomBuildIngCom";
import HMP_BottomMainCom from "./com/HMP_BottomMainCom";
import HMP_BuildContCom from "./com/HMP_BuildContCom";
import HMP_ChessCom from "./com/HMP_ChessCom";
import HMP_GridCom from "./com/HMP_GridCom";
import HMP_GridMoneyCom from "./com/HMP_GridMoneyCom";
import HMP_TopCtlCom from "./com/HMP_TopCtlCom";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_MainPanel extends gea.abstracts.ui.ViewBase {
    static get prefabUrl(): string {
        return 'res/prefab/ui/HMP_MainPanel'
    }

    /**bundle 名称 */
    static get bundle(): string {
        return HMP_GameConfig.bundle
    }

    @property(cc.Node)
    chessBoard: cc.Node = null;

    @property(cc.Sprite)
    chessMap: cc.Sprite = null;
    @property(HMP_ChessCom)
    currentChess: HMP_ChessCom = null;
    @property(HMP_CameraFollowCom)
    cameraFollow: HMP_CameraFollowCom = null;

    @property(HMP_BottomMainCom)
    bottomCtl: HMP_BottomMainCom = null;
    @property(HMP_TopCtlCom)
    topCtl: HMP_TopCtlCom = null;

    @property(HMP_BottomBuildIngCom)
    buildBottomCtl: HMP_BottomBuildIngCom = null;
    @property(HMP_BuildContCom)
    buildContCtl: HMP_BuildContCom = null;

    @property(sp.Skeleton)
    leftDice: sp.Skeleton = null
    @property(sp.Skeleton)
    rightDice: sp.Skeleton = null
    @property(cc.Material)
    flashMaterial: cc.Material = null!;

    @property(HMP_GridMoneyCom)
    addGridMoney: HMP_GridMoneyCom = null;
    @property(HMP_GridMoneyCom)
    addGridMoneyStart: HMP_GridMoneyCom = null;
    @property(HMP_GridMoneyCom)
    reduceGridMoney: HMP_GridMoneyCom = null;

    dataInfo: HMP_GameData
    topBarInited: boolean = false

    diceAni: string[] = ['01/01', '01/02', '01/03', '01/04', '01/05', '01/06']

    // moneyNode: cc.Node
    // LIFE-CYCLE CALLBACKS:
    leagueExl: any

    hallData: any
    // onLoad () {}

    start() {
        this.dataInfo = gea.get(HMP_GameData)
        //
        gea.instance.on(HMP_Event.request_go_to_chess_board, this.onGotoChessBoard, this)
        gea.instance.on(HMP_Event.request_go_to_build_scene, this.onGotoBuildScene, this)
        gea.instance.on(HMP_Event.notice_collect_money, this.showCollectMoney, this)

        gea.net.on(HMP_PBEnums.Res_MonopolyInfo, this.onMonopolyInfoRes, this)
        gea.net.on(HMP_PBEnums.Res_MonopolyPlay, this.onMonopolyPlayRes, this)
        //拖动
        this.chessMap.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this)
        this.chessMap.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this)
        this.chessMap.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this)
        this.chessMap.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this)
        //骰子
        this.rightDice.setCompleteListener((trackEntry) => {
            this.onSencondDiceFinish()
        });

        this.leftDice.node.y = -gea.ui.viewPort.height
        this.rightDice.node.y = -gea.ui.viewPort.height

        //四角点位获取，用于计算投掷骰子区域
        this.chessBoardRecPos = []
        let pos
        for (let i = 1; i <= 4; i++) {
            pos = cc.find("Node" + i, this.chessBoard).getPosition()
            this.chessBoardRecPos.push(cc.v2(pos.x, pos.y))
            cc.find("Node" + i, this.chessBoard).parent = null
        }
        this.chessBoardRecPos.push(this.chessBoardRecPos[0])

        HMP_GridCom.Material = cc.Material.getBuiltinMaterial("2d-sprite")
    }

    callbackAfterShow() {

        this.initChessBoard()
        this.bottomCtl.init(this)
        this.buildBottomCtl.init(this)
        this.buildBottomCtl.node.active = false
        this.buildContCtl.init(this)
        this.topCtl.updateInfo()
        gea.instance.dispatch(gea.events.ui.game_loading_progress, 1, gea.enums.GameLoadingType.complete)
    }

    /** 丢骰子 */
    doMonopolyPlayReq() {
        if (this.dataInfo.Multiple > this.dataInfo.getDiceItemNum()) {
            gea.instance.dispatch(HMP_Event.notice_need_stop_auto)
            if (this.dataInfo.Multiple > 1) {
                this.bottomCtl.checkAndChangeMultiple(-2)
            }
            return
        }

        this.bottomCtl.isOnChessRound = true
        // this.onMonopolyPlayRes({ Number1: Math.floor(Math.random() * 6) + 1, Number2: Math.floor(Math.random() * 6) + 1 })
        gea.net.send(HMP_PBEnums.Req_MonopolyPlay, { Multiple: this.dataInfo.Multiple })
    }

    onGotoChessBoard() {
        if (this.dataInfo.checkGotoChessBoard()) {
            this.cameraFollow.moveToChessBoard()
            this.bottomCtl.show()
            this.topCtl.onGotoChessBoard()
        }
    }

    onGotoBuildScene() {
        this.cameraFollow.moveToBuildScene(cc.v2(this.buildContCtl.node.x, this.buildContCtl.node.y))
        this.topCtl.onGotoBuildScene()
    }

    //协议返回================================================================================
    onMonopolyInfoRes() {
        this.initChessBoard()
    }

    dropDicPosMap: Map<number, cc.Vec3[]> = new Map()
    playeEndIndex: number = -1
    onMonopolyPlayRes(msg: HMP_pb.IMonopolyPlayRes) {
        if (msg.Number1 <= 0 || msg.Number2 <= 0) {
            return
        }
        this.playeEndIndex = msg.Lattice

        this.totalPoint = msg.Number1 + msg.Number2
        this.leftDice.setAnimation(0, this.diceAni[msg.Number1 - 1], false);
        this.rightDice.setAnimation(0, this.diceAni[msg.Number2 - 1], false);

        //获取骰子可投掷区域
        if (!this.dropDicPosMap.has(this.currentIndex)) {
            this.dropDicPosMap.set(this.currentIndex, this.getRectInChessBoard())
        }

        let pos = this.cameraFollow.node.position
        pos = cc.v3(-pos.x, -pos.y - cc.view.getVisibleSize().height / 2, pos.z)
        this.leftDice.node.setPosition(pos)
        this.rightDice.node.setPosition(pos)

        let vec3s: cc.Vec3[] = this.dropDicPosMap.get(this.currentIndex)
        let array = this.getTwoUniqueRandomElements(vec3s)
        cc.tween(this.leftDice.node).to(0.6, { position: array[0] }).start()
        cc.tween(this.rightDice.node).to(0.6, { position: array[1] }).start()
    }

    //拖动=================================================================================
    touchStartPos: cc.Vec2
    onTouchStart(event) {
        // 记录触摸开始的位置
        this.touchStartPos = event.getLocation();
    }
    onTouchMove(event) {
        if (this.touchStartPos) {
            // 计算移动的偏移量
            let diff = event.getLocation().sub(this.touchStartPos);
            // // 移动节点
            this.cameraFollow.doTouchMoveCamera(diff.x, diff.y)
            // 重置开始位置
            this.touchStartPos = event.getLocation();
        }
    }
    onTouchEnd(event) {
        this.touchStartPos = null
        this.cameraFollow.doTouchMoveEnd()
    }
    //走棋子==================================================================================
    jumpTime: number = 0.35

    gridItemList: HMP_GridCom[] = []
    jumpTimes: number = 0
    currentIndex: number = 0
    //总点数
    totalPoint: number = 0
    waitForStop: boolean = false
    curPlayMoveGrid: HMP_GridCom

    /** 初始化棋盘 */
    initChessBoard() {
        if (!this.dataInfo.monopolyInfoRes) {
            return
        }
        this.gridItemList.length = 0
        for (let i = 0; i < 40; i++) {
            this.gridItemList.push(cc.find("chessBoard/grid" + i, this.node).getComponent(HMP_GridCom))
            this.gridItemList[i].bundle = this.bundle
            this.gridItemList[i].init(i + 1)
        }
        this.gridItemList.unshift(this.gridItemList[0])//服务端从1开始，数字第一位塞多一个没用的
        // this.updateShieldInfo()
        this.cameraFollow.init()
        this.currentIndex = this.dataInfo.monopolyInfoRes.Lattice
        let pos = this.gridItemList[this.currentIndex].node.position.clone()
        this.currentChess.node.setPosition(pos)
        this.cameraFollow.target = this.currentChess.node
        this.setChessOrientation()
        this.currentChess.node.setPosition(pos)//.add(this.chessGapPos))
        this.cameraFollow.onUpdateCamera()
    }
    /** 更新棋盘护盾 */
    updateShieldInfo() {
        let list = gea.get(HMP_GameData).monopolyInfoRes.ShieldLattice
        for (let i = 0; i < list.length; i++) {
            this.gridItemList[list[i] - 1].updateShild(list)
        }
    }

    /** 设置骰子区域 */
    setChessOrientation() {
        let nextGridIndex = this.currentIndex + 1
        if (nextGridIndex >= this.gridItemList.length) {
            nextGridIndex = 0
        }
        let nextGrid: cc.Node = this.gridItemList[nextGridIndex].node
        this.currentChess.setNextGrid(nextGrid)
        // this.cameraFollow.onUpdateCamera()
    }

    onSencondDiceFinish(): void {
        if (this.playeEndIndex == this.currentIndex) {
            //不可走动 目前是监狱中
            gea.instance.dispatch(HMP_Event.notice_chess_move_end)
            return
        }
        this.startJumping()
    }

    startJumping(): void {
        this.jumpTimes = 0

        // this.keyList[this.currentIndex].getComponent(Animation)
        this.cameraFollow.isOnMove = true
        this.canJumpNext()
    }

    canJumpNext(): void {
        if (this.jumpTimes < this.totalPoint) {
            this.jumpNextPos();
        } else {
            this.waitForStop = false
            this.onJumpFinished()
            this.cameraFollow.isOnMove = false
        }
    }
    onJumpFinished(): void {
        this.curPlayMoveGrid && this.curPlayMoveGrid.removeFlash()
        this.curPlayMoveGrid = this.gridItemList[this.currentIndex].playMove(this.flashMaterial)
        gea.instance.dispatch(HMP_Event.notice_chess_move_end)
    }

    jumpNextPos(): void {

        if (this.jumpTimes > 0) {
            this.curPlayMoveGrid && this.curPlayMoveGrid.removeFlash()
            this.curPlayMoveGrid = this.gridItemList[this.currentIndex].playMove(this.flashMaterial)
        }
        //经过起点
        if (this.currentIndex == 1) {
            if (this.dataInfo.startEvent) {
                this.addGridMoneyStart.node.setPosition(this.gridItemList[this.currentIndex].node.getPosition())
                this.addGridMoneyStart.showMoney(this.dataInfo.startEvent.ChangeCash)
                this.dataInfo.startEvent = null
            }
        }
        this.currentIndex++;
        if (this.currentIndex >= this.gridItemList.length) {
            this.currentIndex = 1
        }
        let piecePosition = this.gridItemList[this.currentIndex].node.position.clone()//.add(this.chessGapPos)

        this.cameraFollow.moveToNextPosition(this.gridItemList[this.currentIndex].node.getPosition(), this.jumpTime)

        this.currentChess.qtJumpPosition(piecePosition, 70, 1, this.jumpTime,
            () => {
                this.setChessOrientation()
                this.jumpTimes++;
                this.canJumpNext()
            }
        )
    }

    showCollectMoney(addMoney: number, needFly: boolean = false) {
        if (addMoney < 0) {
            this.reduceGridMoney.node.setPosition(this.currentChess.node.getPosition())
            this.reduceGridMoney.showMoney(addMoney)
            return
        }

        this.addGridMoney.node.setPosition(this.currentChess.node.getPosition())
        this.addGridMoney.showMoney(addMoney)
        if (needFly) {
            // Effect2DMgr.instance.playEffect("money001", this.frontLayer, this.keyList[this.currentIndex].getPosition())
        }

    }

    //================================================================================

    chessBoardRecPos: cc.Vec2[] = null

    insertNewToArrary(arr: cc.Vec2[], pos: cc.Vec2) {
        if (arr.indexOf(pos) < 0) {
            arr.push(pos)
        }
    }

    getTwoUniqueRandomElements<T>(array: T[]): [T, T] | null {
        if (array.length < 2) {
            return null;
        }

        let index1 = Math.floor(Math.random() * array.length);
        let element1 = array[index1];

        let index2: number;
        do {
            index2 = Math.floor(Math.random() * array.length);
        } while (index2 === index1);

        let element2 = array[index2];

        return [element1, element2];
    }


    /** 从当前视图所见棋盘区域获取两个位置点放置骰子 */
    getRectInChessBoard(): cc.Vec3[] {

        let croPos: cc.Vec2[] = []
        let intersection: cc.Vec2[]
        let pos = this.chessBoard.getPosition()
        pos = cc.v2(-pos.x, -pos.y)
        let size = cc.view.getVisibleSize()
        let rect: cc.Rect = new cc.Rect(pos.x - size.width / 2, pos.y - size.height / 2, size.width, size.height)
        let cameraPos: cc.Vec2[] = [cc.v2(pos.x - size.width / 2, pos.y - size.height / 2),
        cc.v2(pos.x - size.width / 2, pos.y + size.height / 2),
        cc.v2(pos.x + size.width / 2, pos.y + size.height / 2),
        cc.v2(pos.x + size.width / 2, pos.y - size.height / 2)]

        let interPos: cc.Vec2

        for (let i = 0; i < this.chessBoardRecPos.length - 1; i++) {
            if (rect.contains(this.chessBoardRecPos[i])) {
                this.insertNewToArrary(croPos, this.chessBoardRecPos[i])
            }
            if (rect.contains(this.chessBoardRecPos[i]) && rect.contains(this.chessBoardRecPos[i + 1])) {
                this.insertNewToArrary(croPos, this.chessBoardRecPos[i])
                this.insertNewToArrary(croPos, this.chessBoardRecPos[i + 1])
                continue
            }

            for (let j = 0; j < cameraPos.length - 1; j++) {
                interPos = this.getLineIntersection(this.chessBoardRecPos[i], this.chessBoardRecPos[i + 1], cameraPos[j], cameraPos[j + 1])
                if (interPos) {
                    croPos.push(interPos)
                    // break
                }
            }
        }

        for (let i = 0; i < cameraPos.length; i++) {
            if (this.isPointInsidePolygon(cameraPos[i], this.chessBoardRecPos)) {
                croPos.push(cameraPos[i])
            }
        }


        // let grap
        // let poss

        // grap = cc.find("chessBoard/grap", this.node).getComponent(cc.Graphics) //this.currentChess.node.getChildByName("grap").getComponent(cc.Graphics)
        // grap.clear()


        // poss = croPos

        // grap.moveTo(poss[0].x, poss[0].y)


        // for (let i = 1; i < poss.length; i++) {
        //     grap.lineTo(poss[i].x, poss[i].y)
        // }
        // grap.stroke()


        let vec3s: cc.Vec3[] = this.getTwoFixedSizeRectsFromPolygon(croPos, new cc.Size(100, 100))
        return vec3s
    }


    //---
    // 计算交点
    getLineIntersection(p0: cc.Vec2, p1: cc.Vec2, p2: cc.Vec2, p3: cc.Vec2): cc.Vec2 | null {
        let s1_x, s1_y, s2_x, s2_y;
        s1_x = p1.x - p0.x;
        s1_y = p1.y - p0.y;
        s2_x = p3.x - p2.x;
        s2_y = p3.y - p2.y;

        const s = (-s1_y * (p0.x - p2.x) + s1_x * (p0.y - p2.y)) / (-s2_x * s1_y + s1_x * s2_y);
        const t = (s2_x * (p0.y - p2.y) - s2_y * (p0.x - p2.x)) / (-s2_x * s1_y + s1_x * s2_y);

        if (s >= 0 && s <= 1 && t >= 0 && t <= 1) {
            // 交点存在
            return cc.v2(p0.x + (t * s1_x), p0.y + (t * s1_y));
        }

        return null; // 交点不存在
    }
    ////////////////////////////////////////////////

    // 判断点是否在多边形内部
    isPointInsidePolygon(point, vertices) {
        // 转换为向量
        let vPoint = cc.v2(point);
        let vVertices = vertices.map(vertex => cc.v2(vertex));

        // 判断交点的奇偶性
        let nCross = 0;
        for (let i = 0; i < vVertices.length; i++) {
            let v1 = vVertices[i];
            let v2 = vVertices[(i + 1) % vVertices.length];
            if (vPoint.y > Math.min(v1.y, v2.y) && vPoint.y <= Math.max(v1.y, v2.y)) {
                let d = (vPoint.y - v1.y) / (v2.y - v1.y);
                let x = v1.x + (v2.x - v1.x) * d;
                if (x > vPoint.x) {
                    nCross++;
                }
            }
        }

        // 如果nCross为奇数，点在多边形内
        return nCross % 2 === 1;
    }

    //================================================================

    // 假设polygon是一个包含多边形顶点的数组，例如: [[x1, y1], [x2, y2], ...]
    // size是你想要的固定尺寸，例如: cc.size(100, 100)
    getTwoFixedSizeRectsFromPolygon(polygon: cc.Vec2[], size: cc.Size): cc.Vec3[] {
        // 计算多边形的边界矩形
        let minX = Number.POSITIVE_INFINITY;
        let minY = Number.POSITIVE_INFINITY;
        let maxX = Number.NEGATIVE_INFINITY;
        let maxY = Number.NEGATIVE_INFINITY;
        polygon.forEach(point => {
            minX = Math.min(minX, point.x);
            minY = Math.min(minY, point.y);
            maxX = Math.max(maxX, point.x);
            maxY = Math.max(maxY, point.y);
        });
        let boundingRect = new cc.Rect(minX, minY, maxX - minX, maxY - minY);

        // 从边界矩形中划分出两个固定尺寸的矩形
        let rect1 = new cc.Rect(
            boundingRect.x + (boundingRect.width - size.width) / 2 - size.width,
            boundingRect.y + (boundingRect.height - size.height) / 2,
            size.width,
            size.height
        );
        let rect2 = new cc.Rect(
            boundingRect.x + (boundingRect.width - size.width) / 2 + size.width,
            boundingRect.y + boundingRect.height - (boundingRect.height - size.height) / 2 - size.height,
            size.width,
            size.height
        );

        return [cc.v3(rect1.x, rect1.y, 1), cc.v3(rect2.x, rect2.y, 1)];
    }
}
