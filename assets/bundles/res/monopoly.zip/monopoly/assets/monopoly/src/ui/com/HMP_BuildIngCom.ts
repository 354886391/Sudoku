// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { HMP_Exlmonopoly_build, HMP_Exlmonopoly_buildProvider } from "../../../excelData/HMP_Exlmonopoly_build";
import { HMP_pb } from "../../../proto/HMP_pb";
import { HMP_GameConfig } from "../../common/HMP_GameConfig";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_BuildIngCom extends gea.abstracts.ui.ViewBase {

    @property(cc.Label)
    label: cc.Label = null;

    // LIFE-CYCLE CALLBACKS:
    brokenParticle: cc.Node[] = []
    buildAni: cc.Animation
    buildImg: cc.Sprite

    index: number = 1
    curExl: HMP_Exlmonopoly_build

    // onLoad () {}
    curData: HMP_pb.IMonopolyBuilding
    curLevel: number = 0

    onLoad() {
        for (let i = 1; i <= 4; i++) {
            this.brokenParticle.push(cc.find("Particle" + i, this.node))
        }
        this.buildAni = this.node.getComponent(cc.Animation)
        this.buildImg = cc.find("buildingImg", this.node).getComponent(cc.Sprite)
    }

    // update (dt) {}

    setData(data: HMP_pb.IMonopolyBuilding) {
        if (!this.curData || this.curLevel != data.Level) {
            this.index = data.Index
            this.curLevel = data.Level
            this.curExl = HMP_Exlmonopoly_buildProvider.getById(data.Id)
            let url: string = this.getBuildIngUrl(this.index, data.Level)
            if (url) {
                gea.loadMgr.setSpriteFrame(url, this.buildImg, HMP_GameConfig.bundle)
            }
            else {
                this.buildImg.spriteFrame = null
            }
        }
        this.curData = data
        for (let i = 0; i < this.brokenParticle.length; i++) {
            this.brokenParticle[i].active = data.isBroken > 0
        }
        this.buildImg.node.angle = data.isBroken > 0 ? 10 : 0
    }

    getBuildIngUrl(index: number, level: number): string {
        if (level > 0) {
            return `res/textures/map/build/${this.curExl.res}/${index + 1}/` + level
        }
        return null
    }

    nextSpriteFrame: cc.SpriteFrame = null
    isWaitUpdateSprite: boolean = false
    buildTween: cc.Tween
    repairTween: cc.Tween
    frameTime: number = 0.016 * 2

    doBuild(data: HMP_pb.IMonopolyBuilding) {
        this.nextSpriteFrame = null
        let self = this
        if (this.curLevel != data.Level) {
            this.curLevel = data.Level
            let url: string = this.getBuildIngUrl(this.index, data.Level)
            gea.assetMgr.load(HMP_GameConfig.bundle, url, cc.SpriteFrame, null, (err, asstes: cc.SpriteFrame) => {
                self.nextSpriteFrame = asstes
                if (self.isWaitUpdateSprite) {
                    self.changeBuildIng()
                }
            })
        }

        if (this.curData.isBroken > 0) {
            if (!this.repairTween) {
                this.repairTween = cc.tween(this.buildImg.node).delay(1).to(this.frameTime * 2, { angle: 0 })
            }
            this.repairTween.start()
        }
        else {
            if (!this.buildTween) {
                this.buildTween = cc.tween(this.buildImg.node).delay(1).call(this.changeBuildIng, this).to(this.frameTime * 5, { scaleX: 0.6, scaleY: 1.4 })
                    .to(this.frameTime * 5, { scaleX: 1.4, scaleY: 0.6 }).to(this.frameTime * 5, { scaleX: 1, scaleY: 1 })
            }
            this.buildTween.start()
        }
        this.buildAni.play()
    }

    changeBuildIng() {
        if (!this.nextSpriteFrame) {
            this.isWaitUpdateSprite = true
            return
        }

        this.buildImg.spriteFrame = this.nextSpriteFrame
        this.nextSpriteFrame = null
        this.isWaitUpdateSprite = false
    }

}
