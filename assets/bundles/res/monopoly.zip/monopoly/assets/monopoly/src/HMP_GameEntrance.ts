/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 11:36:50
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-11-05 18:02:03
 * @Description: 子游戏场景入口
 */
import { HMP_PBEnums } from "../proto/HMP_PBEnums";
import { HMP_GameConfig } from "./common/HMP_GameConfig";
import HMP_GameData from "./common/HMP_GameData";
import HMP_PreLoading from "./loading/HMP_PreLoading";
import HMP_MainPanel from "./ui/HMP_MainPanel";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_GameEntrance extends gea.abstracts.ui.ViewBase {

    @property(cc.Prefab)
    preloading: cc.Prefab = null;
    @property(cc.Prefab)
    mainPanel: cc.Prefab = null;
    static get bundle(): string {
        return HMP_GameConfig.bundle
    }
    // @property
    // text: string = 'hello';

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start() {
        this.bundle = HMP_GameConfig.bundle
        //使用自身协议文件
        gea.net.parser.setMappingLocal(HMP_PBEnums.Mapping)
        //初始化一些游戏的控制类
        gea.game.register(this.bundle, HMP_GameData)
        gea.ui.show(HMP_PreLoading)
        // gea.ui.show(HMP_MainPanel)
        // //抛出子游戏加载完成通知
        // gea.instance.dispatch(gea.events.subGame.enter_sub_game_comolete)
        // cc.director.emit(gea.events.subGame.enter_sub_game_comolete)
    }
    // update (dt) {}
}
