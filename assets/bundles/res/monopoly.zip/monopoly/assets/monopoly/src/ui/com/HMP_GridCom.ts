// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { HMP_Exlmonopoly_qp, HMP_Exlmonopoly_qpProvider } from "../../../excelData/HMP_Exlmonopoly_qp";
import { HMP_Event } from "../../common/HMP_Event";
import { HMP_GameConfig } from "../../common/HMP_GameConfig";
import HMP_GameData from "../../common/HMP_GameData";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_GridCom extends gea.abstracts.ui.ViewBase {
    static Material: cc.Material = null
    @property(cc.Label)
    label: cc.Label = null;

    // LIFE-CYCLE CALLBACKS:
    index: number
    gridImg: cc.Sprite = null
    lineImg: cc.Sprite = null

    shieldImag: cc.Sprite = null
    addShieldTween: cc.Tween = null
    // onLoad () {}

    start() {
        this.gridImg = this.node.getComponent(cc.Sprite)
        let line = this.node.getChildByName("b_02") || this.node.getChildByName("c_02")
        line && (this.lineImg = line.getComponent(cc.Sprite))
    }

    get worldPosition(): cc.Vec2 {
        return this.node.convertToWorldSpaceAR(cc.Vec2.ZERO)
    }

    playMove(material: cc.Material): HMP_GridCom {
        // this.ani.play()
        this.setFlash(material)
        return this
    }

    init(index: number) {
        this.index = index
        let exl: HMP_Exlmonopoly_qp = HMP_Exlmonopoly_qpProvider.getById(index)

        if (exl.reward && exl.reward != "") {
            this.rewardName = exl.reward
            gea.instance.on(HMP_Event.notice_worth_upgrade, this.updateCashShow, this)
            this.updateCashShow()
        }
    }

    rewardName: string
    moneyLbl: cc.Label
    updateCashShow() {
        if (!this.moneyLbl) {
            this.moneyLbl = new cc.Node().addComponent(cc.Label)
            this.moneyLbl.node.color = cc.Color.BLACK
            this.moneyLbl.node.parent = this.node
        }
        let curWExl = gea.get(HMP_GameData).curCashExl
        this.moneyLbl.string = hlgame.utils.comUtil.formatNumWithComma(curWExl[this.rewardName])
    }
    //==========================================
    duration: number = 0.5;
    _median: number = 0;
    _time: number = 0;

    _material: cc.Material = null!;

    setFlash(material: cc.Material) {
        this.lineImg && this.lineImg.setMaterial(0, material)
        this.gridImg.setMaterial(0, material)
        this._median = this.duration / 2;
        this._material = material
        this._material.setProperty("u_rate", 1);

        this.doFlash()
    }

    update(dt: number) {
        if (this._time > 0) {
            this._time -= dt;

            this._time = this._time < 0 ? 0 : this._time;
            let rate = Math.abs(this._time - this._median) * 2 / this.duration;
            this._material.setProperty("u_rate", rate);
        }
    }

    doFlash() {
        this._time = this.duration;
    }

    removeFlash() {
        this.gridImg.setMaterial(0, HMP_GridCom.Material)
        this.lineImg && this.lineImg.setMaterial(0, HMP_GridCom.Material)
        this._time = 0
    }
    // update (dt) {}
    //
    updateShild(shieldIndexes: number[]) {
        if (shieldIndexes.indexOf(this.index) >= 0) {
            this.showNewShild()
        }
        else if (this.shieldImag && this.shieldImag.node.active) {
            this.shieldImag.node.active = false
        }
    }

    showNewShild() {
        if (!this.shieldImag) {
            this.shieldImag = new cc.Node().addComponent(cc.Sprite)
            this.shieldImag.sizeMode = cc.Sprite.SizeMode.RAW
            this.shieldImag.trim = false

            let arr = this.gridImg.spriteFrame.name.split('_')
            let angleIndex: number = Number(arr[arr.length - 1]);
            angleIndex = angleIndex ? angleIndex : 1

            gea.loadMgr.setSpriteFrame(`res/textures/ui/main/chessBoard/dp_` + arr[0], this.shieldImag, HMP_GameConfig.bundle)
            this.shieldImag.node.parent = this.node
            this.shieldImag.node.active = false
        }
        if (!this.shieldImag.node.active) {
            this.shieldImag.node.setScale(0)
            this.shieldImag.node.active = true
            if (!this.addShieldTween) {
                this.addShieldTween = cc.tween(this.shieldImag.node).to(0.2, { scaleX: 0.8, scaleY: 1.1 }).to(0.1, { scaleX: 1.1, scaleY: 0.9 }).to(0.1, { scaleX: 1, scaleY: 1 })
            }
            this.addShieldTween.start()
        }
    }
    eatShild() {
        if (this.shieldImag && this.shieldImag.node.active) {
            this.shieldImag.node.active = false
        }
    }
}
