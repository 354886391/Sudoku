/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2023-10-17 18:20:21
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-05-21 11:05:59
 * @FilePath: \hall-project-creator\assets\hall\src\common\HallScrollVerCtr.ts
 * @Description: 垂直 ScrollView管理
 */

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_ScrollVerCtr extends gea.abstracts.ui.ViewBase {

    @property(cc.Prefab)
    itemPrefab: cc.Prefab = null;
    @property(cc.Node)
    scrollView: cc.Node = null;
    @property(cc.Node)
    content: cc.Node = null;

    // @property
    // pageCount: number = 3;
    @property
    endAddGap: number = 150;
    @property
    gap: number = 3;
    @property
    baseY: number = 150;
    @property
    itemHeight: number = 500;
    // @property
    // itemClassName: string = "";

    // LIFE-CYCLE CALLBACKS:
    /** 当前需要显示的数量 */
    _endShowIndex: number = 0
    /** 当前已经显示的数量 */
    _starShowIndex: number = 0
    _inShowInit: boolean

    curPage: number = 0
    maxPage: number = 0
    pageCount: number = 0

    isLeaguePanel: boolean = false
    leagueUpgradeNeed: number = -1

    _itemPool: cc.Node[] = []
    _itemMap: {} = {}
    _itemList: any[] = []
    // onLoad () {}

    start() {

    }

    setDataList(list: any[]) {
        this._itemList = list

        let viewHeight: number = this.scrollView.height
        this._endShowIndex = Math.ceil(viewHeight / this.itemHeight) + 1
        this.pageCount = this._endShowIndex
        this._endShowIndex = this._endShowIndex > this._itemList.length ? this._itemList.length : this._endShowIndex

        this._starShowIndex = 0
        this._inShowInit = true
        this.content.height = this._itemList.length * (this.itemHeight + this.gap) + this.endAddGap
        this.maxPage = (this._itemList.length - this._endShowIndex) + 1

        this.curPage = -1
        this.lateUpdate(null)
    }

    lateUpdate(dt) {
        if (this._starShowIndex < this._endShowIndex && this._starShowIndex < this._itemList.length) {
            if (this._itemMap[this._starShowIndex] && this._itemMap[this._starShowIndex].parent) {
                this._starShowIndex++
                return
            }
            let node: cc.Node = this.getItemNode(this._starShowIndex)//cc.instantiate(this.HallShopItemComPrefab)
            node.getComponent(this.itemPrefab.name).setData(this._itemList[this._starShowIndex], this._starShowIndex)
            node.opacity = 255
            node.parent = this.content

            node.stopAllActions()
            node.y = this.baseY - this.itemHeight / 2 - this._starShowIndex * (this.itemHeight + this.gap)
            if (this.isLeaguePanel) {
                if (this.leagueUpgradeNeed > 0 && this._starShowIndex > this.leagueUpgradeNeed) {//this._itemList.indexOf(null)) {
                    node.y += 40
                }
            }
            this._itemMap[this._starShowIndex] = node
            this._starShowIndex++
            // gea.log("this.content.childrenCount   ", this.content.childrenCount)
        }
        else {
            let page: number = this.getCurPage()
            if (page != this.curPage) {

                this._starShowIndex = page - 1
                this._starShowIndex = this._starShowIndex < 0 ? 0 : this._starShowIndex
                this._endShowIndex = this._starShowIndex + this.pageCount

                for (const key in this._itemMap) {
                    if (Object.prototype.hasOwnProperty.call(this._itemMap, key)) {
                        const child = this._itemMap[key];
                        let index: number = Number(key)
                        if (child && (index < this._starShowIndex || index > this._endShowIndex)) {
                            child.parent = null
                            this._itemPool.push(child)
                            this._itemMap[index] = null
                            delete this._itemMap[index]
                        }
                    }
                }
                this.curPage = page
            }
        }
    }

    getCurPage(): number {
        let page: number = Math.floor((this.content.y - this.scrollView.height / 2 - (this.itemHeight + this.gap) / 2) / (this.itemHeight + this.gap)) + 1
        page = page >= 0 ? page : 0
        page = page > this.maxPage ? this.maxPage : page
        return page
    }

    getItemNode(index: number): cc.Node {
        if (this._itemPool.length > 0) {
            return this._itemPool.shift()
        }
        if (this._itemMap[index]) {
            return this._itemMap[index]
        }
        let node = cc.instantiate(this.itemPrefab)
        this.pushToReleaseList(node.getComponent(this.itemPrefab.name))
        return node
    }
    // update (dt) {}
}
