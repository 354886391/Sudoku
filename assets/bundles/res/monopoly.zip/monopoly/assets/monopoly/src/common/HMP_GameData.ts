
import { HMP_Exlmonopoly_baseProvider } from "../../excelData/HMP_Exlmonopoly_base"
import { HMP_Exlmonopoly_build, HMP_Exlmonopoly_buildProvider } from "../../excelData/HMP_Exlmonopoly_build"
import { HMP_Exlmonopoly_cash, HMP_Exlmonopoly_cashProvider } from "../../excelData/HMP_Exlmonopoly_cash"
import { HMP_pb } from "../../proto/HMP_pb"
import { HMP_PBEnums } from "../../proto/HMP_PBEnums"
import { HMP_Event } from "./HMP_Event"
import { HMP_GameConfig } from "./HMP_GameConfig"

/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-22 11:57:18
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-11-15 16:29:04
 * @Description: 游戏数据管理控制
 */
export default class HMP_GameData extends gea.common.GameMgrPool {

    slotInited: boolean = false
    hallData: any

    shopItemId: number = 120001
    diceItemId: number = 100301

    /** 设置类名  可以被子游戏或者其他Bundle功能所引用 */
    className: string = "HMP_GameData"

    /** 锁定骰子道具数量 ， 如果-1表示当前没有锁定，有值表示当前锁定等待飞金币 */
    lockDiceNum: number = -1

    curDiceItemNum: number = 0

    gridRwNameMap: Map<number, string> = new Map()

    callbackAfterBorrow() {
        this.slotInited = false
        this.hallData = gea.game.getByName("HallData")

        gea.net.onPrior(HMP_PBEnums.Res_MonopolyInfo, this.onMonopolyInfoRes, this)
        gea.net.onPrior(HMP_PBEnums.Res_MonopolyBuild, this.onMonopolyBuildRes, this)
        gea.net.onPrior(HMP_PBEnums.Res_MonopolyPlay, this.onMonopolyPlayRes, this)
        gea.net.on('pb.GeneralItemRes10223', this.onGeneralItemRes, this)

        gea.instance.on(HMP_Event.notice_chess_move_end, this.onChessMoveEnd, this)

        this.curDiceItemNum = this.getDiceItemNum()

        // let send = gea.net.send
        // gea.net.send = (netTag: string | number, data?: any, path?: string, roomId?: string): any => {

        //     if (netTag == HMP_PBEnums.Req_MonopolyBuild) {
        //         this.testBuild(data.Index)
        //     }
        //     return send.call(gea.net, netTag, data, path, roomId)
        // }
        // this.monopolyInfoRes = {
        //     WealthLevel: 0, Cash: 1000, ShieldNum: 1, Lattice: 0, ShieldLattice: [4, 14, 24, 35], Events: [], Grids: [],
        //     Building: [{ Id: 1, Index: 0, Level: 0, isBroken: 0 },
        //     { Id: 1, Index: 1, Level: 0, isBroken: 0 }, { Id: 1, Index: 2, Level: 0, isBroken: 0 },
        //     { Id: 1, Index: 3, Level: 0, isBroken: 0 }, { Id: 1, Index: 4, Level: 0, isBroken: 0 }]
        // }
    }

    //网络断开事件
    onDisConnect() {

    }

    // 登录成功
    onLoginSucc() {

    }

    //=====================================================================

    onChessMoveEnd() {
        this.doUpdateEventList()
        //事件执行完成。置空
        this.squareEvent = null
    }

    doUpdateEventList() {
        if (!this.squareEvent) {
            return
        }
        for (let i = 0; i < this.squareEvent.length; i++) {
            this.updateEventInfo(this.squareEvent[i])
        }
    }
    /** 处理格子事件 */
    updateEventInfo(event: HMP_pb.IMonopolyEvent) {
        if (event.AddShildNum > 0) {
            //收集护盾
            this.monopolyInfoRes.ShieldNum += event.AddShildNum

        }

        switch (event.EventType) {

            default:
                if (event.ChangeCash != 0) {
                    gea.instance.dispatch(HMP_Event.notice_collect_money, event.ChangeCash)
                }
        }
    }
    //=========================接口方法=====================================

    SendSlotInitReq() {
        gea.net.send(HMP_PBEnums.Req_MonopolyInfo)
        this.MultipleList = JSON.parse(HMP_Exlmonopoly_baseProvider.getById(1).multiple)
        // gea.instance.dispatch(HMP_Event.slot_init_event)
    }

    getDiceItemNum(): number {
        return this.hallData.getItemNum(this.diceItemId)
    }

    onGeneralItemRes() {
        let num: number = this.getDiceItemNum()
        if (this.curDiceItemNum < num) {
            this.lockDiceNum = num
        }
        else {
            this.curDiceItemNum = num
        }
    }
    /** 财富等级刷新 */
    updateWealthLevel(level: number) {
        if (level < this.monopolyInfoRes.WealthLevel) {
            //降级
            this.curCashExl = null
            this.nextCashExl = null
        }
        this.monopolyInfoRes.WealthLevel = level
        if (!this.nextCashExl || (!this.isMaxWealth && level >= this.nextCashExl.net_worth_grade)) {
            let list = HMP_Exlmonopoly_cashProvider.getAll()
            let index: number = this.curCashExl ? list.indexOf(this.curCashExl) : 0
            for (let i = index; i < list.length; i++) {
                if (list[i].net_worth_grade > level) {
                    this.curCashExl = list[i - 1]
                    this.nextCashExl = list[i]
                    //是否满级
                    this.isMaxWealth = (i == (list.length - 1))
                    //段提升
                    gea.instance.dispatch(HMP_Event.notice_worth_upgrade)
                    break
                }
            }
        }
        //等级更新
        gea.instance.dispatch(HMP_Event.notice_worth_garde)
    }

    /** 建造完成一个建筑后，检查是否场景全部搭建完成 */
    checkBuildSceneComplete() {
        if (this.monopolyInfoRes.WealthLevel % 30 == 0) {
            //整数 说明完成了一个场景了
            let nextId: number = Math.floor(this.monopolyInfoRes.WealthLevel / 30)
            if (nextId > this.monopolyInfoRes.Building[0].Id) {
                //升级更新新场景

            }
        }
    }
    /** 获取建筑消耗 */
    getExpense(index: number): number {
        let build = this.monopolyInfoRes.Building[index]
        return this.curExpense[build.Level][index]
    }
    /** 获取修复消耗 */
    getBrokenExpense(index: number): number {
        let build = this.monopolyInfoRes.Building[index]
        return this.curBrokenExpense[build.Level][index]
    }

    testBuild(Index: number) {
        let building: HMP_pb.IMonopolyBuilding = this.monopolyInfoRes.Building[Index]
        if (building.isBroken <= 0) {
            building.Level++
        }
        else {
            building.isBroken--
        }
        this.addToOnBuildList(building.Index)
        this.monopolyInfoRes.WealthLevel++
        gea.instance.dispatch(HMP_Event.notice_upgrade_building, building)
    }

    //====================================================================

    onBuildList: number[] = []
    inWaitGoToChessBoard: boolean = false


    addToOnBuildList(index: number) {
        this.onBuildList.push(index)
    }

    completeOneBuild(index: number) {
        this.onBuildList.splice(this.onBuildList.indexOf(index), 1)
        if (this.onBuildList.length <= 0) {
            gea.instance.dispatch(this.inWaitGoToChessBoard ? HMP_Event.request_go_to_chess_board : HMP_Event.request_go_to_build_scene)
            this.inWaitGoToChessBoard = false
        }
    }

    checkGotoChessBoard(): boolean {
        if (this.onBuildList.length > 0) {
            this.inWaitGoToChessBoard = true
            return false
        }
        return true
    }

    //=========================协议返回=====================================
    /** 财富等级满级 */
    isMaxWealth: boolean = false
    curCashExl: HMP_Exlmonopoly_cash

    curBuildExl: HMP_Exlmonopoly_build
    curExpense: number[]
    curBrokenExpense: number[]
    nextCashExl: HMP_Exlmonopoly_cash

    /** 当前倍数 */
    Multiple: number = 1
    MultipleList: number[]
    monopolyInfoRes: HMP_pb.MonopolyInfoRes
    /** 触发事件队列 */
    squareEvent: HMP_pb.IMonopolyEvent[]
    startEvent: HMP_pb.IMonopolyEvent = null

    onMonopolyInfoRes(res: HMP_pb.MonopolyInfoRes) {
        this.monopolyInfoRes = res
        this.updateWealthLevel(res.WealthLevel)

        this.curBuildExl = HMP_Exlmonopoly_buildProvider.getById(res.Building[0].Id)
        this.curExpense = JSON.parse(this.curBuildExl.expense)
        this.curBrokenExpense = JSON.parse(this.curBuildExl.expense)
        // if(res.Building.length < 5){
        //     let indexs:number[] = []
        //     for (let i = 0; i < array.length; i++) {
        //         const element = array[i];

        //     }
        // }

        gea.instance.dispatch(HMP_Event.slot_init_event)
    }

    onMonopolyPlayRes(res: HMP_pb.MonopolyPlayRes) {
        this.squareEvent = res.Events.concat()
        for (let i = this.squareEvent.length - 1; i >= 0; i--) {
            if (this.squareEvent[i].EventType == 100 && this.squareEvent.length > 1) {
                //起点奖励
                this.startEvent = this.squareEvent[i]
                this.squareEvent.splice(i, 1)
            }
        }
    }

    onMonopolyBuildRes(res: HMP_pb.IMonopolyBuildRes, seq: number) {
        if (res.Code == 0) {

            let req: HMP_pb.IMonopolyBuildReq = gea.net.getSendDataBySeq(seq)
            if (req) {
                // req.
                let building: HMP_pb.IMonopolyBuilding = this.monopolyInfoRes.Building[req.Index]
                if (building.isBroken <= 0) {
                    gea.instance.dispatch(HMP_Event.notice_collect_money, -this.getExpense(req.Index))
                    building.Level++
                }
                else {
                    gea.instance.dispatch(HMP_Event.notice_collect_money, -this.getBrokenExpense(req.Index))
                    building.isBroken--
                }
                this.updateWealthLevel(this.monopolyInfoRes.WealthLevel + 1)
                this.addToOnBuildList(building.Index)
                gea.instance.dispatch(HMP_Event.notice_upgrade_building, building)
            }
        }
    }

    //=========================事件返回=====================================
}
