/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 15:13:15
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2023-10-16 15:52:53
 * @Description: 弹出提示 模板测试用
 *  提示界面一般调用大厅的通用提示。 除非有特殊需求。正常用不上这个界面的话删除掉即可
 */

import { HMP_GameConfig } from "../common/HMP_GameConfig"

const { ccclass, property } = cc._decorator

@ccclass
export default class HMP_AlertPanel extends gea.abstracts.ui.OverModalBase {
    static get prefabUrl(): string {
        return 'res/prefab/ui/AlertPanel'
    }

    static get bundle(): string {
        return HMP_GameConfig.bundle
    }

    @property(cc.Label)
    descTxt: cc.Label = null

    private _hideAction = null
    private _notAuto: Boolean = false
    private _pos: any
    private _topOrDown: any

    start() {
        this._hideAction = cc.sequence(
            cc.delayTime(1),
            cc.fadeTo(0.5, 100),

            cc.callFunc(this.toClose, this),
        )
    }
    /**  tips 提示内容   notAuto 不自动关闭  pos 位置   topOrDown  1 顶部显示  2 底部显示 */
    callbackBeforeShow(tips: string, notAuto, pos) {
        this.node.y = -50
        this.node.opacity = 0
        this.descTxt.string = tips
        this.node.stopAllActions()

        this.scheduleOnce(this.onResize.bind(this), 0)

        this._notAuto = notAuto
        this._pos = pos
    }
    onResize() {
        if (this._pos) {
            this.node.setPosition(this._pos.x, this._pos.y - 50)
        } else {
            this.node.setPosition(0, -50)
        }

        this.node.runAction(
            cc.sequence(
                cc.fadeTo(0, 255),
                cc.moveTo(0.3, this._pos ? this._pos.x : 0, this.node.y + 50),
                cc.callFunc(this.toHideAction.bind(this)),
            ),
        )
    }

    toHideAction() {
        if (this._notAuto !== true) {
            this.node.stopAllActions()
            this.node.runAction(this._hideAction)
        }
    }

    toClose() {
        gea.ui.hide(HMP_AlertPanel)
        this.node.y = -50
        this.node.opacity = 255
    }
}
