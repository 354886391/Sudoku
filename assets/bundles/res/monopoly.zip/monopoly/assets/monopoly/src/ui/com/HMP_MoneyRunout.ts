/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2024-11-13 09:55:52
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-11-15 14:27:27
 * @FilePath: \monopoly\assets\monopoly\src\ui\com\HMP_MoneyRu.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_MoneyRunout extends gea.abstracts.ui.UIMoneyRunout {
    updateLabel(money: number) {
        if (!this.label) {
            return
        }

        let moneyStr: string = hlgame.utils.comUtil.formatNumWithComma(Math.floor(money))
        this.label.string = this.preStr + moneyStr + this.endStr
    }
}
