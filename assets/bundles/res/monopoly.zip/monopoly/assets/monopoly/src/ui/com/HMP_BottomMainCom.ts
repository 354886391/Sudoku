import { HMP_Event } from "../../common/HMP_Event";
import HMP_GameData from "../../common/HMP_GameData";
import HMP_MainPanel from "../HMP_MainPanel";

/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2024-11-07 12:07:18
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-11-15 16:19:46
 * @FilePath: \monopoly\assets\monopoly\src\ui\com\HMP_MainBottomCom.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_BottomMainCom extends gea.abstracts.ui.ViewBase {
    @property(cc.Node)
    startBtn: cc.Node = null;
    @property(cc.Node)
    autoNode: cc.Node = null;
    @property(cc.Node)
    goNode: cc.Node = null;
    @property(cc.Node)
    multipleTip: cc.Node = null;
    @property(cc.ProgressBar)
    bar: cc.ProgressBar = null;
    @property(cc.Label)
    barTxt: cc.Label = null;
    @property(cc.Label)
    refTxt: cc.Label = null;
    @property(cc.Label)
    multipleLbl: cc.Label = null;
    @property(cc.Label)
    multipleLbl2: cc.Label = null;
    @property(cc.Node)
    btnMultiple02: cc.Node = null;

    start() {

    }

    dataInfo: HMP_GameData
    mainCom: HMP_MainPanel
    btnTouchTime: number = 0


    /** 当前棋子回合中  */
    isOnChessRound: boolean = false

    init(mainCom: HMP_MainPanel) {
        this.dataInfo = gea.get(HMP_GameData)
        this.mainCom = mainCom
        this.startBtn.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this)
        this.startBtn.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this)
        this.startBtn.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this)

        gea.instance.on(HMP_Event.notice_need_stop_auto, this.onNeedStopAuto, this)
        gea.instance.on(HMP_Event.notice_chess_move_end, this.onChessMoveEnd, this)
        this.node.y = -gea.ui.viewPort.halfHeight

        gea.net.on('pb.GeneralItemRes10223', this.updateDiceInfo, this)
        gea.instance.on(HMP_Event.notice_worth_upgrade, this.updateDiceInfo, this)
        this.updateDiceInfo()

        this.multipleLocalSaveKey += gea.game.myUserInfo.ID
        let mulIdex: number = gea.localStorage.getItem(this.multipleLocalSaveKey)
        this.checkAndChangeMultiple(mulIdex ? mulIdex : 0)
    }

    updateDiceInfo() {
        this.barTxt.string = `${this.dataInfo.getDiceItemNum()}/${this.dataInfo.curCashExl.max_num}`
    }

    //倍数相关=============================================================================

    multipleLocalSaveKey: string = "HALL_MONOPOLY_"
    multipleTipTween: cc.Tween
    get curMultiple(): number {
        return this.dataInfo.Multiple
    }

    checkAndChangeMultiple(mulIdex: number, isClick: boolean = false) {
        let old: number = this.dataInfo.Multiple
        let list = this.dataInfo.MultipleList
        let itemNum: number = this.dataInfo.getDiceItemNum()
        if (mulIdex == null) {
            mulIdex = list.indexOf(Number(this.multipleLbl.string.replace("X", "")))
        }
        if (mulIdex == -1) {
            mulIdex = list.indexOf(old) + 1
        }
        else if (mulIdex == -2) {
            mulIdex = list.indexOf(old) - 1
        }
        mulIdex = mulIdex < 0 ? 0 : mulIdex
        if (mulIdex >= list.length) {
            mulIdex = 0
        }
        this.dataInfo.Multiple = list[mulIdex]

        if ((this.curMultiple > 1 && this.curMultiple * 5 > itemNum) ||
            (this.curMultiple > itemNum && mulIdex > 0)) {
            mulIdex = isClick ? 0 : mulIdex - 1
            this.dataInfo.Multiple = old
            this.checkAndChangeMultiple(mulIdex, isClick)
            return
        }
        this.multipleLbl.string = 'X' + this.curMultiple
        this.multipleLbl2.string = 'X' + this.curMultiple
        gea.localStorage.setItem(this.multipleLocalSaveKey, mulIdex)
        if (old != this.curMultiple && isClick) {
            if (!this.multipleTipTween) {
                this.multipleTipTween = cc.tween(this.multipleTip).to(0.3, { opacity: 255 }).delay(2).to(0.3, { opacity: 0 })
            }
            this.multipleLbl.node.parent.active = mulIdex < list.length - 1 && list[mulIdex + 1] * 5 < itemNum
            this.btnMultiple02.active = !this.multipleLbl.node.parent.active
            this.multipleTipTween.stop()
            this.multipleTipTween.start()
        }
    }

    onMultipleClick() {
        gea.instance.dispatch(HMP_Event.notice_need_stop_auto)
        if (this.isOnChessRound) {
            return
        }
        this.checkAndChangeMultiple(-1, true)

        gea.audioMgr.play('res/sound/changemul', this.bundle)
    }


    //=====================================================================================
    onTouchStart() {
        gea.log("onTouchStart ")
        if (this.autoNode.active) {
            this.autoNode.active = false
            return
        }
        if (this.isOnChessRound) {
            return
        }

        this.btnTouchTime = gea.net.serverTime
        this.goNode.active = false

        this.mainCom.doMonopolyPlayReq()
    }

    onTouchEnd() {
        this.btnTouchTime = -1
        // this.goNode.color = this.normalColor
    }

    update(dt) {
        if (this.btnTouchTime > 0) {
            if (this.btnTouchTime + 1500 < gea.net.serverTime) {
                this.btnTouchTime = -1
                this.autoNode.active = true
            }
        }
    }


    frameTime: number = 0.016
    showTween: cc.Tween
    hideTween: cc.Tween

    show() {
        if (!this.showTween) {
            this.showTween = cc.tween(this.node).delay(1).to(this.frameTime * 3, { y: -gea.ui.viewPort.halfHeight })
        }
        this.showTween.start()
    }

    hide() {
        if (!this.hideTween) {
            this.hideTween = cc.tween(this.node).to(this.frameTime * 3, { y: -gea.ui.viewPort.halfHeight - 500 })
        }
        this.hideTween.start()
    }


    onNeedStopAuto() {
        this.autoNode.active = false
        if (!this.isOnChessRound) {
            this.btnTouchTime = -1
            this.goNode.active = true
        }
    }

    onChessMoveEnd() {
        this.btnTouchTime = -1
        this.goNode.active = true

        //自动
        if (this.autoNode.active) {
            this.goNode.active = false
            this.mainCom.doMonopolyPlayReq()
        }
        else {
            this.isOnChessRound = false
        }
    }


    onCardClick() {
        gea.instance.dispatch(HMP_Event.notice_need_stop_auto)
        if (this.isOnChessRound) {
            return
        }
        // this.mainCom.getRectInChessBoard()
        gea.net.send('pb.SlotGmHallReq10203', { CmdId: 9, CmdString: "h|additem|100301|10" })
    }

    onBuildClick() {
        gea.instance.dispatch(HMP_Event.notice_need_stop_auto)
        if (this.isOnChessRound) {
            return
        }
        this.mainCom.onGotoBuildScene()
        this.mainCom.bottomCtl.hide()
        this.mainCom.buildBottomCtl.show()
    }
}
