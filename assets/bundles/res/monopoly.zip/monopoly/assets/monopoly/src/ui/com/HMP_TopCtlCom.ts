// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { HMP_Exlmonopoly_cash } from "../../../excelData/HMP_Exlmonopoly_cash";
import { HMP_Event } from "../../common/HMP_Event";
import HMP_GameData from "../../common/HMP_GameData";
import HMP_MoneyRunout from "./HMP_MoneyRunout";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_TopCtlCom extends gea.abstracts.ui.ViewBase {

    @property(cc.ProgressBar)
    bar: cc.ProgressBar = null;
    @property(cc.Label)
    numTxt: cc.Label = null;
    @property(HMP_MoneyRunout)
    moneyRount: HMP_MoneyRunout = null;

    @property(cc.Node)
    shieldCont: cc.Node = null;
    @property(cc.Node)
    buildCont: cc.Node = null;
    @property(cc.Label)
    newBuildTxt: cc.Label = null;


    // LIFE-CYCLE CALLBACKS:
    shieldList: cc.Node[] = []
    showShieldContTween: cc.Tween
    hideShieldContTween: cc.Tween

    showBuildInfoTween: cc.Tween
    hideBuildInfoTween: cc.Tween
    // onLoad () {}

    start() {
        this.shieldList.push(this.shieldCont.children[0])

        gea.instance.on(HMP_Event.notice_collect_money, this.onMoneyChange, this)
    }

    updateInfo() {
        let curCashExl: HMP_Exlmonopoly_cash = gea.get(HMP_GameData).curCashExl
        let nextCashExl: HMP_Exlmonopoly_cash = gea.get(HMP_GameData).nextCashExl

        let WealthLevel = gea.get(HMP_GameData).monopolyInfoRes.WealthLevel
        this.numTxt.string = hlgame.utils.comUtil.getUnitedNumStr(WealthLevel)
        this.bar.progress = WealthLevel / nextCashExl.net_worth_grade

        this.moneyRount.setMoney(gea.get(HMP_GameData).monopolyInfoRes.Cash, 1)

        this.updateShieldInfo()

        this.hideShieldContTween = cc.tween(this.shieldCont).delay(1).to(0.3, { opacity: 0 })
        this.showShieldContTween = cc.tween(this.shieldCont).delay(1).to(0.3, { opacity: 255 })
        this.hideBuildInfoTween = cc.tween(this.buildCont).delay(1).to(0.3, { opacity: 0 })
        this.showBuildInfoTween = cc.tween(this.buildCont).delay(1).to(0.3, { opacity: 255 })
    }

    onMoneyChange(money: number) {
        gea.get(HMP_GameData).monopolyInfoRes.Cash += money
        this.moneyRount.setMoney(gea.get(HMP_GameData).monopolyInfoRes.Cash, 1)
    }

    updateShieldInfo() {
        let curCashExl: HMP_Exlmonopoly_cash = gea.get(HMP_GameData).curCashExl

        if (this.shieldList.length != curCashExl.shields_max_num) {
            while (this.shieldList.length > curCashExl.shields_max_num) {
                this.shieldList.shift().parent = null
            }
            let shield: cc.Node = null
            while (curCashExl.shields_max_num > this.shieldList.length) {
                shield = cc.instantiate(this.shieldList[0])
                shield.parent = this.shieldCont
                this.shieldList.push(shield)
            }

            let gap: number = 250 - curCashExl.shields_max_num * 62
            this.shieldCont.getComponent(cc.Layout).spacingX = Math.min(5, gap / (curCashExl.shields_max_num - 1))
            this.shieldCont.getComponent(cc.Layout).updateLayout()
        }

        let shieldNum: number = gea.get(HMP_GameData).monopolyInfoRes.ShieldNum
        for (let i = 0; i < this.shieldList.length; i++) {
            this.shieldList[i].children[0].active = shieldNum > i
        }
    }

    onGotoChessBoard() {
        this.hideBuildInfoTween.start()
        this.showShieldContTween.start()
    }

    onGotoBuildScene() {
        this.newBuildTxt.string = "0"
        this.hideShieldContTween.start()
        this.showBuildInfoTween.start()
    }


    onEnumClick() {
        gea.game.goBackToHall()
    }
    // update (dt) {}
}
