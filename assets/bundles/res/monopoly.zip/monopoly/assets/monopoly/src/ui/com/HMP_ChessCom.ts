/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2024-11-05 16:38:43
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-11-06 10:56:45
 * @FilePath: \monopoly\assets\monopoly\src\ui\com\HMP_ChessCom.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { HMP_GameConfig } from "../../common/HMP_GameConfig";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_ChessCom extends gea.abstracts.ui.ViewBase {

    @property(cc.Label)
    label: cc.Label = null;

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start() {

    }

    qtJumpPosition(pos: cc.Vec3, height: number, jumps: number, duration: number, callBcak: Function) {
        this.node.stopAllActions()
        let jumpTo = cc.jumpTo(duration, cc.v2(pos.x, pos.y), height, jumps)
        cc.tween(this.node).then(jumpTo).call(callBcak).start()
    }

    @property(cc.Sprite)
    chessImg: cc.Sprite = null!;

    chessName: string = '1'
    setChessData() {

    }

    posList: cc.Vec3[] = [cc.v3(8, 64, 0), cc.v3(-8, 64, 0), cc.v3(6, 59, 0), cc.v3(22, 50, 0)]
    curGapPos: cc.Vec3 = cc.Vec3.ZERO
    curChessUrl: string = ""
    posType: number = 1
    setNextGrid(nextGrid: cc.Node) {
        let nextPos = nextGrid.position
        let curPos = this.node.position

        let url: string = ''
        if (nextPos.x < curPos.x && nextPos.y < curPos.y) {
            url = "4"
            this.posType = 4
            this.curGapPos = this.posList[3]
        }
        else if (nextPos.x < curPos.x && nextPos.y > curPos.y) {
            url = "3"
            this.posType = 3
            this.curGapPos = this.posList[2]
        }
        else if (nextPos.x > curPos.x && nextPos.y > curPos.y) {
            url = "2"
            this.posType = 2
            this.curGapPos = this.posList[1]
        }
        else {
            url = "1"
            this.posType = 1
            this.curGapPos = this.posList[0]

        }
        this.chessImg.node.setPosition(this.curGapPos)
        if (this.curChessUrl != url) {
            this.curChessUrl = url

            gea.loadMgr.setSpriteFrame(`res/textures/ui/chess/${this.chessName}/${this.curChessUrl}`, this.chessImg, HMP_GameConfig.bundle)
        }
    }

    playMove() {
        // this.ani.play()
    }

    update(deltaTime: number) {

    }

    isTouch: boolean = false
    onTouchStart() {
        this.isTouch = true
    }

    // update (dt) {}
}
