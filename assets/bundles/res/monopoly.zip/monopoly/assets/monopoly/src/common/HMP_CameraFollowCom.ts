/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2024-11-05 16:47:34
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-11-14 11:29:54
 * @FilePath: \monopoly\assets\monopoly\src\common\HMP_CameraFollowCom.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

const { ccclass, property } = cc._decorator;

@ccclass
export class HMP_CameraFollowCom extends cc.Component {

    isOnMove: boolean = false

    private _target: cc.Node;
    public get target(): cc.Node {
        return this._target;
    }
    public set target(value: cc.Node) {
        this._target = value;
    }

    mapHeight: number = 2560
    mapWidth: number = 1920
    buildMapHeight: number = 3720

    maxPosX: number = 0
    minPosX: number = 0
    maxPosY: number = 0
    minPosY: number = 0

    maxPosX2: number = 0
    minPosX2: number = 0
    maxPosY2: number = 0
    minPosY2: number = 0

    basePostion: cc.Vec2

    /** 是否在城建界面 */
    isInBuildCont: boolean = false
    buildContPosY: number = 0

    start() {
    }

    init() {

        this.minPosY = this.mapHeight > gea.ui.viewPort.height ? -(this.mapHeight - gea.ui.viewPort.height) / 2 : 0
        this.maxPosY = this.mapHeight > gea.ui.viewPort.height ? 130 : 0

        this.minPosX = this.mapWidth > gea.ui.viewPort.width ? -(this.mapWidth - gea.ui.viewPort.width) / 2 : 0
        this.maxPosX = this.mapWidth > gea.ui.viewPort.width ? (this.mapWidth - gea.ui.viewPort.width) / 2 : 0

        this.minPosY2 = this.mapHeight > gea.ui.viewPort.height ? -(this.mapHeight - gea.ui.viewPort.height) / 2 - 60 : 0
        this.maxPosY2 = this.mapHeight > gea.ui.viewPort.height ? 200 : 0

        this.minPosX2 = this.mapWidth > gea.ui.viewPort.width ? -(this.mapWidth - gea.ui.viewPort.width) / 2 : 0
        this.maxPosX2 = this.mapWidth > gea.ui.viewPort.width ? (this.mapWidth - gea.ui.viewPort.width) / 2 : 0

        this.basePostion = this.node.convertToNodeSpaceAR(cc.v2(gea.ui.viewPort.width / 2, gea.ui.viewPort.height / 2))

        gea.log(this)
    }

    checkPosition(relPos: cc.Vec2 | cc.Vec3, scale: number = 1) {
        let gapW: number = (this.mapWidth * scale - this.mapWidth) / 2
        let gapH: number = (this.mapHeight * scale - this.mapHeight) / 2
        relPos.x = Math.min(relPos.x - gapW, this.maxPosX - gapW)
        relPos.x = Math.max(relPos.x + gapW, this.minPosX + gapW)

        if (this.isInBuildCont) {
            relPos.y = relPos.y - gapH
        }
        else {
            relPos.y = Math.min(relPos.y - gapH, this.maxPosY - gapH)
            relPos.y = Math.max(relPos.y + gapH, this.minPosY + gapH)
        }
    }

    checkPosition2(relPos: cc.Vec2 | cc.Vec3) {
        relPos.x = Math.min(relPos.x, this.maxPosX2)
        relPos.x = Math.max(relPos.x, this.minPosX2)

        relPos.y = Math.min(relPos.y, this.maxPosY2)
        relPos.y = Math.max(relPos.y, this.minPosY2)
    }

    /** 缓动到下一个棋子坐标点 */
    moveToNextPosition(nextPos: cc.Vec2, jumpTime: number) {

        let relPos: cc.Vec2 = cc.v2(this.basePostion.x - nextPos.x, this.basePostion.y - nextPos.y)

        this.checkPosition(relPos)
        this.node.stopAllActions()
        cc.tween(this.node).to(jumpTime, { x: relPos.x, y: relPos.y }).start()
    }
    /** 滑动到建筑界面 */
    moveToBuildScene(pos?: cc.Vec2, jumpTime: number = 1) {
        this.isInBuildCont = true
        let relPos: cc.Vec2 = cc.v2(this.basePostion.x - pos.x, this.basePostion.y - pos.y)
        this.node.stopAllActions()
        cc.tween(this.node).to(jumpTime, { x: relPos.x, y: relPos.y, scale: 1 }, cc.easeCubicActionIn()).start()
        this.buildContPosY = pos.y
    }
    /** 滑动到棋盘界面 */
    moveToChessBoard(jumpTime: number = 1, scale: number = 1) {
        this.isInBuildCont = false
        let relPos: cc.Vec2 = cc.v2(this.basePostion.x - this.target.x, this.basePostion.y - this.target.y)
        this.checkPosition(relPos)
        this.node.stopAllActions()
        cc.tween(this.node).to(jumpTime, { x: relPos.x, y: relPos.y, scale: scale }, cc.easeCubicActionIn()).start()
    }
    /** 初始化更新位置 */
    onUpdateCamera() {
        let relPos: cc.Vec2 = cc.v2(this.basePostion.x - this.target.x, this.basePostion.y - this.target.y)
        this.checkPosition(relPos)
        this.node.setPosition(relPos)
    }
    /** 鼠标拖动地图 */
    doTouchMoveCamera(gapx: number, gapy: number) {
        let pos = this.node.getPosition()

        let relPos: cc.Vec2 = cc.v2(pos.x + gapx, pos.y + gapy)
        this.checkPosition2(relPos)
        this.node.setPosition(relPos)
    }
    /** 停止拖动放开 */
    doTouchMoveEnd() {
        let relPos = this.node.getPosition()
        this.checkPosition(relPos)
        this.node.stopAllActions()
        cc.tween(this.node).to(0.2, { x: relPos.x, y: relPos.y }).start()
    }

    /** 镜头移动盯住某个位置  */
    doLookAt(pos: cc.Vec2, scale: number = 1.2) {
        let relPos: cc.Vec2 = cc.v2(this.basePostion.x - pos.x, this.basePostion.y - pos.y)
        relPos.x = relPos.x * scale
        relPos.y = relPos.y * scale
        this.node.stopAllActions()
        cc.tween(this.node).to(0.3, { x: relPos.x, y: relPos.y, scale: scale }, cc.easeCubicActionIn()).start()
    }
}
