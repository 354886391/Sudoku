import { HMP_pb } from "../../../proto/HMP_pb";
import { HMP_Event } from "../../common/HMP_Event";
import HMP_GameData from "../../common/HMP_GameData";
import HMP_MainPanel from "../HMP_MainPanel";
import HMP_BuildIngCom from "./HMP_BuildIngCom";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_BuildContCom extends gea.abstracts.ui.ViewBase {

    @property(cc.Prefab)
    buildIngPrefab: cc.Prefab = null;
    mainCom: HMP_MainPanel

    posList: cc.Vec2[] = [cc.v2(-318, -514 + 223), cc.v2(-314, 135 + 223), cc.v2(39, -166 + 223), cc.v2(326, 258 + 223), cc.v2(335, -565 + 223)]
    buildIngList: HMP_BuildIngCom[] = []

    start() {
        gea.instance.on(HMP_Event.notice_upgrade_building, this.onUpgradeBuilding, this)
    }

    init(mainCom: HMP_MainPanel) {
        this.mainCom = mainCom

        let list = gea.get(HMP_GameData).monopolyInfoRes.Building
        let item: cc.Node
        for (let i = 0; i < this.posList.length; i++) {
            item = cc.instantiate(this.buildIngPrefab)
            item.parent = this.node
            item.setPosition(this.posList[i])
            this.buildIngList.push(item.getComponent(HMP_BuildIngCom))
            this.buildIngList[i].setData(list[i])
        }
    }

    onUpgradeBuilding(build: HMP_pb.IMonopolyBuilding) {
        this.buildIngList[build.Index].doBuild(build)
        //移动镜头
        let pos = this.buildIngList[build.Index].node.getPosition()
        this.mainCom.cameraFollow.doLookAt(cc.v2(this.node.x + pos.x, this.node.y + pos.y), 1.5)
    }

    onBuildClick(event) {
        let target = event.target
        let pos = target.getPosition()

        this.mainCom.cameraFollow.doLookAt(cc.v2(this.node.x + pos.x, this.node.y + pos.y), 1.5)
    }
}
