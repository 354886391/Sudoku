/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-16 10:52:21
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2023-03-08 17:28:43
 * @Description: 自动转换多语言图片资源，挂载在 图片的cc.Node上
 */

import { HMP_GameConfig } from "./HMP_GameConfig"

const { ccclass, property } = cc._decorator
// 自动转换多语言图片
@ccclass
export default class HMP_LangTranPic extends gea.abstracts.ui.ViewBase {

    @property({ tooltip: '多语言表中的ID字段' })
    picNameTxt: string = ''
    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        this.bundle = HMP_GameConfig.bundle
        if (this.picNameTxt == null || this.picNameTxt === '') {
            this.picNameTxt = this.node.name
        }
        gea.language.tranPicTxt(this.bundle, this.picNameTxt, this.node)
    }

    // update (dt) {}
}
