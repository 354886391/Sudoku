/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-16 10:52:21
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2023-03-08 17:29:58
 * @Description: 自动转换多语言文本，挂载在文本的Node上
 */

import { HMP_GameConfig } from "./HMP_GameConfig"

const { ccclass, property } = cc._decorator
// 自动转换多语言文本
@ccclass
export default class HMP_LangTranStr extends gea.abstracts.ui.ViewBase  {

    @property({ tooltip: '多语言表中的ID字段' })
    keyName: string = ''

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        this.bundle = HMP_GameConfig.bundle
        if (this.keyName == null || this.keyName === '') {
            this.keyName = this.node.name
        }
        gea.language.tranStringTxt(this.bundle, this.keyName, this.node)
    }

    // update (dt) {}
}
