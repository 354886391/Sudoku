/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2024-11-07 10:25:12
 * @LastEditors: dx lzx0513@qq.com
 * @LastEditTime: 2024-11-15 15:00:53
 * @FilePath: \monopoly\assets\monopoly\src\ui\com\HMP_BuildClickCom.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { HMP_Exlmonopoly_build, HMP_Exlmonopoly_buildProvider } from "../../../excelData/HMP_Exlmonopoly_build";
import { HMP_pb } from "../../../proto/HMP_pb";
import { HMP_PBEnums } from "../../../proto/HMP_PBEnums";
import { HMP_GameConfig } from "../../common/HMP_GameConfig";
import HMP_GameData from "../../common/HMP_GameData";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HMP_BuildClickCom extends gea.abstracts.ui.ViewBase {
    @property(cc.Button)
    btn: cc.Button = null;
    @property(cc.Label)
    prizeTxt: cc.Label = null;
    @property(cc.Sprite)
    image: cc.Sprite = null;

    // LIFE-CYCLE CALLBACKS:

    index: number = 1

    dotBuleList: cc.Node[] = []
    dotRedList: cc.Node[] = []

    fixNode: cc.Node
    fixBg: cc.Node
    completeMak: cc.Node

    curData: HMP_pb.IMonopolyBuilding
    curExl: HMP_Exlmonopoly_build
    curLevel: number = 0
    expense: number[] = []
    brokenExpense: number[] = []

    onLoad() {
        for (let i = 1; i <= 6; i++) {
            this.dotBuleList.push(cc.find("pointNode/bule0" + i, this.node))
        }
        this.dotRedList.push(cc.find("pointNode/dotRed", this.node))
        this.dotRedList.push(cc.find("pointNode/dotRed2", this.node))
        this.fixNode = cc.find("fixNode", this.node)
        this.fixBg = cc.find("bg_card", this.node)
        this.completeMak = cc.find("complete", this.node)
        this.bundle = HMP_GameConfig.bundle
    }

    setData(data: HMP_pb.IMonopolyBuilding) {
        if (!this.curData || this.curLevel != data.Level) {
            for (let i = 0; i < this.dotBuleList.length; i++) {
                this.dotBuleList[i].active = false
            }
            this.dotRedList[0].active = false
            this.dotRedList[1].active = false

            this.curLevel = data.Level
            this.index = data.Index
            this.curExl = HMP_Exlmonopoly_buildProvider.getById(data.Id)
            this.expense = JSON.parse(this.curExl.expense)
            this.brokenExpense = JSON.parse(this.curExl.expense)
            gea.loadMgr.setSpriteFrame(`res/textures/map/build/${this.curExl.res}/${this.index + 1}/` + (data.Level < 5 ? data.Level + 1 : data.Level), this.image, HMP_GameConfig.bundle, () => {
                // this.image.sizeMode = cc.Sprite.SizeMode.RAW
                // this.image.trim = false
                // @ts-ignore 私有方法
                this.image._applySpriteFrame()
                let scale: number = Math.min(180 / this.image.node.width, 160 / this.image.node.height)
                this.image.node.scale = scale
            })
        }

        this.curData = data
        for (let i = 0; i < this.curData.Level; i++) {
            this.dotBuleList[i].active = true
        }

        if (this.curData.isBroken > 0) {
            for (let i = 0; i < this.curData.isBroken; i++) {
                this.dotRedList[i].active = true
                this.dotRedList[i].x = this.dotBuleList[this.curData.Level - 1 - i].x
            }
            this.prizeTxt.string = this.brokenExpense[this.curData.Level][this.index]
            this.fixNode.active = true
            this.fixBg.active = true
        }
        else {
            this.prizeTxt.string = this.expense[this.curData.Level] ? this.expense[this.curData.Level][this.index] : "0"
            this.fixNode.active = false
            this.fixBg.active = false
            this.prizeTxt.node.parent.active = this.curData.Level < this.dotBuleList.length

        }
        this.completeMak.active = !this.prizeTxt.node.parent.active
        this.btn.interactable = !this.completeMak.active
    }

    buildComplete() {
        this.setData(this.curData)
        this.btn.interactable = true
        gea.get(HMP_GameData).completeOneBuild(this.index)
    }


    onClick() {
        this.btn.interactable = false
        gea.net.send(HMP_PBEnums.Req_MonopolyBuild, { Id: this.curData.Id, Index: this.curData.Index })
        gea.timer.once(2000, this.buildComplete, this)
    }
    // update (dt) {}
}
