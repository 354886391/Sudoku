/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2023-01-14 09:48:46
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-11-15 14:16:36
 * @Description: 子游戏内事件名定义
 */
export enum HMP_Event {
    /**初始化数据 */
    slot_init_event = "slot_init_event",
    /**初始化数据失败 */
    slot_init_failed = "slot_init_failed",
    /** 棋子行走结束 */
    notice_chess_move_end = 'HMP_Event.notice_chess_move_end',
    /** 停止自动 */
    notice_need_stop_auto = 'HMP_Event.notice_need_stop_auto',
    /** 升级建筑 */
    notice_upgrade_building = "HMP_Event.notice_upgrade_building",
    /** 格子加减钱 带增加的钱，如果扣钱 则是负数 */
    notice_collect_money = "HMP_Event.notice_collect_money",
    /** 收集护盾 */
    notice_collect_shield = "HMP_Event.notice_collect_shield",

    /** 请求返回棋盘界面 */
    request_go_to_chess_board = "HMP_Event.request_go_to_chess_board",
    /** 请求进入建筑场景 */
    request_go_to_build_scene = "HMP_Event.request_go_to_build_scene",
    /** 更新财富等级 */
    notice_worth_garde = "HMP_Event.notice_worth_garde",
    /** 财富等级段提升 */
    notice_worth_upgrade = "HMP_Event.notice_worth_upgrade",
}

