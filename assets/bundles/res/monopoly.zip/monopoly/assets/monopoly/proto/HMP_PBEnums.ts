/** generate by parseMessage.py, do not moidfy */
import { HMP_pb } from './HMP_pb'
export abstract class HMP_PBEnums {
    /** proto/monopoly.proto */
    static readonly Req_MonopolyInfo: string = 'pb.MonopolyInfoReq11500'
    static readonly Res_MonopolyInfo: string = 'pb.MonopolyInfoRes11500'
    static readonly Req_MonopolyPlay: string = 'pb.MonopolyPlayReq11501'
    static readonly Res_MonopolyPlay: string = 'pb.MonopolyPlayRes11501'
    static readonly Req_MonopolyBuild: string = 'pb.MonopolyBuildReq11502'
    static readonly Res_MonopolyBuild: string = 'pb.MonopolyBuildRes11502'
    static readonly Req_GetDiceByHour: string = 'pb.GetDiceByHourReq11503'
    static readonly Res_GetDiceByHour: string = 'pb.GetDiceByHourRes11503'
    // mapping
    static readonly Mapping = {
        'pb.MonopolyInfoReq11500': { parser: HMP_pb.MonopolyInfoReq, msgCode: 11500 },
        'pb.MonopolyInfoRes11500': { parser: HMP_pb.MonopolyInfoRes, msgCode: 11500 },
        'pb.MonopolyPlayReq11501': { parser: HMP_pb.MonopolyPlayReq, msgCode: 11501 },
        'pb.MonopolyPlayRes11501': { parser: HMP_pb.MonopolyPlayRes, msgCode: 11501 },
        'pb.MonopolyBuildReq11502': { parser: HMP_pb.MonopolyBuildReq, msgCode: 11502 },
        'pb.MonopolyBuildRes11502': { parser: HMP_pb.MonopolyBuildRes, msgCode: 11502 },
        'pb.GetDiceByHourReq11503': { parser: HMP_pb.GetDiceByHourReq, msgCode: 11503 },
        'pb.GetDiceByHourRes11503': { parser: HMP_pb.GetDiceByHourRes, msgCode: 11503 },
    }
    // CodeMapping
    static readonly CodeMapping = {
        [11500]: 'pb.MonopolyInfoRes11500',
        [11501]: 'pb.MonopolyPlayRes11501',
        [11502]: 'pb.MonopolyBuildRes11502',
        [11503]: 'pb.GetDiceByHourRes11503',
    }
}
