/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars*/
"use strict";

var $protobuf = gea.net.protobufjs || require("protobufjs/minimal");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;

// Exported root namespace
var $root = $protobuf.roots.protobuf || ($protobuf.roots.protobuf = {});

$root.HMP_pb = (function() {

    /**
     * Namespace HMP_pb.
     * @exports pb
     * @namespace
     */
    var HMP_pb = {};

    HMP_pb.MonopolyGrid = (function() {

        /**
         * Properties of a MonopolyGrid.
         * @memberof pb
         * @interface IMonopolyGrid
         * @property {number|null} [Lattice] MonopolyGrid Lattice
         * @property {number|null} [Level] MonopolyGrid Level
         */

        /**
         * Constructs a new MonopolyGrid.
         * @memberof pb
         * @classdesc Represents a MonopolyGrid.
         * @implements IMonopolyGrid
         * @constructor
         * @param {HMP_pb.IMonopolyGrid=} [properties] Properties to set
         */
        function MonopolyGrid(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyGrid Lattice.
         * @member {number} Lattice
         * @memberof HMP_pb.MonopolyGrid
         * @instance
         */
        MonopolyGrid.prototype.Lattice = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyGrid Level.
         * @member {number} Level
         * @memberof HMP_pb.MonopolyGrid
         * @instance
         */
        MonopolyGrid.prototype.Level = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * Creates a new MonopolyGrid instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyGrid
         * @static
         * @param {HMP_pb.IMonopolyGrid=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyGrid} MonopolyGrid instance
         */
        MonopolyGrid.create = function create(properties) {
            return new MonopolyGrid(properties);
        };

        /**
         * Encodes the specified MonopolyGrid message. Does not implicitly {@link HMP_pb.MonopolyGrid.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyGrid
         * @static
         * @param {HMP_pb.IMonopolyGrid} message MonopolyGrid message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyGrid.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.Lattice != null && message.hasOwnProperty("Lattice"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.Lattice);
            if (message.Level != null && message.hasOwnProperty("Level"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.Level);
            return writer;
        };

        /**
         * Decodes a MonopolyGrid message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyGrid
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyGrid} MonopolyGrid
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyGrid.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyGrid();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.Lattice = reader.int64();
                    break;
                case 2:
                    message.Level = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyGrid;
    })();

    HMP_pb.MonopolyEvent = (function() {

        /**
         * Properties of a MonopolyEvent.
         * @memberof pb
         * @interface IMonopolyEvent
         * @property {number|null} [EventType] MonopolyEvent EventType
         * @property {number|null} [ChangeCash] MonopolyEvent ChangeCash
         * @property {number|null} [PrisonRollNum] MonopolyEvent PrisonRollNum
         * @property {number|null} [AddShildNum] MonopolyEvent AddShildNum
         */

        /**
         * Constructs a new MonopolyEvent.
         * @memberof pb
         * @classdesc Represents a MonopolyEvent.
         * @implements IMonopolyEvent
         * @constructor
         * @param {HMP_pb.IMonopolyEvent=} [properties] Properties to set
         */
        function MonopolyEvent(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyEvent EventType.
         * @member {number} EventType
         * @memberof HMP_pb.MonopolyEvent
         * @instance
         */
        MonopolyEvent.prototype.EventType = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyEvent ChangeCash.
         * @member {number} ChangeCash
         * @memberof HMP_pb.MonopolyEvent
         * @instance
         */
        MonopolyEvent.prototype.ChangeCash = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyEvent PrisonRollNum.
         * @member {number} PrisonRollNum
         * @memberof HMP_pb.MonopolyEvent
         * @instance
         */
        MonopolyEvent.prototype.PrisonRollNum = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyEvent AddShildNum.
         * @member {number} AddShildNum
         * @memberof HMP_pb.MonopolyEvent
         * @instance
         */
        MonopolyEvent.prototype.AddShildNum = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * Creates a new MonopolyEvent instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyEvent
         * @static
         * @param {HMP_pb.IMonopolyEvent=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyEvent} MonopolyEvent instance
         */
        MonopolyEvent.create = function create(properties) {
            return new MonopolyEvent(properties);
        };

        /**
         * Encodes the specified MonopolyEvent message. Does not implicitly {@link HMP_pb.MonopolyEvent.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyEvent
         * @static
         * @param {HMP_pb.IMonopolyEvent} message MonopolyEvent message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyEvent.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.EventType != null && message.hasOwnProperty("EventType"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.EventType);
            if (message.ChangeCash != null && message.hasOwnProperty("ChangeCash"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.ChangeCash);
            if (message.PrisonRollNum != null && message.hasOwnProperty("PrisonRollNum"))
                writer.uint32(/* id 3, wireType 0 =*/24).int64(message.PrisonRollNum);
            if (message.AddShildNum != null && message.hasOwnProperty("AddShildNum"))
                writer.uint32(/* id 4, wireType 0 =*/32).int64(message.AddShildNum);
            return writer;
        };

        /**
         * Decodes a MonopolyEvent message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyEvent
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyEvent} MonopolyEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyEvent.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyEvent();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.EventType = reader.int64();
                    break;
                case 2:
                    message.ChangeCash = reader.int64();
                    break;
                case 3:
                    message.PrisonRollNum = reader.int64();
                    break;
                case 4:
                    message.AddShildNum = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyEvent;
    })();

    HMP_pb.MonopolyInfoReq = (function() {

        /**
         * Properties of a MonopolyInfoReq.
         * @memberof pb
         * @interface IMonopolyInfoReq
         */

        /**
         * Constructs a new MonopolyInfoReq.
         * @memberof pb
         * @classdesc Represents a MonopolyInfoReq.
         * @implements IMonopolyInfoReq
         * @constructor
         * @param {HMP_pb.IMonopolyInfoReq=} [properties] Properties to set
         */
        function MonopolyInfoReq(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * Creates a new MonopolyInfoReq instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyInfoReq
         * @static
         * @param {HMP_pb.IMonopolyInfoReq=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyInfoReq} MonopolyInfoReq instance
         */
        MonopolyInfoReq.create = function create(properties) {
            return new MonopolyInfoReq(properties);
        };

        /**
         * Encodes the specified MonopolyInfoReq message. Does not implicitly {@link HMP_pb.MonopolyInfoReq.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyInfoReq
         * @static
         * @param {HMP_pb.IMonopolyInfoReq} message MonopolyInfoReq message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyInfoReq.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            return writer;
        };

        /**
         * Decodes a MonopolyInfoReq message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyInfoReq
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyInfoReq} MonopolyInfoReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyInfoReq.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyInfoReq();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyInfoReq;
    })();

    HMP_pb.MonopolyInfoRes = (function() {

        /**
         * Properties of a MonopolyInfoRes.
         * @memberof pb
         * @interface IMonopolyInfoRes
         * @property {number|null} [WealthLevel] MonopolyInfoRes WealthLevel
         * @property {number|null} [Cash] MonopolyInfoRes Cash
         * @property {number|null} [ShieldNum] MonopolyInfoRes ShieldNum
         * @property {number|null} [Lattice] MonopolyInfoRes Lattice
         * @property {number|null} [Countdown] MonopolyInfoRes Countdown
         * @property {Array.<number>|null} [ShieldLattice] MonopolyInfoRes ShieldLattice
         * @property {Array.<HMP_pb.IMonopolyEvent>|null} [Events] MonopolyInfoRes Events
         * @property {Array.<HMP_pb.IMonopolyGrid>|null} [Grids] MonopolyInfoRes Grids
         * @property {Array.<HMP_pb.IMonopolyBuilding>|null} [Building] MonopolyInfoRes Building
         */

        /**
         * Constructs a new MonopolyInfoRes.
         * @memberof pb
         * @classdesc Represents a MonopolyInfoRes.
         * @implements IMonopolyInfoRes
         * @constructor
         * @param {HMP_pb.IMonopolyInfoRes=} [properties] Properties to set
         */
        function MonopolyInfoRes(properties) {
            this.ShieldLattice = [];
            this.Events = [];
            this.Grids = [];
            this.Building = [];
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyInfoRes WealthLevel.
         * @member {number} WealthLevel
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.WealthLevel = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyInfoRes Cash.
         * @member {number} Cash
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.Cash = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyInfoRes ShieldNum.
         * @member {number} ShieldNum
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.ShieldNum = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyInfoRes Lattice.
         * @member {number} Lattice
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.Lattice = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyInfoRes Countdown.
         * @member {number} Countdown
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.Countdown = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyInfoRes ShieldLattice.
         * @member {Array.<number>} ShieldLattice
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.ShieldLattice = $util.emptyArray;

        /**
         * MonopolyInfoRes Events.
         * @member {Array.<HMP_pb.IMonopolyEvent>} Events
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.Events = $util.emptyArray;

        /**
         * MonopolyInfoRes Grids.
         * @member {Array.<HMP_pb.IMonopolyGrid>} Grids
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.Grids = $util.emptyArray;

        /**
         * MonopolyInfoRes Building.
         * @member {Array.<HMP_pb.IMonopolyBuilding>} Building
         * @memberof HMP_pb.MonopolyInfoRes
         * @instance
         */
        MonopolyInfoRes.prototype.Building = $util.emptyArray;

        /**
         * Creates a new MonopolyInfoRes instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyInfoRes
         * @static
         * @param {HMP_pb.IMonopolyInfoRes=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyInfoRes} MonopolyInfoRes instance
         */
        MonopolyInfoRes.create = function create(properties) {
            return new MonopolyInfoRes(properties);
        };

        /**
         * Encodes the specified MonopolyInfoRes message. Does not implicitly {@link HMP_pb.MonopolyInfoRes.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyInfoRes
         * @static
         * @param {HMP_pb.IMonopolyInfoRes} message MonopolyInfoRes message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyInfoRes.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.WealthLevel != null && message.hasOwnProperty("WealthLevel"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.WealthLevel);
            if (message.Cash != null && message.hasOwnProperty("Cash"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.Cash);
            if (message.ShieldNum != null && message.hasOwnProperty("ShieldNum"))
                writer.uint32(/* id 3, wireType 0 =*/24).int64(message.ShieldNum);
            if (message.Lattice != null && message.hasOwnProperty("Lattice"))
                writer.uint32(/* id 4, wireType 0 =*/32).int64(message.Lattice);
            if (message.Countdown != null && message.hasOwnProperty("Countdown"))
                writer.uint32(/* id 5, wireType 0 =*/40).int64(message.Countdown);
            if (message.ShieldLattice != null && message.ShieldLattice.length) {
                writer.uint32(/* id 6, wireType 2 =*/50).fork();
                for (var i = 0; i < message.ShieldLattice.length; ++i)
                    writer.int64(message.ShieldLattice[i]);
                writer.ldelim();
            }
            if (message.Events != null && message.Events.length)
                for (var i = 0; i < message.Events.length; ++i)
                    $root.HMP_pb.MonopolyEvent.encode(message.Events[i], writer.uint32(/* id 7, wireType 2 =*/58).fork()).ldelim();
            if (message.Grids != null && message.Grids.length)
                for (var i = 0; i < message.Grids.length; ++i)
                    $root.HMP_pb.MonopolyGrid.encode(message.Grids[i], writer.uint32(/* id 8, wireType 2 =*/66).fork()).ldelim();
            if (message.Building != null && message.Building.length)
                for (var i = 0; i < message.Building.length; ++i)
                    $root.HMP_pb.MonopolyBuilding.encode(message.Building[i], writer.uint32(/* id 9, wireType 2 =*/74).fork()).ldelim();
            return writer;
        };

        /**
         * Decodes a MonopolyInfoRes message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyInfoRes
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyInfoRes} MonopolyInfoRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyInfoRes.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyInfoRes();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.WealthLevel = reader.int64();
                    break;
                case 2:
                    message.Cash = reader.int64();
                    break;
                case 3:
                    message.ShieldNum = reader.int64();
                    break;
                case 4:
                    message.Lattice = reader.int64();
                    break;
                case 5:
                    message.Countdown = reader.int64();
                    break;
                case 6:
                    if (!(message.ShieldLattice && message.ShieldLattice.length))
                        message.ShieldLattice = [];
                    if ((tag & 7) === 2) {
                        var end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2)
                            message.ShieldLattice.push(reader.int64());
                    } else
                        message.ShieldLattice.push(reader.int64());
                    break;
                case 7:
                    if (!(message.Events && message.Events.length))
                        message.Events = [];
                    message.Events.push($root.HMP_pb.MonopolyEvent.decode(reader, reader.uint32()));
                    break;
                case 8:
                    if (!(message.Grids && message.Grids.length))
                        message.Grids = [];
                    message.Grids.push($root.HMP_pb.MonopolyGrid.decode(reader, reader.uint32()));
                    break;
                case 9:
                    if (!(message.Building && message.Building.length))
                        message.Building = [];
                    message.Building.push($root.HMP_pb.MonopolyBuilding.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyInfoRes;
    })();

    HMP_pb.MonopolyPlayReq = (function() {

        /**
         * Properties of a MonopolyPlayReq.
         * @memberof pb
         * @interface IMonopolyPlayReq
         * @property {number|null} [Multiple] MonopolyPlayReq Multiple
         */

        /**
         * Constructs a new MonopolyPlayReq.
         * @memberof pb
         * @classdesc Represents a MonopolyPlayReq.
         * @implements IMonopolyPlayReq
         * @constructor
         * @param {HMP_pb.IMonopolyPlayReq=} [properties] Properties to set
         */
        function MonopolyPlayReq(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyPlayReq Multiple.
         * @member {number} Multiple
         * @memberof HMP_pb.MonopolyPlayReq
         * @instance
         */
        MonopolyPlayReq.prototype.Multiple = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * Creates a new MonopolyPlayReq instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyPlayReq
         * @static
         * @param {HMP_pb.IMonopolyPlayReq=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyPlayReq} MonopolyPlayReq instance
         */
        MonopolyPlayReq.create = function create(properties) {
            return new MonopolyPlayReq(properties);
        };

        /**
         * Encodes the specified MonopolyPlayReq message. Does not implicitly {@link HMP_pb.MonopolyPlayReq.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyPlayReq
         * @static
         * @param {HMP_pb.IMonopolyPlayReq} message MonopolyPlayReq message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyPlayReq.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.Multiple != null && message.hasOwnProperty("Multiple"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.Multiple);
            return writer;
        };

        /**
         * Decodes a MonopolyPlayReq message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyPlayReq
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyPlayReq} MonopolyPlayReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyPlayReq.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyPlayReq();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.Multiple = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyPlayReq;
    })();

    HMP_pb.MonopolyPlayRes = (function() {

        /**
         * Properties of a MonopolyPlayRes.
         * @memberof pb
         * @interface IMonopolyPlayRes
         * @property {number|null} [Lattice] MonopolyPlayRes Lattice
         * @property {number|null} [Number1] MonopolyPlayRes Number1
         * @property {number|null} [Number2] MonopolyPlayRes Number2
         * @property {Array.<HMP_pb.IMonopolyEvent>|null} [Events] MonopolyPlayRes Events
         * @property {Array.<number>|null} [ShieldLattice] MonopolyPlayRes ShieldLattice
         */

        /**
         * Constructs a new MonopolyPlayRes.
         * @memberof pb
         * @classdesc Represents a MonopolyPlayRes.
         * @implements IMonopolyPlayRes
         * @constructor
         * @param {HMP_pb.IMonopolyPlayRes=} [properties] Properties to set
         */
        function MonopolyPlayRes(properties) {
            this.Events = [];
            this.ShieldLattice = [];
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyPlayRes Lattice.
         * @member {number} Lattice
         * @memberof HMP_pb.MonopolyPlayRes
         * @instance
         */
        MonopolyPlayRes.prototype.Lattice = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyPlayRes Number1.
         * @member {number} Number1
         * @memberof HMP_pb.MonopolyPlayRes
         * @instance
         */
        MonopolyPlayRes.prototype.Number1 = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyPlayRes Number2.
         * @member {number} Number2
         * @memberof HMP_pb.MonopolyPlayRes
         * @instance
         */
        MonopolyPlayRes.prototype.Number2 = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyPlayRes Events.
         * @member {Array.<HMP_pb.IMonopolyEvent>} Events
         * @memberof HMP_pb.MonopolyPlayRes
         * @instance
         */
        MonopolyPlayRes.prototype.Events = $util.emptyArray;

        /**
         * MonopolyPlayRes ShieldLattice.
         * @member {Array.<number>} ShieldLattice
         * @memberof HMP_pb.MonopolyPlayRes
         * @instance
         */
        MonopolyPlayRes.prototype.ShieldLattice = $util.emptyArray;

        /**
         * Creates a new MonopolyPlayRes instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyPlayRes
         * @static
         * @param {HMP_pb.IMonopolyPlayRes=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyPlayRes} MonopolyPlayRes instance
         */
        MonopolyPlayRes.create = function create(properties) {
            return new MonopolyPlayRes(properties);
        };

        /**
         * Encodes the specified MonopolyPlayRes message. Does not implicitly {@link HMP_pb.MonopolyPlayRes.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyPlayRes
         * @static
         * @param {HMP_pb.IMonopolyPlayRes} message MonopolyPlayRes message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyPlayRes.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.Lattice != null && message.hasOwnProperty("Lattice"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.Lattice);
            if (message.Number1 != null && message.hasOwnProperty("Number1"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.Number1);
            if (message.Number2 != null && message.hasOwnProperty("Number2"))
                writer.uint32(/* id 3, wireType 0 =*/24).int64(message.Number2);
            if (message.Events != null && message.Events.length)
                for (var i = 0; i < message.Events.length; ++i)
                    $root.HMP_pb.MonopolyEvent.encode(message.Events[i], writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
            if (message.ShieldLattice != null && message.ShieldLattice.length) {
                writer.uint32(/* id 5, wireType 2 =*/42).fork();
                for (var i = 0; i < message.ShieldLattice.length; ++i)
                    writer.int64(message.ShieldLattice[i]);
                writer.ldelim();
            }
            return writer;
        };

        /**
         * Decodes a MonopolyPlayRes message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyPlayRes
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyPlayRes} MonopolyPlayRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyPlayRes.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyPlayRes();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.Lattice = reader.int64();
                    break;
                case 2:
                    message.Number1 = reader.int64();
                    break;
                case 3:
                    message.Number2 = reader.int64();
                    break;
                case 4:
                    if (!(message.Events && message.Events.length))
                        message.Events = [];
                    message.Events.push($root.HMP_pb.MonopolyEvent.decode(reader, reader.uint32()));
                    break;
                case 5:
                    if (!(message.ShieldLattice && message.ShieldLattice.length))
                        message.ShieldLattice = [];
                    if ((tag & 7) === 2) {
                        var end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2)
                            message.ShieldLattice.push(reader.int64());
                    } else
                        message.ShieldLattice.push(reader.int64());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyPlayRes;
    })();

    HMP_pb.MonopolyBuilding = (function() {

        /**
         * Properties of a MonopolyBuilding.
         * @memberof pb
         * @interface IMonopolyBuilding
         * @property {number|null} [Id] MonopolyBuilding Id
         * @property {number|null} [Index] MonopolyBuilding Index
         * @property {number|null} [Level] MonopolyBuilding Level
         * @property {number|null} [IsBroken] MonopolyBuilding IsBroken
         */

        /**
         * Constructs a new MonopolyBuilding.
         * @memberof pb
         * @classdesc Represents a MonopolyBuilding.
         * @implements IMonopolyBuilding
         * @constructor
         * @param {HMP_pb.IMonopolyBuilding=} [properties] Properties to set
         */
        function MonopolyBuilding(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyBuilding Id.
         * @member {number} Id
         * @memberof HMP_pb.MonopolyBuilding
         * @instance
         */
        MonopolyBuilding.prototype.Id = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyBuilding Index.
         * @member {number} Index
         * @memberof HMP_pb.MonopolyBuilding
         * @instance
         */
        MonopolyBuilding.prototype.Index = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyBuilding Level.
         * @member {number} Level
         * @memberof HMP_pb.MonopolyBuilding
         * @instance
         */
        MonopolyBuilding.prototype.Level = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyBuilding IsBroken.
         * @member {number} IsBroken
         * @memberof HMP_pb.MonopolyBuilding
         * @instance
         */
        MonopolyBuilding.prototype.IsBroken = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * Creates a new MonopolyBuilding instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyBuilding
         * @static
         * @param {HMP_pb.IMonopolyBuilding=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyBuilding} MonopolyBuilding instance
         */
        MonopolyBuilding.create = function create(properties) {
            return new MonopolyBuilding(properties);
        };

        /**
         * Encodes the specified MonopolyBuilding message. Does not implicitly {@link HMP_pb.MonopolyBuilding.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyBuilding
         * @static
         * @param {HMP_pb.IMonopolyBuilding} message MonopolyBuilding message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyBuilding.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.Id != null && message.hasOwnProperty("Id"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.Id);
            if (message.Index != null && message.hasOwnProperty("Index"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.Index);
            if (message.Level != null && message.hasOwnProperty("Level"))
                writer.uint32(/* id 3, wireType 0 =*/24).int64(message.Level);
            if (message.IsBroken != null && message.hasOwnProperty("IsBroken"))
                writer.uint32(/* id 4, wireType 0 =*/32).int64(message.IsBroken);
            return writer;
        };

        /**
         * Decodes a MonopolyBuilding message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyBuilding
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyBuilding} MonopolyBuilding
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyBuilding.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyBuilding();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.Id = reader.int64();
                    break;
                case 2:
                    message.Index = reader.int64();
                    break;
                case 3:
                    message.Level = reader.int64();
                    break;
                case 4:
                    message.IsBroken = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyBuilding;
    })();

    HMP_pb.MonopolyBuildReq = (function() {

        /**
         * Properties of a MonopolyBuildReq.
         * @memberof pb
         * @interface IMonopolyBuildReq
         * @property {number|null} [Id] MonopolyBuildReq Id
         * @property {number|null} [Index] MonopolyBuildReq Index
         */

        /**
         * Constructs a new MonopolyBuildReq.
         * @memberof pb
         * @classdesc Represents a MonopolyBuildReq.
         * @implements IMonopolyBuildReq
         * @constructor
         * @param {HMP_pb.IMonopolyBuildReq=} [properties] Properties to set
         */
        function MonopolyBuildReq(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyBuildReq Id.
         * @member {number} Id
         * @memberof HMP_pb.MonopolyBuildReq
         * @instance
         */
        MonopolyBuildReq.prototype.Id = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyBuildReq Index.
         * @member {number} Index
         * @memberof HMP_pb.MonopolyBuildReq
         * @instance
         */
        MonopolyBuildReq.prototype.Index = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * Creates a new MonopolyBuildReq instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyBuildReq
         * @static
         * @param {HMP_pb.IMonopolyBuildReq=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyBuildReq} MonopolyBuildReq instance
         */
        MonopolyBuildReq.create = function create(properties) {
            return new MonopolyBuildReq(properties);
        };

        /**
         * Encodes the specified MonopolyBuildReq message. Does not implicitly {@link HMP_pb.MonopolyBuildReq.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyBuildReq
         * @static
         * @param {HMP_pb.IMonopolyBuildReq} message MonopolyBuildReq message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyBuildReq.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.Id != null && message.hasOwnProperty("Id"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.Id);
            if (message.Index != null && message.hasOwnProperty("Index"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.Index);
            return writer;
        };

        /**
         * Decodes a MonopolyBuildReq message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyBuildReq
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyBuildReq} MonopolyBuildReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyBuildReq.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyBuildReq();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.Id = reader.int64();
                    break;
                case 2:
                    message.Index = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyBuildReq;
    })();

    HMP_pb.MonopolyBuildRes = (function() {

        /**
         * Properties of a MonopolyBuildRes.
         * @memberof pb
         * @interface IMonopolyBuildRes
         * @property {number|null} [Code] MonopolyBuildRes Code
         * @property {number|null} [WealthLevel] MonopolyBuildRes WealthLevel
         */

        /**
         * Constructs a new MonopolyBuildRes.
         * @memberof pb
         * @classdesc Represents a MonopolyBuildRes.
         * @implements IMonopolyBuildRes
         * @constructor
         * @param {HMP_pb.IMonopolyBuildRes=} [properties] Properties to set
         */
        function MonopolyBuildRes(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * MonopolyBuildRes Code.
         * @member {number} Code
         * @memberof HMP_pb.MonopolyBuildRes
         * @instance
         */
        MonopolyBuildRes.prototype.Code = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * MonopolyBuildRes WealthLevel.
         * @member {number} WealthLevel
         * @memberof HMP_pb.MonopolyBuildRes
         * @instance
         */
        MonopolyBuildRes.prototype.WealthLevel = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * Creates a new MonopolyBuildRes instance using the specified properties.
         * @function create
         * @memberof HMP_pb.MonopolyBuildRes
         * @static
         * @param {HMP_pb.IMonopolyBuildRes=} [properties] Properties to set
         * @returns {HMP_pb.MonopolyBuildRes} MonopolyBuildRes instance
         */
        MonopolyBuildRes.create = function create(properties) {
            return new MonopolyBuildRes(properties);
        };

        /**
         * Encodes the specified MonopolyBuildRes message. Does not implicitly {@link HMP_pb.MonopolyBuildRes.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.MonopolyBuildRes
         * @static
         * @param {HMP_pb.IMonopolyBuildRes} message MonopolyBuildRes message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        MonopolyBuildRes.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.Code != null && message.hasOwnProperty("Code"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.Code);
            if (message.WealthLevel != null && message.hasOwnProperty("WealthLevel"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.WealthLevel);
            return writer;
        };

        /**
         * Decodes a MonopolyBuildRes message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.MonopolyBuildRes
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.MonopolyBuildRes} MonopolyBuildRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        MonopolyBuildRes.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.MonopolyBuildRes();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.Code = reader.int64();
                    break;
                case 2:
                    message.WealthLevel = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return MonopolyBuildRes;
    })();

    HMP_pb.GetDiceByHourReq = (function() {

        /**
         * Properties of a GetDiceByHourReq.
         * @memberof pb
         * @interface IGetDiceByHourReq
         */

        /**
         * Constructs a new GetDiceByHourReq.
         * @memberof pb
         * @classdesc Represents a GetDiceByHourReq.
         * @implements IGetDiceByHourReq
         * @constructor
         * @param {HMP_pb.IGetDiceByHourReq=} [properties] Properties to set
         */
        function GetDiceByHourReq(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * Creates a new GetDiceByHourReq instance using the specified properties.
         * @function create
         * @memberof HMP_pb.GetDiceByHourReq
         * @static
         * @param {HMP_pb.IGetDiceByHourReq=} [properties] Properties to set
         * @returns {HMP_pb.GetDiceByHourReq} GetDiceByHourReq instance
         */
        GetDiceByHourReq.create = function create(properties) {
            return new GetDiceByHourReq(properties);
        };

        /**
         * Encodes the specified GetDiceByHourReq message. Does not implicitly {@link HMP_pb.GetDiceByHourReq.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.GetDiceByHourReq
         * @static
         * @param {HMP_pb.IGetDiceByHourReq} message GetDiceByHourReq message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        GetDiceByHourReq.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            return writer;
        };

        /**
         * Decodes a GetDiceByHourReq message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.GetDiceByHourReq
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.GetDiceByHourReq} GetDiceByHourReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        GetDiceByHourReq.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.GetDiceByHourReq();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return GetDiceByHourReq;
    })();

    HMP_pb.GetDiceByHourRes = (function() {

        /**
         * Properties of a GetDiceByHourRes.
         * @memberof pb
         * @interface IGetDiceByHourRes
         * @property {number|null} [ItemNumAll] GetDiceByHourRes ItemNumAll
         * @property {number|null} [Countdown] GetDiceByHourRes Countdown
         */

        /**
         * Constructs a new GetDiceByHourRes.
         * @memberof pb
         * @classdesc Represents a GetDiceByHourRes.
         * @implements IGetDiceByHourRes
         * @constructor
         * @param {HMP_pb.IGetDiceByHourRes=} [properties] Properties to set
         */
        function GetDiceByHourRes(properties) {
            if (properties)
                for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null)
                        this[keys[i]] = properties[keys[i]];
        }

        /**
         * GetDiceByHourRes ItemNumAll.
         * @member {number} ItemNumAll
         * @memberof HMP_pb.GetDiceByHourRes
         * @instance
         */
        GetDiceByHourRes.prototype.ItemNumAll = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * GetDiceByHourRes Countdown.
         * @member {number} Countdown
         * @memberof HMP_pb.GetDiceByHourRes
         * @instance
         */
        GetDiceByHourRes.prototype.Countdown = $util.Long ? $util.Long.fromBits(0,0,false) : 0;

        /**
         * Creates a new GetDiceByHourRes instance using the specified properties.
         * @function create
         * @memberof HMP_pb.GetDiceByHourRes
         * @static
         * @param {HMP_pb.IGetDiceByHourRes=} [properties] Properties to set
         * @returns {HMP_pb.GetDiceByHourRes} GetDiceByHourRes instance
         */
        GetDiceByHourRes.create = function create(properties) {
            return new GetDiceByHourRes(properties);
        };

        /**
         * Encodes the specified GetDiceByHourRes message. Does not implicitly {@link HMP_pb.GetDiceByHourRes.verify|verify} messages.
         * @function encode
         * @memberof HMP_pb.GetDiceByHourRes
         * @static
         * @param {HMP_pb.IGetDiceByHourRes} message GetDiceByHourRes message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        GetDiceByHourRes.encode = function encode(message, writer) {
            if (!writer)
                writer = $Writer.create();
            if (message.ItemNumAll != null && message.hasOwnProperty("ItemNumAll"))
                writer.uint32(/* id 1, wireType 0 =*/8).int64(message.ItemNumAll);
            if (message.Countdown != null && message.hasOwnProperty("Countdown"))
                writer.uint32(/* id 2, wireType 0 =*/16).int64(message.Countdown);
            return writer;
        };

        /**
         * Decodes a GetDiceByHourRes message from the specified reader or buffer.
         * @function decode
         * @memberof HMP_pb.GetDiceByHourRes
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {HMP_pb.GetDiceByHourRes} GetDiceByHourRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        GetDiceByHourRes.decode = function decode(reader, length) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            var end = length === undefined ? reader.len : reader.pos + length, message = new $root.HMP_pb.GetDiceByHourRes();
            while (reader.pos < end) {
                var tag = reader.uint32();
                switch (tag >>> 3) {
                case 1:
                    message.ItemNumAll = reader.int64();
                    break;
                case 2:
                    message.Countdown = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
                }
            }
            return message;
        };

        return GetDiceByHourRes;
    })();

    return HMP_pb;
})();

module.exports = $root;
