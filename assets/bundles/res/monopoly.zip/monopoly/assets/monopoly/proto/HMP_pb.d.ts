import * as $protobuf from "protobufjs";
/** Namespace HMP_pb. */
export namespace HMP_pb {

    /** Properties of a MonopolyGrid. */
    interface IMonopolyGrid {

        /** MonopolyGrid Lattice */
        Lattice?: (number|null);

        /** MonopolyGrid Level */
        Level?: (number|null);
    }

    /** Represents a MonopolyGrid. */
    class MonopolyGrid implements IMonopolyGrid {

        /**
         * Constructs a new MonopolyGrid.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyGrid);

        /** MonopolyGrid Lattice. */
        public Lattice: number;

        /** MonopolyGrid Level. */
        public Level: number;

        /**
         * Creates a new MonopolyGrid instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyGrid instance
         */
        public static create(properties?: HMP_pb.IMonopolyGrid): HMP_pb.MonopolyGrid;

        /**
         * Encodes the specified MonopolyGrid message. Does not implicitly {@link HMP_pb.MonopolyGrid.verify|verify} messages.
         * @param message MonopolyGrid message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyGrid, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyGrid message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyGrid
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyGrid;
    }

    /** Properties of a MonopolyEvent. */
    interface IMonopolyEvent {

        /** MonopolyEvent EventType */
        EventType?: (number|null);

        /** MonopolyEvent ChangeCash */
        ChangeCash?: (number|null);

        /** MonopolyEvent PrisonRollNum */
        PrisonRollNum?: (number|null);

        /** MonopolyEvent AddShildNum */
        AddShildNum?: (number|null);
    }

    /** Represents a MonopolyEvent. */
    class MonopolyEvent implements IMonopolyEvent {

        /**
         * Constructs a new MonopolyEvent.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyEvent);

        /** MonopolyEvent EventType. */
        public EventType: number;

        /** MonopolyEvent ChangeCash. */
        public ChangeCash: number;

        /** MonopolyEvent PrisonRollNum. */
        public PrisonRollNum: number;

        /** MonopolyEvent AddShildNum. */
        public AddShildNum: number;

        /**
         * Creates a new MonopolyEvent instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyEvent instance
         */
        public static create(properties?: HMP_pb.IMonopolyEvent): HMP_pb.MonopolyEvent;

        /**
         * Encodes the specified MonopolyEvent message. Does not implicitly {@link HMP_pb.MonopolyEvent.verify|verify} messages.
         * @param message MonopolyEvent message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyEvent, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyEvent message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyEvent
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyEvent;
    }

    /** Properties of a MonopolyInfoReq. */
    interface IMonopolyInfoReq {
    }

    /** Represents a MonopolyInfoReq. */
    class MonopolyInfoReq implements IMonopolyInfoReq {

        /**
         * Constructs a new MonopolyInfoReq.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyInfoReq);

        /**
         * Creates a new MonopolyInfoReq instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyInfoReq instance
         */
        public static create(properties?: HMP_pb.IMonopolyInfoReq): HMP_pb.MonopolyInfoReq;

        /**
         * Encodes the specified MonopolyInfoReq message. Does not implicitly {@link HMP_pb.MonopolyInfoReq.verify|verify} messages.
         * @param message MonopolyInfoReq message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyInfoReq, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyInfoReq message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyInfoReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyInfoReq;
    }

    /** Properties of a MonopolyInfoRes. */
    interface IMonopolyInfoRes {

        /** MonopolyInfoRes WealthLevel */
        WealthLevel?: (number|null);

        /** MonopolyInfoRes Cash */
        Cash?: (number|null);

        /** MonopolyInfoRes ShieldNum */
        ShieldNum?: (number|null);

        /** MonopolyInfoRes Lattice */
        Lattice?: (number|null);

        /** MonopolyInfoRes Countdown */
        Countdown?: (number|null);

        /** MonopolyInfoRes ShieldLattice */
        ShieldLattice?: (number[]|null);

        /** MonopolyInfoRes Events */
        Events?: (HMP_pb.IMonopolyEvent[]|null);

        /** MonopolyInfoRes Grids */
        Grids?: (HMP_pb.IMonopolyGrid[]|null);

        /** MonopolyInfoRes Building */
        Building?: (HMP_pb.IMonopolyBuilding[]|null);
    }

    /** Represents a MonopolyInfoRes. */
    class MonopolyInfoRes implements IMonopolyInfoRes {

        /**
         * Constructs a new MonopolyInfoRes.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyInfoRes);

        /** MonopolyInfoRes WealthLevel. */
        public WealthLevel: number;

        /** MonopolyInfoRes Cash. */
        public Cash: number;

        /** MonopolyInfoRes ShieldNum. */
        public ShieldNum: number;

        /** MonopolyInfoRes Lattice. */
        public Lattice: number;

        /** MonopolyInfoRes Countdown. */
        public Countdown: number;

        /** MonopolyInfoRes ShieldLattice. */
        public ShieldLattice: number[];

        /** MonopolyInfoRes Events. */
        public Events: HMP_pb.IMonopolyEvent[];

        /** MonopolyInfoRes Grids. */
        public Grids: HMP_pb.IMonopolyGrid[];

        /** MonopolyInfoRes Building. */
        public Building: HMP_pb.IMonopolyBuilding[];

        /**
         * Creates a new MonopolyInfoRes instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyInfoRes instance
         */
        public static create(properties?: HMP_pb.IMonopolyInfoRes): HMP_pb.MonopolyInfoRes;

        /**
         * Encodes the specified MonopolyInfoRes message. Does not implicitly {@link HMP_pb.MonopolyInfoRes.verify|verify} messages.
         * @param message MonopolyInfoRes message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyInfoRes, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyInfoRes message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyInfoRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyInfoRes;
    }

    /** Properties of a MonopolyPlayReq. */
    interface IMonopolyPlayReq {

        /** MonopolyPlayReq Multiple */
        Multiple?: (number|null);
    }

    /** Represents a MonopolyPlayReq. */
    class MonopolyPlayReq implements IMonopolyPlayReq {

        /**
         * Constructs a new MonopolyPlayReq.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyPlayReq);

        /** MonopolyPlayReq Multiple. */
        public Multiple: number;

        /**
         * Creates a new MonopolyPlayReq instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyPlayReq instance
         */
        public static create(properties?: HMP_pb.IMonopolyPlayReq): HMP_pb.MonopolyPlayReq;

        /**
         * Encodes the specified MonopolyPlayReq message. Does not implicitly {@link HMP_pb.MonopolyPlayReq.verify|verify} messages.
         * @param message MonopolyPlayReq message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyPlayReq, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyPlayReq message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyPlayReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyPlayReq;
    }

    /** Properties of a MonopolyPlayRes. */
    interface IMonopolyPlayRes {

        /** MonopolyPlayRes Lattice */
        Lattice?: (number|null);

        /** MonopolyPlayRes Number1 */
        Number1?: (number|null);

        /** MonopolyPlayRes Number2 */
        Number2?: (number|null);

        /** MonopolyPlayRes Events */
        Events?: (HMP_pb.IMonopolyEvent[]|null);

        /** MonopolyPlayRes ShieldLattice */
        ShieldLattice?: (number[]|null);
    }

    /** Represents a MonopolyPlayRes. */
    class MonopolyPlayRes implements IMonopolyPlayRes {

        /**
         * Constructs a new MonopolyPlayRes.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyPlayRes);

        /** MonopolyPlayRes Lattice. */
        public Lattice: number;

        /** MonopolyPlayRes Number1. */
        public Number1: number;

        /** MonopolyPlayRes Number2. */
        public Number2: number;

        /** MonopolyPlayRes Events. */
        public Events: HMP_pb.IMonopolyEvent[];

        /** MonopolyPlayRes ShieldLattice. */
        public ShieldLattice: number[];

        /**
         * Creates a new MonopolyPlayRes instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyPlayRes instance
         */
        public static create(properties?: HMP_pb.IMonopolyPlayRes): HMP_pb.MonopolyPlayRes;

        /**
         * Encodes the specified MonopolyPlayRes message. Does not implicitly {@link HMP_pb.MonopolyPlayRes.verify|verify} messages.
         * @param message MonopolyPlayRes message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyPlayRes, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyPlayRes message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyPlayRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyPlayRes;
    }

    /** Properties of a MonopolyBuilding. */
    interface IMonopolyBuilding {

        /** MonopolyBuilding Id */
        Id?: (number|null);

        /** MonopolyBuilding Index */
        Index?: (number|null);

        /** MonopolyBuilding Level */
        Level?: (number|null);

        /** MonopolyBuilding IsBroken */
        IsBroken?: (number|null);
    }

    /** Represents a MonopolyBuilding. */
    class MonopolyBuilding implements IMonopolyBuilding {

        /**
         * Constructs a new MonopolyBuilding.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyBuilding);

        /** MonopolyBuilding Id. */
        public Id: number;

        /** MonopolyBuilding Index. */
        public Index: number;

        /** MonopolyBuilding Level. */
        public Level: number;

        /** MonopolyBuilding IsBroken. */
        public IsBroken: number;

        /**
         * Creates a new MonopolyBuilding instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyBuilding instance
         */
        public static create(properties?: HMP_pb.IMonopolyBuilding): HMP_pb.MonopolyBuilding;

        /**
         * Encodes the specified MonopolyBuilding message. Does not implicitly {@link HMP_pb.MonopolyBuilding.verify|verify} messages.
         * @param message MonopolyBuilding message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyBuilding, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyBuilding message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyBuilding
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyBuilding;
    }

    /** Properties of a MonopolyBuildReq. */
    interface IMonopolyBuildReq {

        /** MonopolyBuildReq Id */
        Id?: (number|null);

        /** MonopolyBuildReq Index */
        Index?: (number|null);
    }

    /** Represents a MonopolyBuildReq. */
    class MonopolyBuildReq implements IMonopolyBuildReq {

        /**
         * Constructs a new MonopolyBuildReq.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyBuildReq);

        /** MonopolyBuildReq Id. */
        public Id: number;

        /** MonopolyBuildReq Index. */
        public Index: number;

        /**
         * Creates a new MonopolyBuildReq instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyBuildReq instance
         */
        public static create(properties?: HMP_pb.IMonopolyBuildReq): HMP_pb.MonopolyBuildReq;

        /**
         * Encodes the specified MonopolyBuildReq message. Does not implicitly {@link HMP_pb.MonopolyBuildReq.verify|verify} messages.
         * @param message MonopolyBuildReq message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyBuildReq, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyBuildReq message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyBuildReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyBuildReq;
    }

    /** Properties of a MonopolyBuildRes. */
    interface IMonopolyBuildRes {

        /** MonopolyBuildRes Code */
        Code?: (number|null);

        /** MonopolyBuildRes WealthLevel */
        WealthLevel?: (number|null);
    }

    /** Represents a MonopolyBuildRes. */
    class MonopolyBuildRes implements IMonopolyBuildRes {

        /**
         * Constructs a new MonopolyBuildRes.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IMonopolyBuildRes);

        /** MonopolyBuildRes Code. */
        public Code: number;

        /** MonopolyBuildRes WealthLevel. */
        public WealthLevel: number;

        /**
         * Creates a new MonopolyBuildRes instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MonopolyBuildRes instance
         */
        public static create(properties?: HMP_pb.IMonopolyBuildRes): HMP_pb.MonopolyBuildRes;

        /**
         * Encodes the specified MonopolyBuildRes message. Does not implicitly {@link HMP_pb.MonopolyBuildRes.verify|verify} messages.
         * @param message MonopolyBuildRes message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IMonopolyBuildRes, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MonopolyBuildRes message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MonopolyBuildRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.MonopolyBuildRes;
    }

    /** Properties of a GetDiceByHourReq. */
    interface IGetDiceByHourReq {
    }

    /** Represents a GetDiceByHourReq. */
    class GetDiceByHourReq implements IGetDiceByHourReq {

        /**
         * Constructs a new GetDiceByHourReq.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IGetDiceByHourReq);

        /**
         * Creates a new GetDiceByHourReq instance using the specified properties.
         * @param [properties] Properties to set
         * @returns GetDiceByHourReq instance
         */
        public static create(properties?: HMP_pb.IGetDiceByHourReq): HMP_pb.GetDiceByHourReq;

        /**
         * Encodes the specified GetDiceByHourReq message. Does not implicitly {@link HMP_pb.GetDiceByHourReq.verify|verify} messages.
         * @param message GetDiceByHourReq message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IGetDiceByHourReq, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a GetDiceByHourReq message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns GetDiceByHourReq
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.GetDiceByHourReq;
    }

    /** Properties of a GetDiceByHourRes. */
    interface IGetDiceByHourRes {

        /** GetDiceByHourRes ItemNumAll */
        ItemNumAll?: (number|null);

        /** GetDiceByHourRes Countdown */
        Countdown?: (number|null);
    }

    /** Represents a GetDiceByHourRes. */
    class GetDiceByHourRes implements IGetDiceByHourRes {

        /**
         * Constructs a new GetDiceByHourRes.
         * @param [properties] Properties to set
         */
        constructor(properties?: HMP_pb.IGetDiceByHourRes);

        /** GetDiceByHourRes ItemNumAll. */
        public ItemNumAll: number;

        /** GetDiceByHourRes Countdown. */
        public Countdown: number;

        /**
         * Creates a new GetDiceByHourRes instance using the specified properties.
         * @param [properties] Properties to set
         * @returns GetDiceByHourRes instance
         */
        public static create(properties?: HMP_pb.IGetDiceByHourRes): HMP_pb.GetDiceByHourRes;

        /**
         * Encodes the specified GetDiceByHourRes message. Does not implicitly {@link HMP_pb.GetDiceByHourRes.verify|verify} messages.
         * @param message GetDiceByHourRes message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: HMP_pb.IGetDiceByHourRes, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a GetDiceByHourRes message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns GetDiceByHourRes
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): HMP_pb.GetDiceByHourRes;
    }
}
