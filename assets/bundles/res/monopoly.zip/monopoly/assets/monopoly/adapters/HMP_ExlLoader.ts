/** auto generate by exlExport.js, do not modify! */
import { HMP_ExllangTable } from '../excelData/HMP_ExllangTable'
import { HMP_Exlloading } from '../excelData/HMP_Exlloading'
import { HMP_Exlmonopoly_base } from '../excelData/HMP_Exlmonopoly_base'
import { HMP_Exlmonopoly_build } from '../excelData/HMP_Exlmonopoly_build'
import { HMP_Exlmonopoly_cash } from '../excelData/HMP_Exlmonopoly_cash'
import { HMP_Exlmonopoly_qp } from '../excelData/HMP_Exlmonopoly_qp'
export class HMP_ExlLoader extends gea.common.GameMgrPool {
    /**
     * 加载所有excel导出的数据文件
     * @param option 用于指定加载进度回调和加载完成回调
     */
    loadAll(bundle: string, option: { complete: (error: Error, resource: cc.JsonAsset[]) => void, completeScope?: any, progress?: (completeCount: number, totalCount: number, item: cc.AssetManager.RequestItem) => void, progressScope?: any }): void {
        this.load(bundle, ['langTable', 'loading', 'monopoly_base', 'monopoly_build', 'monopoly_cash', 'monopoly_qp'], option)
    }
    /**
     * 加载自定义的excel导出的数据文件
     * @param jsonFileNames 要加载的数据文件名列表,根据代码提示填写即可
     * @param option 用于指定加载进度回调和加载完成回调
     */
    loadFew(bundle: string, jsonFileNames: ('langTable' | 'loading' | 'monopoly_base' | 'monopoly_build' | 'monopoly_cash' | 'monopoly_qp')[], option: { complete: (error: Error, resource: cc.JsonAsset[]) => void, completeScope?: any, progress?: (completeCount: number, totalCount: number, item: cc.AssetManager.RequestItem) => void, progressScope?: any }): void {
        this.load(bundle, jsonFileNames, option)
    }
    callbackAfterBorrow():void {
    }
    callbackBeforeRestore(): boolean {
        HMP_ExllangTable.clearAll()
        HMP_Exlloading.clearAll()
        HMP_Exlmonopoly_base.clearAll()
        HMP_Exlmonopoly_build.clearAll()
        HMP_Exlmonopoly_cash.clearAll()
        HMP_Exlmonopoly_qp.clearAll()
        return true
    }
    /**
     * 加载指定excel导出的数据文件
     * @param jsonFileNames 指定的数据文件列表
     * @param option 用于指定加载进度回调和加载完成回调
     */
    private load(bundle: string, jsonFileNames: string[], option: { complete: (error: Error, resource: cc.JsonAsset[]) => void, completeScope?: any, progress?: (completeCount: number, totalCount: number, item: cc.AssetManager.RequestItem) => void, progressScope?: any }): void {
        gea.assetMgr.getBundle(bundle).load(jsonFileNames.map((fileName: string): string => { return 'res/excelData/' + fileName }), cc.JsonAsset,
            (completeCount: number, totalCount: number, item: cc.AssetManager.RequestItem): void => {
                if (option.progress) {
                    option.progress.call(option.progressScope, completeCount, totalCount, item)
                }
            },
            (error: Error, resource: cc.JsonAsset | cc.JsonAsset[]): void => {
                let result: cc.JsonAsset[] = resource && (resource instanceof Array ? resource : [resource])
                if (error) {
                    console.error(error)
                } else if (result) {
                    result.forEach(res => {
                        switch (res.name) {
                            case 'langTable': res.json.root.forEach((value: any): void => { HMP_ExllangTable.append(value) }); break
                            case 'loading': res.json.root.forEach((value: any): void => { HMP_Exlloading.append(value) }); break
                            case 'monopoly_base': res.json.root.forEach((value: any): void => { HMP_Exlmonopoly_base.append(value) }); break
                            case 'monopoly_build': res.json.root.forEach((value: any): void => { HMP_Exlmonopoly_build.append(value) }); break
                            case 'monopoly_cash': res.json.root.forEach((value: any): void => { HMP_Exlmonopoly_cash.append(value) }); break
                            case 'monopoly_qp': res.json.root.forEach((value: any): void => { HMP_Exlmonopoly_qp.append(value) }); break
                        }
                    })
                }
                if (option.complete) {
                    option.complete.call(option.completeScope, error, result)
                }
            },
        )
    }
}
