/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 17:58:39
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-11-04 17:57:40
 * @Description: 配置子游戏bundle名字， 给工具脚本设置路径用
 */
//子游戏bundle名
exports._subGameBundle = 'monopoly'
//子游戏文件前缀
exports._subGamePrefix = 'HMP_'
