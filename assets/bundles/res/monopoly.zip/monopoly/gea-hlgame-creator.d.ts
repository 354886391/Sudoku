/// <reference path="gea-hlgame-creator-2.4/src/creator.d.ts" />
declare namespace gea.interfaces.base {
    interface IDestroyAble {
        /**
         * 销毁
         */
        destroy(...args: any[]): void;
    }
}
declare namespace gea.discriminator {
    enum interfaces {
        callback = "gea.interfaces.base.ICallback"
    }
}
declare namespace gea.interfaces.base {
    interface IInterfaceDiscriminator {
        /**
         * 接口的辨别器
         * + 实现一个接口时，直接返回对应接口的字符串定义就可以
         * + 实现多个接口时，返回一个数组，包含多个接口的字符串定义
         * @see gea.discriminator.interfaces
         */
        readonly discriminator: string[] | string;
    }
}
declare namespace gea.interfaces.base {
    interface ICallback extends IDestroyAble, IInterfaceDiscriminator {
        readonly discriminator: gea.discriminator.interfaces.callback;
        /**
         * 获取剩余回调次数
         */
        callbackLimite(): number;
        /**
         * @param value 设置回调次数上限,小于等于0表示无穷大
         */
        callbackLimite(value: number): ICallback;
        /**
         * 回调设置
         * @param args 回调参数
         */
        args(...args: any[]): ICallback;
        /**
         * 执行一次回调
         * @param extraArgs 额外的回调参数
         */
        excute(...extraArgs: any[]): ICallback;
    }
}
declare namespace gea.interfaces.base {
    interface IPoolObject {
        /**
         * 借用后的回调函数
         * @param args 可选参数
         * @example
         * gea.pool.borrow(poolClass)
         */
        callbackAfterBorrow?(...args: any[]): void;
        /**
         * 归还前的回调函数,如果返回true，则表示可以立即还入对象池
         * @param args 可选参数
         * @example
         * gea.pool.restore(poolObject)
         */
        callbackBeforeRestore?(...args: any[]): boolean;
    }
}
declare namespace gea {
    function log(...args: any[]): void;
    function info(...args: any[]): void;
    function warn(...args: any[]): void;
    function error(...args: any[]): void;
    enum LogLv {
        DEBUG = 0,
        INFO = 1,
        WARN = 2,
        ERROR = 3
    }
    let logLevel: gea.LogLv;
    let log2: Function;
    /**
     * 设置Log前缀
     * @param prefix
     */
    function setLogPrefix(prefix: string): void;
    /** 设置日志级别 */
    function setLogLevel(lv: number): void;
}
declare namespace gea.interfaces.base {
    /**
     * 对象池管理中心
     */
    interface IPoolManager {
        /**
         * 从对象池获取一个实例
         * @param poolClass 继承自对象池基类的class
         * @param args 初始化参数
         */
        borrow<T extends IPoolObject>(poolClass: {
            prototype: T;
            new (): T;
        }, ...args: any[]): T;
        /**
         * 回收一个实例到对象池
         * @param ins 继承自对象池的实例对象
         * @param args 回收时附带的参数
         */
        restore(ins: IPoolObject, ...args: any[]): void;
    }
}
declare namespace gea {
    const pool: interfaces.base.IPoolManager;
}
declare namespace gea {
    /**
     * 获取一个对象的uuid
     * @params target 任意对象,若为数字或者字符串则直接返回字符串格式
     * @params scope 作用域,若为数字或者字符串则忽略
     */
    function uuid(target: any, scope?: any): string;
}
declare namespace gea {
    /**
     * 获取一个经过封装的回调函数
     * @param callback 回调函数
     * @param scope 回调函数作用于
     * @param callbackLimite 回调函数回调次数限制,0为不限制回调次数
     * @param callbackArgs 回调函数参数
     * @see gea.interfaces.base.ICallback
     */
    function callback(callback: Function, scope: any, ...callbackArgs: any[]): interfaces.base.ICallback;
}
declare namespace gea.events {
    enum base {
        /**本地时间被回拨 */
        localtime_reduced = "gea.events.base.localtime_reduced",
        /**系统切到后台 */
        enter_background = "gea.events.base.enter_background",
        /**系统切回前台 */
        enter_foreground = "gea.events.base.enter_foreground"
    }
}
declare namespace gea.interfaces.base {
    /**
     * Gea
     */
    interface IGea {
        /**
         * 是否已暂停
         */
        readonly paused: boolean;
        /**
         * 本地时间
         */
        readonly localTime: number;
        /**
         * 获取运行经过的时间
         */
        readonly pastTime: number;
        /**
         * 暂停Polling,Timer
         */
        pause(): void;
        /**
         * 唤醒Polling,Timer
         */
        resume(): void;
        /**
         * 针对某tag新增一个订阅者,订阅执行一次后关闭,或者off显式关闭
         * @param tag 标记
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        once(tag: any, callback: Function, scope: any, ...callbackArgs: any[]): IGea;
        /**
         * 针对某tag新增一个优先订阅者,订阅执行一次后关闭,或者off显式关闭
         * @param tag 标记
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        oncePrior(tag: any, callback: Function, scope: any, ...callbackArgs: any[]): IGea;
        /**
         * 针对某tag新增一个订阅者
         * @param tag 标记
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        on(tag: any, callback: Function, scope: any, ...callbackArgs: any[]): IGea;
        /**
         * 针对某tag新增一个优先订阅者
         * @param tag 标记
         * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        on(tag: any, callbackLimite: number, callback: Function, scope: any, ...callbackArgs: any[]): IGea;
        /**
         * 针对某tag新增一个订阅者
         * @param tag 标记
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        onPrior(tag: any, callback: Function, scope: any, ...callbackArgs: any[]): IGea;
        /**
         * 针对某tag新增一个优先订阅者
         * @param tag 标记
         * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        onPrior(tag: any, callbackLimite: number, callback: Function, scope: any, ...callbackArgs: any[]): IGea;
        /**
         * 移除一个订阅者
         * @param tag 标记
         * @param callback 回调函数
         * @param scope 回调函数作用域
         */
        off(tag: any, callback: Function, scope: any): IGea;
        /**
         * 触发一个tag,通知所有的tag订阅者(执行回调函数)
         * @param tag 标记
         * @param args 附加回调参数
         */
        /**
         * 移除实例相关的所有订阅者
         * @param scope 实例本身(this)
         */
        offByScope(scope: any): IGea;
        /**
         * 发布一个通知
         * @param tag 通知
         * @param args 通知携带的额外参数
         */
        dispatch(tag: any, ...args: any[]): IGea;
    }
}
declare namespace gea.utility.dispatcher {
    let gameMgr: any;
    function once(dispatcher: any, tag: any, callback: Function, scope: any, ...callbackArgs: any[]): void;
    function oncePrior(dispatcher: any, tag: any, callback: Function, scope: any, ...callbackArgs: any[]): void;
    function on(dispatcher: any, tag: any, callbackLimite: number | Function, callback: Function, scope: any, ...callbackArgs: any[]): void;
    function onPrior(dispatcher: any, tag: any, callbackLimite: number | Function, callback: Function, scope: any, ...callbackArgs: any[]): void;
    function off(dispatcher: any, tag: any, callback: Function, scope: any): void;
    /**
     * 移除`scope`下的所有订阅者
     * @param scope 指定作用域
     * @param dispatcher 指定的dispatcher实例，如果这个值为空，则表示移除调所有dispather下的订阅者
     */
    function offByScope(scope: any, dispatcher?: any): void;
    /**
     * 移除bundle中所有`scope`下的所有订阅者
     * @param bundle
     */
    function offByBundle(bundle: string): void;
    function dispatch(dispatcher: any, tag: any, ...args: any[]): void;
}
declare namespace gea {
    /**
     * @see gea.interfaces.base.IGea
     */
    const instance: interfaces.base.IGea;
}
declare namespace gea.interfaces.base {
    interface IPolling {
        /**轮询帧频 */
        frameRate: number;
        /**
         * 开启一个轮询回调,轮询回调一次后关闭,或者off显式关闭
         * @param callback 回调函数
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        once(callback: Function, scope: any, ...callbackArgs: any[]): IPolling;
        /**
         * 开启一个轮询回调
         * @param callback 回调函数
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        on(callback: Function, scope: any, ...callbackArgs: any[]): IPolling;
        /**
         * 开启一个轮询回调
         * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
         * @param callback 回调函数
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        on(callbackLimite: number, callback: Function, scope: any, ...callbackArgs: any[]): IPolling;
        /**
         * 移除一个轮询回调
         * @param callback 回调函数
         * @param scope 回调函数作用域
         */
        off(callback: Function, scope: any): IPolling;
        /**
        * 开启一个优先的轮询回调,轮询回调一次后关闭,或者offPrior显式关闭
        * @param callback 回调函数--订阅者
        * @param scope 回调函数作用域
        * @param callbackArgs 回调参数
        */
        oncePrior(callback: Function, scope: any, ...callbackArgs: any[]): IPolling;
        /**
         * 开启一个优先的轮询回调
         * @param callback 回调函数
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        onPrior(callback: Function, scope: any, ...callbackArgs: any[]): IPolling;
        /**
         * 开启一个优先的轮询回调
         * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
         * @param callback 回调函数
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        onPrior(callbackLimite: number, callback: Function, scope: any, ...callbackArgs: any[]): IPolling;
        /**
         * 移除实例相关的所有轮询回调
         * @param scope 实例本身(this)
         */
        offByScope(scope: any): IPolling;
    }
}
declare namespace gea {
    const polling: interfaces.base.IPolling;
}
declare namespace gea.interfaces.base {
    interface ITimer {
        /**
        * 新增一个定时回调,执行一次后关闭,或者off显式关闭
        * @param interval 回调频率,设置多少ms触发一次
        * @param callback 回调函数
        * @param scope 作用域
        * @param callbackArgs 回调函数参数
        */
        once(interval: number, callback: Function, scope: any, ...callbackArgs: any[]): ITimer;
        /**
         * 新增一个定时回调
         * @param interval 回调频率,设置多少ms触发一次
         * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
         * @param callback 回调函数
         * @param scope 作用域
         * @param callbackArgs 回调函数参数
         */
        on(interval: number, callback: Function, scope: any, ...callbackArgs: any[]): ITimer;
        on(interval: number, callbackLimite: number, callback: Function, scope: any, ...callbackArgs: any[]): ITimer;
        /**
         * 关闭一个定时回调
         * @param callback 回调函数
         * @param scope 回调函数作用域
         */
        off(callback: Function, scope: any): ITimer;
        /**
         * 移除实例相关的所有定时回调
         * @param scope 实例本身(this)
         */
        offByScope(scope: any): ITimer;
        /**
         * 移除bundle中所有`scope`的实例相关的所有定时回调
         * @param bundle
         */
        offByBundle(bundle: string): void;
        gameMgr: any;
    }
}
declare namespace gea {
    const timer: interfaces.base.ITimer;
}
declare namespace gea.decorators.base {
    function finallyInvoke(callback: Function, scope?: any): Function;
}
declare namespace gea.interfaces.base {
    /**
     * 日志模型
     */
    interface ILog {
        log(...args: any[]): ILog;
        info(...args: any[]): ILog;
        warn(...args: any[]): ILog;
        error(...args: any[]): ILog;
        setPrefix(prefix: string): void;
    }
}
declare namespace gea.utility.entity {
    /**
     * 添加一个组件依附于当前实体
     * + 同一个类型的组件只能在同一个实体上添加一个
     * @param entity 实体
     * @param component 组件实例
     */
    function addComponent<T>(entity: any, component: T): T;
    /**
     * 获取当前实体上的某个组件
     * @param compClass 组件class
     * @param matchPrototype 当通过`compClass`找不到组件时，是否按原型链匹配的方式查找
     * + 当实体上有多个组件的原型与传入的`compClass`相匹配时，始终返回第一个匹配到的值
     * @example
     * class BaseComponent {}
     * class SubComponent extends BaseComponent{}
     * const comp = new SubComponent()
     * gea.utility.base.entiry.addComponent('testEntity', comp)
     * gea.utility.base.entiry.getComponent('testEntity', SubComponent);       //通过子类型自身获取:comp
     * gea.utility.base.entiry.getComponent('testEntity', BaseComponent);      //通过父类型获取，不匹配原型链:undefined
     * gea.utility.base.entiry.getComponent('testEntity', BaseClass, true);    //通过父类型获取，匹配原型链:comp
     */
    function getComponent<T>(entity: any, compClass: {
        prototype: T;
    }, matchPrototype?: boolean): T;
    /**
     * 移除当前实体上的某个组件
     * @param compClass 组件class
     * @param matchPrototype 当通过`compClass`找不到组件时，是否按原型链匹配的方式查找
     * + 当实体上有多个组件的原型与传入的`compClass`相匹配时，始终返回第一个匹配到的值
     * @example
     * class BaseComponent {}
     * class SubComponent extends BaseComponent{}
     * const comp = new SubComponent()
     * gea.utility.base.entiry.addComponent('testEntity', comp)
     * gea.utility.base.entiry.removeComponent('testEntity', SubComponent);       //通过子类型自身删除:comp
     * gea.utility.base.entiry.removeComponent('testEntity', BaseComponent);      //通过父类型删除，不匹配原型链:undefined
     * gea.utility.base.entiry.removeComponent('testEntity', BaseClass, true);    //通过父类型删除，匹配原型链:comp
     */
    function removeComponent<T>(entity: any, compClass: {
        prototype: T;
        new (): T;
    }, matchPrototype?: boolean): T;
}
declare namespace gea.utility.interfaces {
    /**
     * 辨别一个对象是否实现了某个接口
     * @param target 被判断的对象
     * @param discriminator 接口的discriminator定义
     */
    function discriminate<T extends gea.interfaces.base.IInterfaceDiscriminator>(target: T, discriminator: string): boolean;
}
declare namespace gea.enums.ui {
    /**ui类型 */
    enum ui_type {
        /**一般是全屏ui，添加到view层-->gea.ui.abstracts.ViewBase */
        'view' = 0,
        /**一般是挂靠在屏幕四周的块区域ui，添加到panel层-->gea.ui.abstracts.PanelBase */
        'panel' = 1,
        /**子游戏容器层，处于中间 */
        'subGame' = 2,
        /**一般是弹出的窗口ui，添加到window层-->gea.ui.abstracts.WindowBase */
        'window' = 3,
        /**处于以上三种ui的上一层，模态窗口的下一层ui，添加到under_modal层-->gea.ui.abstracts.UnderModalBase */
        'under_modal' = 4,
        /**模态窗口，添加到modal层-->gea.ui.abstracts.ModalBase */
        'modal' = 5,
        /**处于以上所有ui的上一层，添加到over_modal层-->gea.ui.abstracts.OverModalBase */
        'over_modal' = 6
    }
    /**ui层类型 */
    enum layer_type {
        /**view类型ui的容器，第底层 */
        'view' = 0,
        /**panel类型ui的容器，view层上一层 */
        'panel' = 1,
        /**子游戏容器层，处于中间 */
        'subGame' = 2,
        /**window类型ui的容器，panel层的上一层 */
        'window' = 3,
        /**under_modal类型ui容器，window层的上一层 */
        'under_modal' = 4,
        /**modal类型ui容器，under_modal层的上一层 */
        'modal' = 5,
        /**over_modal类型ui容器，modal层的上一层 */
        'over_modal' = 6
    }
    /** 通用UI */
    enum common_ui {
        /** 通用竖屏顶部按钮，可带入3个参数，gm面板信息， 位置，父层，界面回调（可回调带回界面的Node，因为UI加载显示是异步的。所以通过回调获取）
         *  默认顶部显示，添加到UI层级， 可传入父层转移到自己界面上
         * gea.ui.openCommonUI(gea.enums.ui.common_ui.HallTopBarPanel, { args: [[bundler, gameId, PBEnums.Req_SlotGmHall, Exlgm_commandProvider.getAll()],position?, parent?, callBack?: Function] })
         */
        HallTopBarPanel = "HallTopBarPanel",
        /** 通用横屏顶部按钮，可带入3个参数，gm面板信息， 位置，父层，界面回调（可回调带回界面的Node，因为UI加载显示是异步的。所以通过回调获取）
        *  默认顶部显示，添加到UI层级， 可传入父层转移到自己界面上
        * gea.ui.openCommonUI(gea.enums.ui.common_ui.HallTopBarLandPanel, { args: [[bundler, gameId, PBEnums.Req_SlotGmHall, Exlgm_commandProvider.getAll()],position?, parent?, callBack?: Function] })
        */
        HallTopBarLandPanel = "HallTopBarLandPanel",
        /** 通用底部按钮，可带入2个参数， 位置 父层，界面回调（可回调带回界面的Node，因为UI加载显示是异步的。所以通过回调获取）
         *  默认底部显示，添加到UI层级， 可传入父层转移到自己界面上
         * gea.ui.openCommonUI(gea.enums.ui.common_ui.HallBottomBarPanel, { args: [position?, parent?, callBack?: Function] })
         */
        HallBottomBarPanel = "HallBottomBarPanel",
        /** 通用底部按钮，可带入4个参数， 位置 父层 下注列表 下注额，界面回调（可回调带回界面的Node，因为UI加载显示是异步的。所以通过回调获取）
         *  默认底部显示，添加到UI层级， 可传入父层转移到自己界面上
         * gea.ui.openCommonUI(gea.enums.ui.common_ui.HallTopBarLandPanel, { args: [position?, parent?, betList?, bet?, callBack?: Function] })
         */
        HallBottomBarLandPanel = "HallBottomBarLandPanel",
        /**通用GM 打开此界面需要带入参数  bundle名 gameId GM协议名称 GM配置列表
         * extebdCmd 可传入自定义GM指令列表，用于方便游戏自身测试所有的GM， ID设值大一些不要和配置表重复，带入内容和回调方法
         * gea.ui.openCommonUI(gea.enums.ui.common_ui.HallComGMPanel, { args: [bundler, gameId, "SlotGmGameReq", Exlgm_commandProvider.getAll(),
         * extendCmd?: { id: number, desc: string, pattern: string, auto_close: number, callFun: Function }[]] })
         */
        HallComGMPanel = "HallComGMPanel",
        /**
         * 通用提示信息界面
         * gea.ui.openCommonUI(gea.enums.ui.common_ui.HallAlertPanel, { args: [tips 提示内容, notAuto? 不自动关闭,pos? 位置] })
         */
        HallAlertPanel = "HallAlertPanel",
        /** 通用 过渡界面- 从大厅进入游戏或者从游戏退回大厅时显示的过渡界面 */
        HallChangeEnterPanel = "HallChangeEnterPanel",
        /** 通用 投注额选择界面  需要带入参数  chip: number, bet: number, win: number, dataInfo: any
         *  dataInfo 为子游戏的数据类， 需要包含有 betBase   betJumlah  jumlahList  SendSlotSettingReq
        */
        HallTaruhanPanel = "HallTaruhanPanel",
        /** 通用竖版游戏 下注底部栏 界面 可带入4个参数， 位置 父层，颜色，star按钮资源，界面回调（可回调带回界面， 因为UI加载显示是异步的。所以通过回调获取）
         *  star按钮资源传入列表  [按钮底图，按钮彩色旋转图，按钮灰色旋转图，按钮点击光效动画，按钮悬停光效动画]
         *  按钮底图，按钮彩色旋转图，按钮灰色旋转图 这3个如果不传或者传null则按钮空白，但是可点击
         *  按钮点击光效动画，按钮悬停光效动画 如果不传或者传null则使用默认动画
         *  star按钮资源 如果传入null 会移除通用界面的start按钮，由游戏自身去创建
         *  回调会返回  界面 this
         *  默认底部显示，添加到UI层级， 可传入父层转移到自己界面上
         * gea.ui.openCommonUI(gea.enums.ui.common_ui.HallBetComponent, { args: [position: cc.Vec2, parent: cc.Node, color: cc.Color, callback: Function] })
         */
        HallBetComponent = "HallBetComponent",
        /**
         *
         */
        HallComFlyMoneyPanel = "HallComFlyMoneyPanel",
        /**
         * 通用游戏整体底部栏- 包含货币信息和操作按钮
         */
        HallBottomPanel = "HallBottomPanel",
        /**
         * 通用子游戏跑马灯和win  totalwin显示
         */
        HallRewardNoticePanel = "HallRewardNoticePanel",
        /** 通用奖励弹出界面
         * rewards: { "ItemId": number, "Num": number }[], needFlyMoney: boolean = true, callBack: Function, args: any
        */
        HallGetRewardPanel = "HallGetRewardPanel",
        /**
         * 大厅 子游戏自动旋转 选择次数界面
         */
        HallAutoSelectPanel = "HallAutoSelectPanel",
        /**
         * 子游戏通用历史记录日期选择界面
         */
        HallHisCustomDatePanel = "HallHisCustomDatePanel",
        /**
         * 网络状态显示界面  position?: cc.Vec2, parent?: cc.Node, callBack?: Function
         */
        HallNetworkPanel = "HallNetworkPanel"
    }
}
declare namespace gea.interfaces.ui {
    type IUIClass = typeof adapters.abstracts.ui.UIBase;
    interface IUI {
        /**
         * 自定义实例的展示动画
         */
        readonly customTweenShow: gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        /**
         * 自定义实例的移除动画
         */
        readonly customTweenHide: gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        /**
         * 添加到舞台前的回调/UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackBeforeShow(...args: any[]): void;
        /**
         * 添加到舞台后的回调/UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackAfterShow(...args: any[]): void;
        /**
         * 从舞台移除前的回调
         * @param args
         */
        callbackBeforeHide(...args: any[]): void;
        /**
         * 从舞台移除后的回调
         * @param args
         */
        callbackAfterHide(...args: any[]): void;
    }
}
declare namespace gea.enums.tween {
    /**ease类型 */
    enum ease {
        Linear = 0,
        SineIn = 1,
        SineOut = 2,
        SineInOut = 3,
        QuadIn = 4,
        QuadOut = 5,
        QuadInOut = 6,
        CubicIn = 7,
        CubicOut = 8,
        CubicInOut = 9,
        QuartIn = 10,
        QuartOut = 11,
        QuartInOut = 12,
        QuintIn = 13,
        QuintOut = 14,
        QuintInOut = 15,
        ExpoIn = 16,
        ExpoOut = 17,
        ExpoInOut = 18,
        CircIn = 19,
        CircOut = 20,
        CircInOut = 21,
        ElasticIn = 22,
        ElasticOut = 23,
        ElasticInOut = 24,
        BackIn = 25,
        BackOut = 26,
        BackInOut = 27,
        BounceIn = 28,
        BounceOut = 29,
        BounceInOut = 30,
        EaseInOut = 31
    }
}
declare namespace gea.discriminator {
    enum interfaces {
        tweener = "gea.interfaces.tween.ITweener"
    }
}
declare namespace gea.interfaces.tween {
    interface ITweenOption {
        easeType?: gea.enums.tween.ease;
        delay?: number;
        repeatCount?: number;
        repeatInterval?: number;
        yoyo?: boolean;
        yoyoDelay?: number;
        callbackStart?: (tweener: ITweener, startCount: number, ...args: any[]) => void;
        callbackStartScope?: any;
        callbackStartArgs?: any[];
        callbackComplete?: (tweener: ITweener, completeCount: number, ...args: any[]) => void;
        callbackCompleteScope?: any;
        callbackCompleteArgs?: any[];
    }
    interface ITweener extends gea.interfaces.base.IInterfaceDiscriminator {
        /**
         * 标记为ITweener接口
         */
        readonly discriminator: gea.discriminator.interfaces.tweener;
        /**
         * 缓动对象
         */
        readonly target: any;
        /**
         * 缓动总时长
         */
        readonly totalDuration: number;
        /**
         * 开始
         */
        start(): ITweener;
        /**
         * 暂停
         */
        pause(): ITweener;
        /**
         * 从pause恢复继续运行
         */
        resume(): ITweener;
        /**
         * 停止缓动
         * @param forceComplete 是否强制设置为完成状态
         */
        stop(forceComplete: boolean): ITweener;
        /**
         * 重新开始
         * + `startCount`和`completeCount`都会重新计数
         * + `gea.tween.create`时需指定不自动释放，否则会在运行`finish`或者`stop`的时候自动释放
         */
        reStart(): ITweener;
        /**
         * 追加一个延迟
         * @param value 延迟时间，单位:`ms`
         */
        delay(value: number): ITweener;
        /**
         * 追加一个回调
         * @param callback 回调函数
         * @param scope 回调函数作用域
         * @param args 回调参数
         */
        callback(callback: (...args: any[]) => void, scope?: any, ...args: any): ITweener;
        /**
         * @param value 重复次数
         * + 默认值为0，表示不重复。<0表示无限重复
         */
        repeatCount(value: number): ITweener;
        /**
         * 设置重复间隔
         * @param value 间隔时间
         * + 单位ms
         */
        repeatInterval(value: number): ITweener;
        /**
         * repeatCount不为0时有效
         * @param value
         * + false表示直接从起始值开始重复
         * + true表示先从最终值按照缓动路径回到起始值再开始重复
         * + 默认为false
         */
        yoyo(value: boolean): ITweener;
        /**
         * 设置yoyo动作延迟时间
         * @param value
         */
        yoyoDelay(value: number): ITweener;
        /**
         * 追加一个from缓动
         * @param duration 缓动总时长，单位:`ms`
         * @param property 缓动属性的起始值，目标值为当前值
         * @param option 额外参数
         * + easeType 缓动类型 @see gea.enums.tween.ease
         * + delay 缓动开始前的延迟时间，单位:`ms`
         * + repeatCount 重复次数，默认值为0，表示不重复。<0表示无限重复
         * + repeatInterval 重复间隔，单位:`ms`
         * + yoyo 是否回到缓动开始的位置
         * + yoyoDelay yoyo延迟时间，单位:`ms`
         * + callbackStart 缓动开始的回调
         * + callbackStartScope callbackStart作用域
         * + callbackStartArgs callbackStart额外参数
         * + callbackComplete 此条缓动结束的回调
         * + callbackCompleteScope callbackComplete作用域
         * + callbackCompleteArgs callbackComplete 额外参数
         */
        from(duration: number, property: {
            [key: string]: number;
        }, option?: {
            easeType?: gea.enums.tween.ease;
            delay?: number;
            repeatCount?: number;
            repeatInterval?: number;
            yoyo?: boolean;
            yoyoDelay?: number;
            callbackStart?: (tweener: ITweener, startCount: number, repeatCount: number, ...args: any[]) => void;
            callbackStartScope?: any;
            callbackStartArgs?: any[];
            callbackComplete?: (tweener: ITweener, completeCount: number, repeatCount: number, ...args: any[]) => void;
            callbackCompleteScope?: any;
            callbackCompleteArgs?: any[];
        }): ITweener;
        /**
         * 追加一个to缓动
         * @param duration 缓动总时长，单位:`ms`
         * @param property 缓动属性的目标值，起始值为当前值
         * @param option 额外参数
         * + easeType 缓动类型 @see gea.enums.tween.ease
         * + delay 缓动开始前的延迟时间,单位:`ms`
         * + repeatCount 重复次数，默认值为0，表示不重复。<0表示无限重复
         * + repeatInterval 重复间隔，单位:`ms`
         * + yoyo 是否回到缓动开始的位置
         * + yoyoDelay yoyo延迟时间，单位:`ms`
         * + callbackStart 缓动开始的回调
         * + callbackStartScope callbackStart作用域
         * + callbackStartArgs callbackStart额外参数
         * + callbackComplete 此条缓动结束的回调
         * + callbackCompleteScope callbackComplete作用域
         * + callbackCompleteArgs callbackComplete 额外参数
         */
        to(duration: number, property: {
            [key: string]: number;
        }, option?: {
            easeType?: gea.enums.tween.ease;
            delay?: number;
            repeatCount?: number;
            repeatInterval?: number;
            yoyo?: boolean;
            yoyoDelay?: number;
            callbackStart?: (tweener: ITweener, startCount: number, repeatCount: number, ...args: any[]) => void;
            callbackStartScope?: any;
            callbackStartArgs?: any[];
            callbackComplete?: (tweener: ITweener, completeCount: number, repeatCount: number, ...args: any[]) => void;
            callbackCompleteScope?: any;
            callbackCompleteArgs?: any[];
        }): ITweener;
        /**
         * 追加一个fromTo缓动
         * @param duration 缓动总时长，单位:`ms`
         * @param propertyFrom 缓动的起始属性值
         * @param propertyTo 缓动的目标属性值
         * @param option 额外参数
         * + easeType 缓动类型 @see gea.enums.tween.ease
         * + delay 缓动开始前的延迟时间,单位:`ms`
         * + repeatCount 重复次数，默认值为0，表示不重复。<0表示无限重复
         * + repeatInterval 重复间隔，单位:`ms`
         * + yoyo 是否回到缓动开始的位置
         * + yoyoDelay yoyo延迟时间，单位:`ms`
         * + callbackStart 缓动开始的回调
         * + callbackStartScope callbackStart作用域
         * + callbackStartArgs callbackStart额外参数
         * + callbackComplete 此条缓动结束的回调
         * + callbackCompleteScope callbackComplete作用域
         * + callbackCompleteArgs callbackComplete 额外参数
         */
        fromTo(duration: number, propertyFrom: {
            [key: string]: number;
        }, propertyTo: {
            [key: string]: number;
        }, option?: {
            easeType?: gea.enums.tween.ease;
            delay?: number;
            repeatCount?: number;
            repeatInterval?: number;
            yoyo?: boolean;
            yoyoDelay?: number;
            callbackStart?: (tweener: ITweener, startCount: number, repeatCount: number, ...args: any[]) => void;
            callbackStartScope?: any;
            callbackStartArgs?: any[];
            callbackComplete?: (tweener: ITweener, completeCount: number, repeatCount: number, ...args: any[]) => void;
            callbackCompleteScope?: any;
            callbackCompleteArgs?: any[];
        }): ITweener;
        /**
         * 开始缓动回调
         * @param callback
         * @param scope
         * @param callbackArgs
         */
        appendCallbackStart(callback: (tweener: ITweener, startCount: number, repeatCount: number, ...args: any[]) => void, scope?: any, ...callbackArgs: any[]): ITweener;
        /**
         * 整个缓动过程中的属性变化回调
         * @param callback
         * @param scope
         * @param callbackArgs
         */
        appendCallbackUpdate(callback: (tweener: ITweener, ...args: any[]) => void, scope?: any, ...callbackArgs: any[]): ITweener;
        /**
         * 整个缓动过程每次完成时都回调
         * @param callback
         * @param scope
         * @param callbackArgs
         */
        appendCallbackComplete(callback: (tweener: ITweener, completeCount: number, repeatCount: number, ...args: any[]) => void, scope?: any, ...callbackArgs: any[]): ITweener;
    }
}
declare namespace gea.adapters.abstracts.ui {
    abstract class UIBase extends cc.Component implements gea.interfaces.ui.IUI {
        /**
         * 模态UI
         */
        static get modal(): boolean;
        /**
         * 获取prefabUrl
         */
        static get prefabUrl(): string;
        /**ui类型 */
        static get uiType(): gea.enums.ui.ui_type;
        /**bundle 名称 */
        static get bundle(): string;
        /**是否不能被hideAll 方法关闭，自己控制界面的关闭，不被hideAll关闭 */
        static get excludeHideAll(): boolean;
        /** 依赖的资源URL列表
         *  1.该列表内的资源会随着此ui一起被加载
            2.并非依赖资源,但希望随此ui一起加载的资源也可以拖到这个列表`,
         */
        static get necessaryUrls(): {
            url: string;
            type?: typeof cc.Asset;
        }[];
        get customTweenShow(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        get customTweenHide(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        static get runTimeDynamicAsset(): {
            url: string;
            type?: typeof cc.Asset;
        }[];
        get nodePreventTapClose(): cc.Node;
        set nodePreventTapClose(value: cc.Node);
        set autoRelease(value: boolean);
        get autoRelease(): boolean;
        set autoReleaseDelayTime(value: number);
        get autoReleaseDelayTime(): number;
        set blockEvents(value: boolean);
        get blockEvents(): boolean;
        set bundle(value: string);
        get bundle(): string;
        set multiInstance(value: boolean);
        get multiInstance(): boolean;
        set resBundle(value: string);
        get resBundle(): string;
        set checkAtuoUI(value: boolean);
        get checkAtuoUI(): boolean;
        set previewAtuoUI(value: boolean);
        get previewAtuoUI(): boolean;
        get needReleaseList(): cc.Asset[];
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        private static _mapRuntimeDynamicAsset;
        langAssets: cc.Node[];
        _nodePreventTapClose: cc.Node;
        _autoRelease: boolean;
        _autoReleaseDelayTime: number;
        _blockEvents: boolean;
        _multiInstance: boolean;
        _bundle: string;
        _needReleaseList: any[];
        _checkAtuoUI: boolean;
        _previewAtuoUI: boolean;
        constructor();
        static appendRunTimeDynamicAsset(...assets: {
            url: string;
            type?: typeof cc.Asset;
        }[]): void;
        static clearRunTimeDynamicAsset(): void;
        /** 遍历检查自动加载UI组件 */
        recursiveScreening(node: cc.Node): void;
        /** 遍历检查自动加载UI组件，显示预览 */
        recursiveScreeningPrivew(node: cc.Node): void;
        /**
         * 设置
         * @param value
         */
        static setup(value: {
            modal?: boolean;
        }): void;
        /**
         * 添加到舞台前的回调/UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackBeforeShow(...args: any[]): void;
        /**
         * 添加到舞台后的回调//UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackAfterShow(...args: any[]): void;
        /**
         * 从舞台移除前的回调
         * @param args
         */
        callbackBeforeHide(...args: any[]): void;
        /**
         * 从舞台移除后的回调
         * @param args
         */
        callbackAfterHide(...args: any[]): void;
        /**  转换多语言图片 */
        tranPicTxt(picName: string, sp: cc.Node): void;
        /** 转换多语言文本 */
        tranStringTxt(keyName: string, sp: cc.Node, ...args: any[]): void;
        /** 获取多语言 spriteFrame */
        tranSpriteFrame(picName: string): Promise<cc.SpriteFrame>;
        /** 是否已经自动翻译 */
        isAutoTranLang: boolean;
        /** 自动翻译 */
        autoTranLangAsstes(): void;
        /** 添加进待销毁列表，界面关闭回收时会进行对应的清理回收
         *  内部自动处理，目前标记弃用，外部可以不需要使用
         */
        pushToReleaseList(asset: any): void;
        /** 递归遍历节点添加到回收中 */
        checkPushToRelease(node?: cc.Node, topIns?: gea.adapters.abstracts.ui.UIBase): void;
        /**
         * 断线重连处理，断线重连后会调用此方法
         * @returns 返回 1 则会自动关闭mainPanel界面重新打开
         */
        doReConnect(): number;
        /**
         * 回收清理资源
         */
        releaseAll(): void;
    }
}
declare namespace gea.adapters.abstracts.ui {
    abstract class UIExtendBase extends cc.Component implements gea.interfaces.ui.IUI {
        _bundle: string;
        set bundle(value: string);
        get bundle(): string;
        retainComponent: boolean;
        _preview: boolean;
        set preview(value: boolean);
        get preview(): boolean;
        /** 更新预览 */
        updatePreview(): void;
        onDestroy(): void;
        callbackBeforeHide(...args: any[]): void;
        callbackAfterHide(...args: any[]): void;
        get customTweenShow(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        get customTweenHide(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        /**
          * 添加到舞台前的回调/UI已经在显示中,再次调用show,也会回调
          * @param args
          */
        callbackBeforeShow(...args: any[]): void;
        /**
         * 添加到舞台后的回调//UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackAfterShow(...args: any[]): void;
    }
}
declare namespace gea.adapters.interfaces.ui {
    interface IUIManager {
        /**
         * 视窗大小，游戏视图窗口
         */
        readonly viewPort: {
            width: number;
            height: number;
            halfWidth: number;
            halfHeight: number;
        };
        /**
         * 模态ui遮罩
         */
        readonly nodeModal: cc.Node;
        /**
         * 显示一个ui
         * @param uiClass 要显示的ui的class
         * @param option  额外参数
         * + tweener: 通过gea.tween.create创建
         * + args: 额外参数，会携带在callbackBeforeShow、callbackAfterShow中
         */
        show(uiClass: gea.interfaces.ui.IUIClass, option?: {
            tween?: {
                duration: number;
                from?: {
                    [key: string]: number;
                };
                to?: {
                    [key: string]: number;
                };
                option?: gea.interfaces.tween.ITweenOption;
            };
            args?: any[];
        }): IUIManager;
        /**
         * 隐藏一个ui
         * @param uiClass 要显示的ui的class或者ui实例
         * @param option  额外参数
         * + tweener: 通过gea.tween.create创建
         * + args: 额外参数，会携带在callbackBeforeShow、callbackAfterShow中
         */
        hide(uiClass: gea.interfaces.ui.IUIClass | gea.adapters.abstracts.ui.UIBase, option?: {
            tween?: {
                duration: number;
                from?: {
                    [key: string]: number;
                };
                to?: {
                    [key: string]: number;
                };
                option?: gea.interfaces.tween.ITweenOption;
            };
            args?: any[];
        }): IUIManager;
        /**
         * 隐藏所有ui
         */
        hideAll(excludeUIClass?: gea.interfaces.ui.IUIClass[]): IUIManager;
        /**
         * 隐藏指定bundle的所有UI
         * @param bundle
         */
        hideBundleUIAll(bundle: string): IUIManager;
        /**
        /**
         * 判断某个ui是否正在显示
         * @param uiClass
         */
        isShowing(uiClass: gea.interfaces.ui.IUIClass): boolean;
        /**
         * ui设置
         * @param config 设置
         * + modal，模态窗口黑色遮罩的设置
         */
        setup(config: {
            modal?: {
                tweenShow?: {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                } | {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                }[];
                tweenHide?: {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                } | {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                }[];
            };
        }): IUIManager;
        /**
         * 针对某ui事件新增一个订阅者,订阅执行一次后关闭,或者off显式关闭
         * @param tag 标记
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         * @see gea.events.ui
         */
        once(tag: any, callback: Function, scope: any, ...callbackArgs: any[]): IUIManager;
        /**
         * 针对某ui事件新增一个订阅者
         * @param tag 标记
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         * @see gea.events.ui
         */
        on(tag: any, callback: Function, scope: any, ...callbackArgs: any[]): IUIManager;
        /**
         * 针对某ui事件新增一个订阅者
         * @param tag 标记
         * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         * @see gea.events.ui
         */
        on(tag: any, callbackLimite: number, callback: Function, scope: any, ...callbackArgs: any[]): IUIManager;
        /**
         * 移除一个订阅者
         * @param tag 标记
         * @param callback 回调函数
         * @param scope 回调函数作用域
         */
        off(tag: any, callback: Function, scope: any): IUIManager;
        /**
         * 触发一个tag,通知所有的tag订阅者(执行回调函数)
         * @param tag 标记
         * @param args 附加回调参数
         */
        /**
         * 移除实例相关的所有订阅者
         * @param scope 实例本身(this)
         */
        offByScope(scope: any): IUIManager;
        /**
         * 清除回收该 bundle在UI中的所有信息和界面，并回释放此包中的所有资源
         * @param bundle
         * @returns
         */
        releaseBundle(bundle: string): void;
        addBundleScene(bundle: string, sceneNode: cc.Node): void;
        /** 获取指定bundle 对应的UI层 如果bundle传空，则会从默认图层找 */
        getBundleLayer(bundle: string, layerType: gea.enums.ui.ui_type): cc.Node;
        /** 注册通用UI */
        registerCommonUI(name: string, uiClass: gea.interfaces.ui.IUIClass): IUIManager;
        /** 打开通用UI */
        openCommonUI(name: string, option?: {
            tween?: {
                duration: number;
                from: {
                    [key: string]: number;
                };
                to: {
                    [key: string]: number;
                };
                option: gea.interfaces.tween.ITweenOption;
            };
            args: any[];
        }): IUIManager;
        /** 关闭通用UI */
        closeCommonUI(name: string, option?: {
            tween?: {
                duration: number;
                from: {
                    [key: string]: number;
                };
                to: {
                    [key: string]: number;
                };
                option: gea.interfaces.tween.ITweenOption;
            };
            args: any[];
        }): IUIManager;
        getCommonUIClass(name: string): gea.interfaces.ui.IUIClass;
        /** 关闭所有通用UI */
        closeAllCommonUI(): IUIManager;
        /** 获取指定的UI界面，显示中的才能获取到。未显示返回 null */
        getShowUI<T extends adapters.abstracts.ui.UIBase>(uiClass: gea.interfaces.ui.IUIClass): T;
        /** 检查某通用UI是否打开中 */
        isShowingCommonUI(name: any): boolean;
        /** 获取指定的通用UI界面，显示中的才能获取到。未显示返回 null */
        getShowCommonUI<T extends adapters.abstracts.ui.UIBase>(name: string): T;
        setLoadProgress(loadProgress: any): any;
        /** 获取模态层黑底遮罩状态  判断当前是否有模态界面显示 */
        getModeLayerStatus(): boolean;
        /**
         * 添加canvas 层  目前用于添加子游戏3D层, 层级名字不能命名为 canvas
         * @param canvas
         * @param bundle
         */
        addNewCanvas(canvas: cc.Node, bundle: string): any;
        /** 清理其他canvas */
        clearOtherCanvas(): any;
    }
}
declare namespace gea.events {
    enum ui {
        /**开始加载ui */
        load_start = "gea.events.ui.load_start",
        /**ui加载进度通知 */
        load_progress = "gea.events.ui.load_progress",
        /**ui加载完成通知 */
        load_complete = "gea.events.ui.load_complete",
        /**ui添加到图层显示完成通知 */
        ui_show_complete = "gea.events.ui.ui_show_complete",
        /**ui加载失败通知 */
        load_failed = "gea.events.ui.load_failed",
        /**界面上ui数量改变通知 */
        ui_number_change = "gea.events.ui.ui_number_change",
        /** app界面加载进度更新 */
        app_loading_progress = "gea.events.ui.app_loading_progress",
        /** 游戏界面加载进度更新 */
        game_loading_progress = "gea.events.ui.game_loading_progress",
        /** 界面尺寸改变 */
        scene_stage_resize = "gea.events.ui.scene_stage_resize",
        /** 模态层 状态更新 */
        modal_layer_status_update = "gea.events.ui.modal_layer_status_update"
    }
    /** webView界面的消息传送 */
    enum webView {
        /** 发送消息 */
        message = "gea.events.webView.message",
        /** 顶部条状态改变 */
        change_top_bar = "gea.events.webView.change_top_bar",
        /** 关闭游戏 */
        close_game = "gea.events.webView.close_game",
        /** 更新货币显示 */
        update_money = "gea.events.webView.update_money",
        /** 更新等级显示 */
        update_exp_level = "gea.events.webView.update_exp_level",
        /** 网页版加载失败 通知网页上层*/
        launch_failed = "gea.events.webView.launch_failed",
        /** webview 传递 发送协议 */
        netSend = "gea.events.webView.netSend",
        /** 传递协议给 webview */
        netReceive = "gea.events.webView.netReceive"
    }
    enum jsb {
        jsbCall = "gea.events.jsb.jsbCall",
        down_load_progress = "gea.events.jsb.down_load_progress",
        down_load_error = "gea.events.jsb.down_load_error",
        down_load_complete = "gea.events.jsb.down_load_complete",
        /** app的loading界面关闭 */
        app_loading_close = "gea.events.jsb.app_loading_close",
        /** @deprecated */
        /** 谷歌登录返回 带回3个参数  pName  id  idToken, 如果参数空表示登录失败   */
        google_login = "gea.events.jsb.google_login",
        /** 第三方登录请求  携带一个json字符串
        *info.put("idType",idType);  3 facebook  4 google
        * info.put("pName",pName);
        * info.put("id",id);
        * info.put("idToken",id);
        * info.put("errCode",errCode);
        * info.put("result",resultInfo);
        * */
        other_login_req = "gea.events.jsb.other_login_req",
        /** 谷歌商店商品购买成功， 返回消费的商品新消息
         *  携带两个参数 一个结果json字符传。
         *   info.put("data",resultInfo);
            info.put("code",code);
            info.put("type", type);
         *
         *  一个商店购买返回信息字符串
         *  {"orderId":"GPA.3322-8975-9826-09418","packageName":"org.cocos2d.duomi3",
         * "productId":"1001","purchaseTime":1705463679713,"purchaseState":0,
         * "purchaseToken":"flcipcngcladiglnfpbegbdk.AO-J1OxwO7K-hsHIeoxr4fY57qsjsjdIHep5TOfj2BjSAYI8Na8o122nRY3TUzbEPkvxuCUGZQRxbqmWI35WjmTBOe7p-q1KHA",
         * "quantity":1,"acknowledged":false}
         *
         *  code  错误码， 有值说明购买过程中错误返回
         *  type     错误类型 有错误码返回时会带有类型
         *          1 获取商品信息错误返回（3） 获取商品信息失败，请检查网络情况
         *          2 支付错误返回（code 2 玩家取消，  其他值 其他异常错误，请重试）
         *          3 google 消费失败， 返回对应错误码和消费token   需要联系客服处理
         *          4 消费成功够 获取商品信息失败，需要联系客服处理
         */
        google_pay_complete = "gea.events.jsb.google_pay_complete",
        /** 清除游戏缓存后返回 */
        clear_cache_complete = "gea.events.jsb.clear_cache_complete"
    }
}
declare namespace gea.manager {
    export class ResCacheData {
        /** 是否列表加载 */
        isloadList: boolean;
        /** 列表加载时， 记录  uuid和path */
        loadListMap: Map<string, string>;
        /** 加载资源url地址 */
        url: string;
        /** 是否已经加载完成 */
        isLoaded: boolean;
        /**加载完成数据
         * cc.Prefab
         * cc.SpriteAtlas
         * cc.SpriteFrame
         * cc.AudioClip
         * cc.Font
         * sp.SkeletonData
         * cc.ParticleAsset
         * cc.Texture2D
         * cc.JsonAsset
         * */
        data: cc.Asset | cc.Asset[];
        /**加载资源类型 */
        assetType: typeof cc.Asset;
        bundle: string;
        bindBundle: string;
        /** 超时时间戳（毫秒） */
        loadTimeOut: number;
        /** 超时或者错误重试次数 */
        retryNum: number;
        /** 完成回调，在资源正在加载过程中，又有其它地方调用加载同一个资源，此时需要等待资源加载完成，统一回调 */
        finishCallBack: ((error: Error, assets: any, data?: any) => void)[];
        /** 加载进度回调 */
        onProgressCallBack: ((finish: number, total: number, item: cc.AssetManager.RequestItem) => void)[];
        doFinishCb(data: any, error?: Error): void;
        doProgressCallBack(finish: number, total: number, item: cc.AssetManager.RequestItem): void;
        setToLoadListMap(uuid: string, path: string): void;
        clear(): void;
    }
    class RemoteCaches {
        private _caches;
        private _bundleCaches;
        private _spriteFrameCaches;
        /**
         * 获取远程缓存数据
         * @param type 远程奖状类型
         * @param url 远程地址
         */
        get(url: string): ResCacheData;
        getSpriteFrame(url: string): ResCacheData;
        setSpriteFrame(url: string, data: any): cc.SpriteFrame;
        set(url: string, data?: ResCacheData): ResCacheData;
        remove(url: string): boolean;
        setToBundle(bundle: string, url: string): void;
        removeBundle(bundle: string): void;
        showCaches(): void;
    }
    export class CacheManager {
        private logTag;
        private _bundles;
        private _remoteCaches;
        get remoteCaches(): RemoteCaches;
        get(bundle: string, path: string, isCheck?: boolean): ResCacheData;
        set(bundle: string, path: string, data: ResCacheData): void;
        createCache(bundle: string, path: string): ResCacheData;
        remove(bundle: string, path: string): boolean;
        removeBundle(bundle: string): void;
    }
    export {};
}
declare namespace gea.manager {
    class RemoteLoader {
        private BUNDLE_REMOTE;
        private _logTag;
        private _cacheMgr;
        private _remoteLoadPipes;
        set cacheMgr(value: CacheManager);
        loadImage(url: string, bindBundle?: string): Promise<cc.SpriteFrame>;
        loadSkeleton(path: string, name: string, bindBundle?: string): Promise<sp.SkeletonData>;
        private _loadRemoteRes;
        /** 当前下载中远程资源数量 */
        private _onLoadRemoteNum;
        /** 最大下载红远程资源数量 */
        private _maxLoadRemoteNum;
        /** 立即下载 */
        private _doLoadRemote;
        private _addToLoadingList;
        private _removeFromLoadingList;
        private _onDoNextRemoteLoad;
    }
    class AssetManager implements gea.interfaces.manager.IAssetManager {
        private logTag;
        private _cacheMgr;
        private _remote;
        initRemote(): RemoteLoader;
        getCacheMgr(): CacheManager;
        getBundle(bundle: string): cc.AssetManager.Bundle;
        /** 马上加载批量资源,进入这个方法说明已经判断了资源是否下载过，直接加载 */
        doLoadList(bundle: string, paths: string[], onProgress?: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete?: (error: Error, assets: cc.Asset[]) => void): void;
        /** 马上加载批量资源,进入这个方法说明已经判断了资源是否下载过，直接加载 */
        loadDir(bundle: string, path: string, onProgress?: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete?: (error: Error, assets: cc.Asset[]) => void): void;
        /**
         * 预加载
         * @param bundle
         * @param paths
         * @param onProgress
         * @param onComplete
         */
        preLoad(bundle: string, paths: string | string[], onProgress: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete: (error: Error, items: cc.AssetManager.RequestItem[]) => void): void;
        slientLoadList: {
            bundle: string;
            url: string;
            type?: typeof cc.Asset;
        }[];
        /** 后台静默加载 */
        appebdSilentPreload(bundle: string, url: string, type?: typeof cc.Asset): AssetManager;
        /** 清除指定bundle资源的静默加载 */
        clearGameSlientPreload(bundle: string): AssetManager;
        /** 静默检查轮询 */
        checkSlientPreLoad(): void;
        getPrefab(bundle: string, prefabUrl: string): cc.Prefab;
        getAsset(bundle: string, patch: string, type: typeof cc.Asset): cc.Asset;
        releaseAsset(bundle: string, path: string, type: typeof cc.Asset): void;
        load(bundle: string, path: string, type: typeof cc.Asset, onProgress: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete: (error: Error, assets: cc.Asset | cc.Asset[], data?: gea.manager.ResCacheData) => void): void;
        /** 进度回调 */
        private _onProgress;
        /** 加载完成回调 */
        private _onLoadComplete;
        /** 加载远程图片 */
        loadRemote(url: string, bindBundle?: string): Promise<cc.SpriteFrame>;
        /** 加载远程图片 */
        loadRemoteSkeleton(path: string, name: string, bindBundle?: string): Promise<sp.SkeletonData>;
        /** 编辑器加载  游戏逻辑能禁用 */
        loadEditorSpineRes(url: string, callback: Function): void;
    }
    const assetManager: AssetManager;
}
declare namespace gea.manager {
    class LoadManager {
        /** 记录一下加载的sprite的url .避免出现瞬间加载不同资源结果不符合预期的问题 */
        loadSpriteMap: Map<string, string>;
        /**
         * 设置加载本地图片
         * @param url  string 图片路径 | {url:图集路径，key:图片key}
         * @param sprite
         * @param bundle
         * @param completeCallback
         */
        setSpriteFrame(url: string | {
            url: string;
            key: string;
        }, sprite: cc.Sprite, bundle: string, completeCallback?: (data: cc.SpriteFrame) => void): void;
        /**
         * 设置远程资源图
         * @param url
         * @param sprite
         * @param bundle 绑定关联的bundle, 例如这个资源只是在某个子游戏game1中使用的，就把game1的bundle名字带进来，这样如果game1关闭清理的时候，这个远程资源也会默认被自动清理
         *                      如果在加载过程中game1被清理关闭了。加载完成时候会被停止不会再回调，加载完成的资源也会被清理
         * @param completeCallback
         */
        setRemoteSpriteFrame(url: string, sprite: cc.Sprite, bindBundle: string, completeCallback?: (data: cc.SpriteFrame) => void): void;
        /**
         * 按尺寸加载远程图片
         * @param originUrl
         * @param sprite
         * @param bindBundle
         * @param size
         * @param completeCallback
         */
        setRemoteSpriteFrameSize(originUrl: string, sprite: cc.Sprite, bindBundle: string, size: cc.Size, completeCallback?: (data: cc.SpriteFrame) => void): void;
        /**
         * 加载spine动画
         * @param path
         * @param bundle
         * @param complete
         * @param onProgress
         */
        loadSkeleton(path: string, bundle: string, complete: (error: Error, assets: sp.SkeletonData, data?: ResCacheData) => void, onProgress?: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void): void;
        /**
         * 加载远程spien动画资源
         * @param path
         * @param spineName
         * @param completeCallback
         * @param bindBundle 绑定关联的bundle, 例如这个资源只是在某个子游戏game1中使用的，就把game1的bundle名字带进来，这样如果game1关闭清理的时候，这个远程资源也会默认被自动清理
         *                      如果在加载过程中game1被清理关闭了。加载完成时候会被停止不会再回调，加载完成的资源也会被清理
         */
        loadRemoteSkeleton(path: string, spineName: string, completeCallback: (assets: sp.SkeletonData, data?: ResCacheData, error?: Error) => void, bindBundle?: string): void;
    }
}
declare namespace gea.manager {
    class AudiosManager implements gea.interfaces.manager.IAudiosManager {
        /** 默认Button点击会设置通用点击音效，
         *  如果不需要的，把Button的name设置为这个，PS：是设置Button Component的name, 不是Node节点的
         * */
        NOT_CLICK_AUDIO: string;
        /** 映射ID */
        audioIDMap: Map<number, number>;
        seqId: number;
        /** 是否静音音效 单禁止音效*/
        isMuteSound: boolean;
        /** 是否静音背景音效 单禁止背景音乐*/
        isMuteBgMusic: boolean;
        /** 是否静音状态 - 全禁音*/
        isMute: boolean;
        /** 是否屏蔽音效音乐 效果和全静音一样,但是不会存缓存*/
        isShield: boolean;
        /** 音效音量百分比。默认100 */
        volumePer: number;
        /** 是否已经点击过屏幕 */
        hasTouch: boolean;
        curBgMusic: {
            audioName: string;
            bundle: string;
            volume: number;
            audioId: number;
        };
        constructor();
        getAudioId(): number;
        /** 获取 对应 cc.audioEngine 中播放的AudioId */
        getPlayAudioId(auid: number): number;
        /** 播放背景音乐  默认强制播放，会停掉之前的重新播放 */
        playBgMusic(audioName: string, bundle: string, volume?: number, force?: boolean): {
            audioName: string;
            bundle: string;
            volume: number;
            audioId: number;
        };
        /** 播放音效音乐 */
        play(audioName: string, bundle: string, isLoop?: boolean, volume?: number, onStartFun?: (auId?: number) => void, isBgMusic?: boolean): number;
        /** 停止播放 */
        stop(audioID: number): void;
        /** 暂停 */
        pause(audioID: number): void;
        /** 恢复 */
        resume(audioID: number): void;
        /** 设置音量 */
        setVolume(audioID: number, volume: number): void;
        /** 暂停所有 */
        pauseAll(): void;
        /** 恢复所有 */
        resumeAll(): void;
        /** 停止播放所有 */
        stopAll(): void;
        /** 切换声音状态 */
        switchSoundStatus(): void;
        /** 设置声音状态 */
        setSoundStatus(isMute: boolean): void;
        /** 设置音效音量 */
        setSoundVolumePer(value: number): void;
        /** 设置背景音乐音量 */
        setBgMusicVolumePer(value: number): void;
        updateSoundStatus(): void;
        /** 设置音效状态 */
        switchSoundEffStatus(sendNoice?: boolean): void;
        /** 设置背景音乐状态 */
        switchBgMusicStatus(sendNoice?: boolean): void;
        checkMute(sendNoice?: boolean): void;
        /** 设置音效屏蔽状态 */
        switchShield(flag: boolean): void;
        /**
         * 设置Button 点击时不使用默认点击音效。
         * 会把界面的 button Compone 名字改为 "notClickAudio"，以此作为标识不使用默认点击音效
         * 也可以自己手动设置
         * @param node
         */
        setNotDefaultClickAudio(node: cc.Node): gea.interfaces.manager.IAudiosManager;
        /** 设置按钮点击音效参数  bundle 和 url 不传，则表示不需要音效 */
        setButtonClickSound(btn: cc.Button, bundle?: string, url?: string): AudiosManager;
        curBundle: string;
        curExlaudioProvider: any;
        prefixUrl: string;
        /** 重置路径 */
        resetAudioPrefixUrl(): void;
        updateAudioExcel(bundle: string, exlaudioProvider: any, prefixUrl?: string): void;
        /** 播放子游戏的音乐音效 以excel表的key值 播放 这个方法主要给子游戏使用 */
        playAuido(key: string, isLoop?: boolean, volume?: number, onStartFun?: (auId?: number) => void, isBgMusic?: boolean): number;
        /** 播放子游戏背景音效，  以excel表的key值 播放 这个方法主要给子游戏使用 */
        playGameBGM(key: string, volume?: number, force?: boolean): {
            audioName: string;
            bundle: string;
            volume: number;
            audioId: number;
        };
    }
}
declare namespace hlgame.interfaces {
    interface INetConfigData {
        /**服务器地址 */
        domain: string;
        /**平台来源 */
        readonly platform: string;
        /**账号id */
        identifier: string;
        /**要自动进入的gameId 联网成功自动进入该游戏*/
        waitEnterGameId: number;
        /** 单游戏模式下的gameId */
        gameId: number;
        /** 大厅的id 默认大厅是1
         * 发布给第三方平台时可能会有定制的大厅 从链接传来大厅的ID*/
        hallId: number;
        /** 子游戏列表 */
        gameList: number[];
        /** 大厅状态  */
        hallMode: gea.enums.hallMode;
        /** 链接token */
        token: string;
        /** 账号类型数组 */
        identity_types: number[];
        /** 进入二次大厅概率(0-100) 放大100倍取整 */
        hallProb: number;
        /** H5游戏带进来的游戏横竖屏标识 */
        orientation: number;
        /** 认证信息图 */
        certification: string;
    }
    interface INetConfig extends INetConfigData {
        setup(config: {
            /**服务器地址 */
            domain?: string;
            /**平台来源 */
            platform?: string;
            /**账号ID */
            identifier?: string;
            /**gameId */
            gameId?: number;
            hallId?: number;
            waitEnterGameId?: number;
            gameList?: number[];
            token?: string;
            hallMode?: gea.enums.hallMode;
            certification?: string;
        }): void;
        /** 是否h5链接模式 H5链接直连*/
        isH5Mode: boolean;
    }
}
/** 存储初始链信息 */
declare namespace hlgame {
    const netConfig: interfaces.INetConfig;
}
declare namespace gea.common {
    class LocalStorage implements gea.interfaces.common.ILocalStorage {
        key: string;
        get prefix(): string;
        getItem(key: string, defaultValue?: any): any;
        setItem(key: string, value: string | number | boolean | object): void;
        removeItem(key: string): void;
        clear(): void;
        private encrypt;
        private decryption;
    }
}
declare namespace gea.common {
    class BitEncrypt implements gea.interfaces.common.IBitEncrypt {
        private readonly logTag;
        /**加密解密 密钥  */
        encryptKey: string;
        /**
         * @description 解密
         * @param content 加密的内容
         * @param key 解密的key 加密/解密的key保持一致，如果不传可通过设置encryptKey
         */
        decode(content: string, key?: string): string;
        /**
         * @description 加密
         * @param content 未加密内容
         * @param key 加密的key 加密/解密的key保持一致 如果不传可通过设置encryptKey
         */
        encode(content: string, key?: string): string;
        private _code;
        private _check;
    }
}
declare namespace gea.interfaces.net {
    /**
     * 网络解析器编码结果
     */
    interface INetParserEncodeResult {
        /**消息key */
        msg: string | number;
        /**发送给服务器的数据 */
        data: any;
        /**协议的seq值 */
        seq: number;
        /**原始发送的协议数据对象 */
        sendData: any;
        /**
         * 默认日志
         * + 网络实例会在发送消息前将日志打印出来
         * + 如果这个值是空的，则不打印
         */
        log: any;
    }
    /**
     * 网络解析器解码结果
     */
    interface INetParserDecodeResult {
        /**消息解析耗时 */
        decodeTime: number;
        /**消息key */
        msg: string | number;
        /**协议的seq值 */
        seq: number;
        /**
         * 收到的服务器返回的数据
         * + 解析后的`js对象`
         * + 网络实例会把这个`js对象`发布出去，监听了`msg`的地方会收到
         */
        data: any;
        /**
         * 默认日志
         * + 网络实例在消息解析后会将日志打印出来
         * + 如果这个值是空的，则不打印
         */
        log: any;
        /**额外发布的通知数据，服务器返回的当前消息内容会首先包含在数据中 */
        args: any[];
    }
    /**
     * 网络解析器
     */
    interface INetParser {
        /**
         * 编码函数
         * @param netTag 编码tag,一般用作关系映射
         * @param sendData 被编码对象
         * @param type
         * @returns INetParserEncodeResult
         */
        encode(netTag: string | number, sendData: any, ...args: any[]): INetParserEncodeResult;
        /**
         * 解码函数
         * @param recieveData
         * @param type
         * @returns INetParserDecodeResult
         */
        decode(recieveData: any, ...args: any[]): INetParserDecodeResult;
        /**
         * 设置消息编码解码和路径映射
         * @param mapping
         * @ignore
         */
        setMapping(mapping: any): INetParser;
        /**
         * 设置消息数字code和协议名隐射
         * @param mapping
         * @ignore
         */
        setCodeMapping(mapping: any): INetParser;
        /** 子游戏本地调试用，使用自己的协议文件 */
        setMappingLocal(mapping: any): INetParser;
        /**
         * 设置自定义encode日志回调
         * @param callback
         */
        setEncodeLogGenerator?(callback: (opt: any) => any): INetParser;
        /**
         * 设置自定义decode日志回调
         * @param callback
         */
        setDecodeLogGenerator?(callback: (opt: any) => any): INetParser;
    }
}
declare namespace gea.interfaces.net {
    interface INet extends interfaces.base.IDestroyAble {
        /**
         * 网络数据编码解码组件
         */
        readonly parser: interfaces.net.INetParser;
        /**
         * 服务器时间（毫秒）
         */
        readonly serverTime: number;
        /**
         * 网络延迟时间
         */
        readonly delayTime: number;
        /**
         * 是否已连接
         */
        readonly connected: boolean;
        /**
         * 更新服务器时间（毫秒）
         * @param serverTime 服务器时间（毫秒）
         * @param delayTime 网络延迟
         * @param log 是否打印服务器时间差以及网络延迟,一般调试才用,default=false
         */
        updateServerTime(serverTime: number, delayTime: number, log?: boolean): void;
        /**
         * 连接服务器
         * @param url 连接地址
         * @param option 连接参数
         */
        connect(url: string, ...options: any[]): void;
        /**
         * 断开连接
         */
        disconnect(): void;
        /**
         * 发送消息
         * @param netTag
         * @param data
         */
        send(netTag: string | number, data?: any, ...args: any[]): INet;
        /**
         * 新增一个Net相关的消息接收者,接收一次后关闭,或者off显式关闭
         * @param netTag 消息tag
         * @param callback 回调函数
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        once(netTag: string | number, callback: Function, scope?: any, ...callbackArgs: any[]): INet;
        /**
        * 新增一个Net相关的消息接收者
        * @param netTag 消息tag
        * @param callback 回调函数
        * @param scope 作用域
        * @param args 回调函数参数
        */
        on(netTag: string | number, callback: Function, scope?: any, ...callbackArgs: any[]): INet;
        /**
        * 新增一个Net相关的消息接收者
        * @param netTag 消息tag
        * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
        * @param callback 回调函数
        * @param scope 作用域
        * @param args 回调函数参数
        */
        on(netTag: string | number, callbackLimite: number, callback: Function, scope?: any, ...callbackArgs: any[]): INet;
        /**
         * 新增一个优先的Net相关的消息接收者,接收一次后关闭,或者offPrior显式关闭
         * @param netTag 消息tag
         * @param callback 回调函数--订阅者
         * @param scope 回调函数作用域
         * @param callbackArgs 回调参数
         */
        oncePrior(netTag: string | number, callback: Function, scope?: any, ...callbackArgs: any[]): INet;
        /**
         * 新增一个优先的Net相关的消息接收者
         * @param netTag 消息tag
         * @param callback 回调函数
         * @param scope 作用域
         * @param callbackLimite 回调次数限制,为0表示不限制回调次数,default=0
         * @param args 回调函数参数
         */
        onPrior(netTag: string | number, callback: Function, scope?: any, ...callbackArgs: any[]): INet;
        /**
         * 新增一个优先的Net相关的消息接收者
         * @param netTag 消息tag
         * @param callbackLimite 回调次数限制,小于等于0表示不限制回调次数,default = 0,如果此参数不是一个数字,那么将把此参数作为callback参数的值使用
         * @param callback 回调函数
         * @param scope 作用域
         * @param callbackLimite 回调次数限制,为0表示不限制回调次数,default=0
         * @param args 回调函数参数
         */
        onPrior(netTag: string | number, callbackLimite: number, callback: Function, scope?: any, ...callbackArgs: any[]): INet;
        /**
         * 去掉一个Net相关的消息接收者
         * @param netTag 消息tag
         * @param callback 回调函数
         * @param scope 作用域
         */
        off(netTag: string | number, callback: Function, scope?: any): INet;
        /**
         * 移除实例相关的所有网络事件监听
         * @param scope 实例本身(this)
         */
        offByScope(scope: any): INet;
        /**
         * 发布一个网络实例通知
         * @param tag 通知
         * @param args 通知携带的额外参数
         */
        dispatch(tag: any, ...args: any[]): INet;
        /**
         * 禁止req消息log，如果参数传空，则不打印发送的客户端消息
         * @param netTags
         */
        forbidReqLog(...netTags: (string | number)[]): INet;
        /**
         * 禁止res消息log，如果参数传空，则不打印收到的服务器消息
         * @param netTags
         */
        forbidResLog(...netTags: (string | number)[]): INet;
        /**
         * 新建一个网络实例
         * @param 实例的名字，默认为NET,NET1,NET2...
         */
        createNew(name?: string, ...args: any[]): INet;
    }
}
declare namespace gea.events {
    /**网络交互中发生的事件 */
    enum net {
        /**服务器连接成功 */
        connect = "gea.events.net.connect",
        /**
         * 服务器连接失败
         * + 重连次数达到上限时，仍未连上服务器
         */
        connect_fail = "gea.events.net.connect_fail",
        /**服务器连接断开 */
        disconnect = "gea.events.net.disconnect",
        /**重连成功 */
        reconnect = "gea.events.net.reconnect",
        /**
         * 主动断开连接
         * + 手动调用disconnect时触发
         * + 此事件发生时，不会触发disconnect事件
         */
        disconnect_self = "gea.events.net.disconnect_self",
        /**消息错误,具体什么时机抛出根据业务决定 */
        error = "gea.events.net.error",
        /**心跳超时事件 */
        heart_beat_timeout = "gea.events.net.heart_beat_timeout",
        /** login成功通知事件， 收到服务的login */
        login_success = "gea.events.net.login_success"
    }
}
declare namespace gea.abstracts.net {
    abstract class NetBase implements interfaces.net.INet {
        get parser(): interfaces.net.INetParser;
        get serverTime(): number;
        get delayTime(): number;
        get connected(): boolean;
        protected _reqForbiddenAll: boolean;
        protected _dicReqForbidden: {
            [netTag: string]: boolean;
        };
        protected _resForbiddenAll: boolean;
        protected _dicResForbidden: {
            [netTag: string]: boolean;
        };
        protected _name: string;
        private _prevSyncTime;
        private _serverTime;
        private _delayTime;
        createNew(name?: string): NetBase;
        connect(uri: string, opts?: any): void;
        disconnect(): void;
        send(netTag: string | number, data?: any, ...args: any[]): NetBase;
        updateServerTime(serverTime: number, delayTime: number, log?: boolean): void;
        once(netTag: string | number, callback: Function, scope?: any, ...callbackArgs: any[]): NetBase;
        on(netTag: string | number, callbackLimite: number | Function, callback: Function, scope?: any, ...callbackArgs: any[]): NetBase;
        off(netTag: string | number, callback: Function, scope?: any): NetBase;
        oncePrior(netTag: string | number, callback: Function, scope?: any, ...callbackArgs: any[]): NetBase;
        onPrior(netTag: string | number, callbackLimite: number | Function, callback: Function, scope?: any, ...callbackArgs: any[]): NetBase;
        offByScope(scope: any): NetBase;
        dispatch(tag: any, ...args: any[]): NetBase;
        forbidReqLog(...netTags: (string | number)[]): NetBase;
        forbidResLog(...netTags: (string | number)[]): NetBase;
        destroy(): void;
        callbackAfterBorrow(name?: string): void;
        callbackBeforeRestore(): boolean;
        protected decode(data: any): void;
        protected encode(netTag: string | number, data: any, ...args: any[]): gea.interfaces.net.INetParserEncodeResult;
        protected onNetEvent(event: events.net, ...args: any[]): void;
        protected onIoEvent(event: string, param?: any): void;
        protected onWsEvent(event: string, param?: any): void;
        private syncServerTime;
        private logRes;
        private logReq;
    }
}
declare namespace gea.interfaces.net {
    interface IWsConnectOption {
        binaryType?: 'blob' | 'arraybuffer';
        protocols?: string | string[];
        /**
         * Should we allow reconnections?
         * @default true
         */
        reconnection?: boolean;
        /**
         * How many reconnection attempts should we try?
         * @default Infinity
         */
        reconnectionAttempts?: number;
        /**
         * The time delay in milliseconds between reconnection attempts
         * @default 1000
         */
        reconnectionDelay?: number;
        /**
         * The max time delay in milliseconds between reconnection attempts
         * @default 5000
         */
        reconnectionDelayMax?: number;
        /**
         * 计算重连延迟的函数
         */
        reconnectionDealyFunc?: (/**当前重连次数 */ reconnectionAttempts: number, /**重连最小延迟 */ reconnectionDelay: number, /**重连最大延迟 */ reconnectionDelayMax: number) => number;
        /**
         * The timeout in milliseconds for our connection attempt
         * @default 20000
         */
        timeout?: number;
        path?: string;
        query?: {};
    }
}
declare namespace gea.interfaces.net {
    type UpStream = {
        len?: number;
        seq?: number;
        msg_Code?: number;
        is_encry?: number;
        is_zip?: number;
        body?: Uint8Array | null;
        byteArray?: any;
    };
    type DownStream = {
        len?: number;
        seq?: number;
        msg_Code?: number;
        is_encry?: number;
        is_zip?: number;
        body?: Uint8Array | null;
        byteArray?: any;
    };
    interface IGmeNetParser extends interfaces.net.INetParser {
        /**
         * 设置消息编码解码和路径映射
         * @param mapping
         * @ignore
         */
        setMapping(mapping: {
            [msgName: string]: {
                parser: Function;
                msgCode: number;
            };
        }): IGmeNetParser;
        /**
         * 设置消息数字code和协议名隐射
         * @param mapping
         * @ignore
         */
        setCodeMapping(mapping: {
            [msgCode: number]: string;
        }): IGmeNetParser;
        /**
         * 设置自定义encode日志回调
         * @param callback
         */
        setEncodeLogGenerator(callback: (opt: {
            msg: string;
            body: Object;
            upStream: UpStream;
        }) => any): IGmeNetParser;
        /**
         * 设置自定义decode日志回调
         * @param callback
         */
        setDecodeLogGenerator(callback: (opt: {
            msg: string;
            body: Object;
            downStream: DownStream;
        }) => any): IGmeNetParser;
    }
}
declare namespace gea.interfaces.net {
    interface IGmeNet extends gea.interfaces.net.INet {
        /**
         * 网络数据编码解码组件
         */
        readonly parser: IGmeNetParser;
        /**
         * 心跳组件
         */
        readonly heartBeat: INetHeartBeat;
        /**
         * 持有此网络实例的uid
         */
        readonly uid: string | number;
        /**
         * 链接的url
         */
        readonly uri: string;
        /**
         * 连接服务器
         * @param url 连接地址
         * @param option 连接参数
         */
        connect(url: string, option: IWsConnectOption): void;
        /**
         * 设置网络实例的一些信息
         * @param uid
         */
        setup(uid: string | number, opt?: {
            /**
             * 是否自动重连
             * @default true
             */
            reconnection?: boolean;
            /**
             * 自动重连次数上限
             * @default Infinity
             */
            reconnectionAttempts?: number;
            /**
             * 自动重连延迟(毫秒)
             * @default 1000
             */
            reconnectionDelay?: number;
            /**
             * 自动重连最大延迟(毫秒)
             * @default 5000
             */
            reconnectionDelayMax?: number;
            /**自定义自动重连延迟计算函数 */
            reconnectionDealyFunc?: (reconnectionAttempts: number, reconnectionDelay: number, reconnectionDelayMax: number) => number;
            /**
             * 连接超时时间(毫秒)
             * @default 10000
             */
            timeout?: number;
        }): IGmeNet;
        /**
         * 发送消息
         * @param netTag
         * @param data
         * @param path
         * @param roomId
         */
        send(netTag: string | number, data?: any, path?: string, roomId?: string): IGmeNet;
        /**
         * 根据res返回的seq ID，获取对应seq的协议发送数据
         * @param seq
         */
        getSendDataBySeq(seq: number): any;
        /** 设置protobufjs引用给子游戏bundle使用 */
        setProtobufjs(value: any): any;
        /** 是否等待launch中 */
        isWaitLaunch: boolean;
    }
}
declare namespace gea.abstracts.net {
    abstract class NetParserBase implements interfaces.net.INetParser {
        protected _entity: gea.interfaces.net.INet | undefined;
        protected _mapping: {
            [msgName: string]: {
                parser: any;
                [key: string]: any;
            };
        } | undefined;
        protected _codeMapping: {
            [msgCode: string]: string;
        } | undefined;
        protected _encodeLogGenerator: ((opt: any) => any) | undefined;
        protected _decodeLogGenerator: ((opt: any) => any) | undefined;
        encode(netTag: string | number, sendData: any, ...args: any[]): interfaces.net.INetParserEncodeResult;
        decode(recieveData: ArrayBuffer | Array<string | ArrayBuffer>): interfaces.net.INetParserDecodeResult;
        setMapping(mapping: any): NetParserBase;
        setCodeMapping(mapping: any): NetParserBase;
        /** 子游戏本地调试用，使用自己的协议文件 */
        setMappingLocal(mapping: any): NetParserBase;
        setEncodeLogGenerator(callback: (opt: any) => any): NetParserBase;
        setDecodeLogGenerator(callback: (opt: any) => any): NetParserBase;
        destroy(): void;
    }
}
declare namespace gea {
    enum ByteArraySize {
        SIZE_OF_BOOLEAN = 1,
        SIZE_OF_INT8 = 1,
        SIZE_OF_INT16 = 2,
        SIZE_OF_INT32 = 4,
        SIZE_OF_UINT8 = 1,
        SIZE_OF_UINT16 = 2,
        SIZE_OF_UINT32 = 4,
        SIZE_OF_FLOAT32 = 4,
        SIZE_OF_FLOAT64 = 8
    }
    class ByteArray implements interfaces.base.IPoolObject {
        private _littleEndian;
        private _dataView;
        private _buffer;
        protected _position: number;
        /**
         * 已经使用的字节偏移量
         * @protected
         * @type {number}
         * @memberOf ByteArray
         */
        protected write_position: number;
        private _bufferExtSize;
        get length(): number;
        get buffer(): Uint8Array;
        validate(len: number): boolean;
        validateBuffer(len: number): void;
        private _validateBuffer;
        /**
         * 从字节流中读取一个带符号的 16 位整数  2 字节
         * @return 介于 -32768 和 32767 之间的 16 位带符号整数
         */
        readShort(): number;
        /**
         * 从字节流中读取带符号的字节 1 字节
         * @return 介于 -128 和 127 之间的整数
         */
        readByte(): number;
        /**
         * 读取协议数据信息
         * @returns
         */
        readProtoBuff(): Uint8Array;
        /**
         * 在字节流中写入一个 16 位整数。使用参数的低 16 位。忽略高 16 位
         */
        writeShort(value: number): void;
        /**
         * 在字节流中写入一个字节
         * 使用参数的低 8 位。忽略高 24 位
         * @param value 一个 32 位整数。低 8 位将被写入字节流
         */
        writeByte(value: number): void;
        /**
         * 将指定字节数组 bytes（起始偏移量为 offset，从零开始的索引）中包含 length 个字节的字节序列写入字节流
         * 如果省略 length 参数，则使用默认长度 0；该方法将从 offset 开始写入整个缓冲区。如果还省略了 offset 参数，则写入整个缓冲区
         * 如果 offset 或 length 超出范围，它们将被锁定到 bytes 数组的开头和结尾
         * @param bytes ByteArray 对象
         * @param offset 从 0 开始的索引，表示在数组中开始写入的位置
         * @param length 一个无符号整数，表示在缓冲区中的写入范围
         */
        writeUint8Array(unitBytes: Uint8Array, offset?: number, length?: number): void;
        callbackAfterBorrow(buffer?: ArrayBuffer | Uint8Array, bufferExtSize?: number): void;
        callbackBeforeRestore(): boolean;
    }
}
declare namespace gea {
}
declare namespace gea.interfaces.net {
    interface INetHeartBeat {
        /**
         * 获取超时次数上限
         */
        timeoutCountLimit(): number;
        /**
         * 设置超时次数上限
         * + 每次ping的时候超时次数+1
         * + 当超时次数达到设定的值时,网络实例会抛出一个`gea.events.net.heart_beat_timeout`事件
         * + 默认值为 `Infinity`，表示永远不会超时
         */
        timeoutCountLimit(value: number): INetHeartBeat;
        /**
         * 获取发送`ping`的频率，单位是毫秒
         */
        interval(): number;
        /**
         * 设置发送`ping`的频率，单位是毫秒
         * + 默认值为5000毫秒
         */
        interval(value: number): INetHeartBeat;
        /**
         * 设置启动心跳的事件
         * @param value 具体事件
         * + 心跳组件依附的网络实例会监听这个事件，在这个事件之后启动`ping`
         * + 心跳超时后会停止`ping`，再次启动`ping`的时候也是依赖这个事件
         * + 默认值为 `gea.events.net.coonnect`，表示网络连上之后立即启动`ping`
         * @param immediately 是否在设置事件的时候就立即启动`ping`
         */
        startupEvent(value: string | number, immediately?: boolean): INetHeartBeat;
        /**
         * 是否打印服务器时间差
         * @param value
         * + 本地会自己计算一个服务器时间
         * + 每次更新服务器时间的时候根据这个方法设置的值决定是否打印
         * + 默认不打印
         */
        printServerDiffTime(value: boolean): INetHeartBeat;
    }
}
declare namespace gea.abstracts.net {
    abstract class NetHeartBeatBase implements interfaces.net.INetHeartBeat {
        protected _entity: interfaces.net.INet | undefined;
        protected _timeoutCountLimit: number;
        protected _pingRate: number;
        protected _pingStartEvent: string | number;
        protected _listHeartBeatClientTime: number[];
        protected _printserverDiffTime: boolean;
        private _running;
        private _timeoutCount;
        timeoutCountLimit(): number;
        timeoutCountLimit(value: number): interfaces.net.INetHeartBeat;
        interval(): number;
        interval(value: number): interfaces.net.INetHeartBeat;
        startupEvent(value: string | number, immediately?: boolean): interfaces.net.INetHeartBeat;
        printServerDiffTime(value: boolean): interfaces.net.INetHeartBeat;
        destroy(): void;
        protected ping(): void;
        protected pong(...args: any[]): void;
        /**
         * 启动ping
         */
        private startPing;
        private stopPing;
        /**
         * ping计数
         */
        private pingCount;
    }
}
declare namespace gea {
}
declare namespace gea {
}
declare namespace gea {
    /**
     * 玩家网络实例
     */
    const net: interfaces.net.IGmeNet;
}
declare namespace gea.common {
    class ServerStorage {
        Req_UpdatePlayerCustom: string;
        private _data;
        updateData(custom: string): void;
        /**
         * 获取数据
         * @param bundle
         * @param key
         * @param defaultValue
         * @returns
         */
        getItem(bundle: string, key: string, defaultValue?: any): any;
        getAllItem(bundle?: string, defaultValue?: any): any;
        /**
         * 存储数据
         * @param bundle
         * @param key
         * @param value
         * @returns
         */
        setItem(bundle: string, key: string, value: any): void;
        /**
         * 删除数据
         * @param bundle
         * @param key
         * @returns
         */
        removeItem(bundle: string, key?: string): void;
    }
}
declare namespace gea.common {
    class Language {
        private _exlLangTableMap;
        private _bundleLangMap;
        RESOURCES: string;
        constructor();
        get language(): string;
        updateLanguage(): void;
        /** 设置对应bundle的多语言表 */
        setBundleLangTab(bundle: string, exlLangTabl: any): void;
        /** 获取对应bundle的多语言 */
        getBundleLangTab(bundle: string): any;
        tran(bundle: string, key: string, ...args: any[]): string;
        checkInLang(bundle: string, key: string): string;
        tranArr(bundle: string, key: string, args: any): string;
        /**
         * 获取语言码
         */
        getLanguage(bundle: string): string;
        /**  转换多语言图片 */
        tranPicTxt(bundle: string, picName: string, sp: cc.Node): void;
        /** 转换多语言文本 */
        tranStringTxt(bundle: string, keyName: string, sp: cc.Node, ...args: any[]): void;
        /** 获取多语言 spriteFrame */
        tranSpriteFrame(bundle: string, picName: string): Promise<cc.SpriteFrame>;
    }
}
declare namespace gea.tween.ease {
    function evaluate(easeType: gea.enums.tween.ease, time: number, duration: number, overshootOrAmplitude: number, period: number): number;
}
declare namespace gea.tween {
    /**
     * 追加一个from缓动
     * @param target 被缓动对象
     * @param duration 缓动总时长，单位:`ms`
     * @param property 缓动属性的起始值，目标值为当前值
     * @param option 额外参数
     * + easeType 缓动类型 @see gea.enums.tween.ease
     * + delay 缓动开始前的延迟时间，单位:`ms`
     * + repeatCount 重复次数，默认值为0，表示不重复。<0表示无限重复
     * + repeatInterval 重复间隔，单位:`ms`
     * + yoyo 是否回到缓动开始的位置
     * + yoyoDelay yoyo延迟时间，单位:`ms`
     * + callbackStart 缓动开始的回调
     * + callbackStartScope callbackStart作用域
     * + callbackStartArgs callbackStart额外参数
     * + callbackComplete 此条缓动结束的回调
     * + callbackCompleteScope callbackComplete作用域
     * + callbackCompleteArgs callbackComplete 额外参数
     */
    function from(target: {
        [key: string]: any;
    }, duration: number, property: {
        [key: string]: number;
    }, option?: interfaces.tween.ITweenOption): interfaces.tween.ITweener;
    /**
     * 追加一个to缓动
     * @param target 被缓动对象
     * @param duration 缓动总时长，单位:`ms`
     * @param property 缓动属性的目标值，起始值为当前值
     * @param option 额外参数
     * + easeType 缓动类型 @see gea.enums.tween.ease
     * + delay 缓动开始前的延迟时间,单位:`ms`
     * + repeatCount 重复次数，默认值为0，表示不重复。<0表示无限重复
     * + repeatInterval 重复间隔，单位:`ms`
     * + yoyo 是否回到缓动开始的位置
     * + yoyoDelay yoyo延迟时间，单位:`ms`
     * + callbackStart 缓动开始的回调
     * + callbackStartScope callbackStart作用域
     * + callbackStartArgs callbackStart额外参数
     * + callbackComplete 此条缓动结束的回调
     * + callbackCompleteScope callbackComplete作用域
     * + callbackCompleteArgs callbackComplete 额外参数
     */
    function to(target: {
        [key: string]: any;
    }, duration: number, property: {
        [key: string]: number;
    }, option?: interfaces.tween.ITweenOption): interfaces.tween.ITweener;
    /**
     * 追加一个fromTo缓动
     * @target 被缓动对象
     * @param duration 缓动总时长，单位:`ms`
     * @param propertyFrom 缓动的起始属性值
     * @param propertyTo 缓动的目标属性值
     * @param option 额外参数
     * + easeType 缓动类型 @see gea.enums.tween.ease
     * + delay 缓动开始前的延迟时间,单位:`ms`
     * + repeatCount 重复次数，默认值为0，表示不重复。<0表示无限重复
     * + repeatInterval 重复间隔，单位:`ms`
     * + yoyo 是否回到缓动开始的位置
     * + yoyoDelay yoyo延迟时间，单位:`ms`
     * + callbackStart 缓动开始的回调
     * + callbackStartScope callbackStart作用域
     * + callbackStartArgs callbackStart额外参数
     * + callbackComplete 此条缓动结束的回调
     * + callbackCompleteScope callbackComplete作用域
     * + callbackCompleteArgs callbackComplete 额外参数
     */
    function fromTo(target: {
        [key: string]: any;
    }, duration: number, propertyFrom: {
        [key: string]: number;
    }, propertyTo: {
        [key: string]: number;
    }, option?: interfaces.tween.ITweenOption): interfaces.tween.ITweener;
    /**
     * 立即停止一个缓动
     * @param target 被缓动的对象
     * @param forceComplete 是否强制到结束值
     */
    function kill(target: any, forceComplete?: boolean): void;
    let gameMgr: any;
    function checkAndAddToBundleMap(scope: any): void;
    /**
     * 移除bundle中所有`scope`下的所有订阅者
     * @param bundle
     */
    function offByBundle(bundle: string): void;
}
declare namespace gea.adapters.ui {
    class UIManager implements adapters.interfaces.ui.IUIManager {
        get viewPort(): {
            width: number;
            height: number;
            halfWidth: number;
            halfHeight: number;
        };
        get nodeModal(): cc.Node;
        HALL: string;
        private _viewPort;
        /** 已创建的/正在加载中的ui字典 */
        private _mapUI;
        /** 已经实例化，但是还未进入到_dicUi的ui节点 */
        private _mapUINodeBeforeDraw;
        /** ui显示参数 */
        private _mapUIShowOption;
        /**
         * ui的Widget组件字典
         * 只有widget的alignMode为cc.Widget.AlignMode.ON_WINDOW_RESIZE时会存在_dicUiWidget
         */
        private _dicUiWidget;
        /** 已经显示到舞台的ui */
        private _mapOpeningUI;
        /** 对应游戏bundle下的界面uuid列表 记录下来方便关闭子游戏的时候清除界面字典和回收 */
        private _mapBundleUI;
        /** uuid to uiClass*/
        private _mapUUIDToUIClass;
        /** 大厅或者APP界面注册进来可以给子游戏打开的通用界面 */
        private _mapCommonUIClass;
        /**  ui容器列表 */
        private _listLayer;
        private _mapListLayer;
        /** 正在显示的模态UI数量 */
        private _modalCount;
        /**模态层 */
        private _layerModal;
        /**模态蒙层对象 */
        private _viewModal;
        private _graphicsModal;
        private _mapUIAssets;
        private _setup;
        constructor();
        isShowing(uiClass: gea.interfaces.ui.IUIClass): boolean;
        once(tag: any, callback: Function, scope: any, ...callbackArgs: any[]): interfaces.ui.IUIManager;
        on(tag: any, callbackLimit: number | Function, callback: Function, scope: any, ...callbackArgs: any[]): interfaces.ui.IUIManager;
        off(tag: any, callback: Function, scope: any): interfaces.ui.IUIManager;
        offByScope(scope: any): interfaces.ui.IUIManager;
        show(uiClass: gea.interfaces.ui.IUIClass, option?: {
            tween?: {
                duration: number;
                from: {
                    [key: string]: number;
                };
                to: {
                    [key: string]: number;
                };
                option: gea.interfaces.tween.ITweenOption;
            };
            args: any[];
        }): UIManager;
        hide(uiClass: gea.interfaces.ui.IUIClass, option?: {
            tween?: {
                duration: number;
                from: {
                    [key: string]: number;
                };
                to: {
                    [key: string]: number;
                };
                option: gea.interfaces.tween.ITweenOption;
            };
            args: any[];
        }): UIManager;
        hideAll(excludeUIClass?: gea.interfaces.ui.IUIClass[]): this;
        hideBundleUIAll(bundle: string): this;
        setup(option: {
            modal?: {
                tweenShow: {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                } | {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                }[];
                tweenHide: {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                } | {
                    duration: number;
                    from?: {
                        opacity: number;
                    };
                    to?: {
                        opacity: number;
                    };
                    option?: gea.interfaces.tween.ITweenOption;
                }[];
            };
        }): UIManager;
        /**
         * 添加一个新的子游戏bundle，在UI管理器中为其分配创建UI层
         * 该子游戏所打开显示的UI界面都会添加显示到为其分配的UI层
         * 回收时会一并进行回收移除
         * @param bundle
         * @param sceneNode
         */
        addBundleScene(bundle: string, sceneNode: cc.Node): void;
        getBundleLayer(bundle: string, layerType: gea.enums.ui.ui_type): cc.Node;
        /**
         * 清除回收该 bundle在UI中的所有信息和界面，并回释放此包中的所有资源
         * @param bundle
         * @returns
         */
        releaseBundle(bundle: string): void;
        private loadUIAssets;
        private startLoadUIAssets;
        private getUnLoadedUIAssets;
        private countModal;
        private refreshModal;
        private refreshLayerModal;
        private reDrawModal;
        private releaseUI;
        private delayToReleaseUI;
        private showUI;
        private addUIBeforeDraw;
        private addUIImmediately;
        private afterShowUI;
        private afterHideUI;
        /**
        * 场景运行后,初始化UI容器,ui容器为空节点,高宽为屏幕高宽,配有widgt,位置在Canvas(0,0)
        */
        private afterSceneLaunch;
        private applyWidget;
        private _innerWidht;
        private onStageResize;
        getCanvas(): cc.Node;
        /** 获取指定的UI界面，显示中的才能获取到。未显示返回 null */
        getShowUI<T extends adapters.abstracts.ui.UIBase>(uiClass: gea.interfaces.ui.IUIClass): T;
        _loadProgress: any;
        showLoadProgress(completeCount: number, totalCount: number, item: cc.AssetManager.RequestItem): void;
        hideLoadProgress(): void;
        setLoadProgress(loadProgress: any): void;
        /** 检查某通用UI是否打开中 */
        isShowingCommonUI(name: any): boolean;
        /** 获取指定的通用UI界面，显示中的才能获取到。未显示返回 null */
        getShowCommonUI<T extends adapters.abstracts.ui.UIBase>(name: string): T;
        getCommonUIClass(name: string): gea.interfaces.ui.IUIClass;
        registerCommonUI(name: string, uiClass: gea.interfaces.ui.IUIClass): UIManager;
        openCommonUI(name: string, option?: {
            tween?: {
                duration: number;
                from: {
                    [key: string]: number;
                };
                to: {
                    [key: string]: number;
                };
                option: gea.interfaces.tween.ITweenOption;
            };
            args: any[];
        }): UIManager;
        closeCommonUI(name: string, option?: {
            tween?: {
                duration: number;
                from: {
                    [key: string]: number;
                };
                to: {
                    [key: string]: number;
                };
                option: gea.interfaces.tween.ITweenOption;
            };
            args: any[];
        }): UIManager;
        /** 关闭所有通用UI */
        closeAllCommonUI(): UIManager;
        /** 界面上UI数量通知 */
        noticeUINumber(): void;
        /** 获取模态层黑底遮罩状态  判断当前是否有模态界面显示 */
        getModeLayerStatus(): boolean;
        /** 检查刷新模态层
         *  模态加载界面显示太久，刷新一下
        */
        checkAndRefreshModalPanel(): void;
        /**
         * 添加canvas 层  目前用于添加子游戏3D层, 层级名字不能命名为 canvas
         * @param canvas
         * @param bundle
         */
        addNewCanvas(canvas: cc.Node, bundle: string): any;
        /** 清理其他canvas */
        clearOtherCanvas(): any;
    }
    const manager: UIManager;
}
declare namespace hlgame.utils {
    const comUtil: hlgame.interfaces.utils.IComUtil;
}
declare namespace hlgame.interfaces.utils {
    interface IRenderHeadOpt {
        /**默认资源,在加载真实头像的时候使用的资源,如果为空，则用sprite的默认资源 */
        defaultTexture?: cc.Texture2D;
        /**清楚标记 */
        clearTag?: string | number;
        /** sizemode */
        sizeMode?: cc.Sprite.SizeMode;
    }
    interface IUserRender {
        DIC_APP_AVATAR: {
            [id: number]: string;
        };
        /**
         * 根据uid，目标Sprite渲染玩家头像 远程资源
         * @param uid
         */
        avatar(uid: string | number, sprite: cc.Sprite, opts?: IRenderHeadOpt): IUserRender;
        /**
         * 根据uid，目标Sprite渲染玩家头像框 远程资源
         * @param uid
         * @param sprite
         * @param completeCallback
         * @param opts
         */
        avatarBox(uid: string | number, sprite: cc.Sprite, opts?: hlgame.interfaces.utils.IRenderHeadOpt): IUserRender;
        /**
         * 给 sprite 设置远程的url资源。 用于设置头像和头像框，其他内容请不要使用
         * @param url
         * @param sprite
         * @param opts
         */
        avatarUrl(url: string, sprite: cc.Sprite, opts?: hlgame.interfaces.utils.IRenderHeadOpt): IUserRender;
        /**
         * 根据uid，目标文本渲染玩家名字
         * @param uid
         * @param lable
         * @param maxLen 最大字数，表情/中文/英文都按一个字数计算
         * @param maxWidth 最大宽度，文本`node`的宽度，如果`maxLen`字数渲染出的文本节点宽度依然大于`maxWidth`，则继续截断
         */
        name(uid: string | number, label: cc.Label, maxUtf8Len?: number, maxWidth?: number): IUserRender;
        /**
         * 根据uid，目标Sprite渲染玩家性别
         * @param uid 用户uid
         * @param sprite 性别sprite
         * @param maleUrl 男性默认图标路径，会覆盖[sexDefault](#)接口设置的默认图标(暂不支持网络图标，请设置相对于项目`resource`目录的路径)
         * @param femaleUrl 女性默认图标路径会覆盖[sexDefault](#)接口设置的默认图标(暂不支持网络图标，请设置相对于项目`resource`目录的路径)
         */
        sex(uid: string | number, sprite: cc.Sprite, maleUrl?: string, femaleUrl?: string): IUserRender;
        /**
         * 设置男性&女性默认图标路径，设置默认图标之后就不需要每次调用[sex](#)接口的时候设置路径了
         * @param maleUrl 男性默认图标路径(暂不支持网络图标，请设置相对于项目`resource`目录的路径)
         * @param femaleUrl 女性默认图标路径(暂不支持网络图标，请设置相对于项目`resource`目录的路径)
         */
        sexDefault(maleUrl: string, femaleUrl: string): IUserRender;
        /**
         * 渲染多个/全部玩家相关UI,参数参考 `head` `name` `sex` 接口
         * @param uid
         * @param opt
         */
        few(uid: string | number, opt: {
            head?: {
                sprite: cc.Sprite;
                opts?: IRenderHeadOpt;
            };
            name?: {
                label: cc.Label;
                maxUtf8Len?: number;
                maxWidth?: number;
            };
            sex?: {
                sprite: cc.Sprite;
                maleUrl?: string;
                femaleUrl?: string;
            };
            level?: {
                lable: cc.Label;
                formatStr?: string;
            };
            vip?: {
                sprite: cc.Sprite;
            };
        }): IUserRender;
        level(uid: string | number, lable: cc.Label, formatStr?: string): IUserRender;
        vip(uid: string | number, sprite: cc.Sprite): IUserRender;
    }
}
declare namespace gea.interfaces.utils {
    /**
     * 字符串相关接口
     * @see unicode编码 https://www.freebuf.com/articles/web/25623.html
     * @see unicode编码 https://blog.csdn.net/hezh1994/article/details/78899683
     */
    interface IStringUtils {
        /**
         * 按utf8长度截取字符串
         * @param str 原始字符串
         * @param len 要截取的长度
         * @param tailSymbol 超过len长度时，要追加的字符,默认值:'...'
         */
        subUtf8(str: string, len: number, tailSymbol?: string): string;
        /**
         * 获取字符串的utf8格式长度
         * @param str
         */
        utf8len(str: string): number;
    }
}
declare namespace gea.utils {
    const str: gea.interfaces.utils.IStringUtils;
}
declare namespace hlgame.interfaces.utils {
    interface IResControl {
        /**
         * 设置加载失败时重试次数，默认值5
         * @param value
         */
        retryCount(value: number): IResControl;
        /**
         * 设置加载失败时重试的间隔，单位ms，默认值2000
         * @param value
         */
        retryDuration(value: number): IResControl;
        /**
         * 从远程获取一张图片
         * @param url 远程图片地址
         * @param callback 图片加载完的回调函数
         * @param callbackScope 回调函数的作用域
         */
        getFrameFromRemote(url: string, callback: (texture: cc.Texture2D, originUrl?: string) => void, callbackScope?: any, limitWidth?: number, limitHeight?: number): void;
    }
}
declare namespace hlgame.utils {
    const res: hlgame.interfaces.utils.IResControl;
}
declare namespace hlgame.utils {
    class UserRender implements hlgame.interfaces.utils.IUserRender {
        DIC_APP_AVATAR: {
            [id: number]: string;
        };
        private _dicHeadInfo;
        private _dicNameInfo;
        private _dicSexInfo;
        private _defaultMaleUrl;
        private _defaultFeMaleUrl;
        RES: string;
        HALL: string;
        avatar(uid: string | number, sprite: cc.Sprite, opts?: hlgame.interfaces.utils.IRenderHeadOpt): UserRender;
        avatarBox(uid: string | number, sprite: cc.Sprite, opts?: hlgame.interfaces.utils.IRenderHeadOpt): UserRender;
        avatarUrl(url: string, sprite: cc.Sprite, opts?: hlgame.interfaces.utils.IRenderHeadOpt): UserRender;
        name(uid: string | number, lable: cc.Label, maxLen?: number, maxWidth?: number): UserRender;
        level(uid: string | number, lable: cc.Label, formatStr?: string): UserRender;
        vip(uid: string | number, sprite: cc.Sprite): UserRender;
        sex(uid: string | number, sprite: cc.Sprite, maleUrl: string, femaleUrl: string): UserRender;
        sexDefault(maleUrl: string, femaleUlr: string): UserRender;
        few(uid: string | number, opts: {
            head?: {
                sprite: cc.Sprite;
                opts?: hlgame.interfaces.utils.IRenderHeadOpt;
            };
            name?: {
                label: cc.Label;
                maxUtf8Len?: number;
                maxWidth?: number;
            };
            sex?: {
                sprite: cc.Sprite;
                maleUrl?: string;
                femaleUrl?: string;
            };
            level?: {
                lable: cc.Label;
                formatStr?: string;
            };
            vip?: {
                sprite: cc.Sprite;
            };
        }): UserRender;
    }
    /**
     * 根据文本内容，目标文本渲染玩家名字
     * @param content 文本内容
     * @param lable
     * @param maxLen 最大字数，表情/中文/英文都按一个字数计算
     * @param maxWidth 最大宽度，文本node的宽度，如果maxLen字数渲染出的文本节点宽度依然大于maxWidth，则继续截断
     */
    function renderLimitLable(content: string, lable: cc.Label, maxLen?: number, maxWidth?: number): void;
}
declare namespace gea.interfaces.manager {
    interface IGameManager {
        /**
         * 注册类进来
         * @param bundle
         * @param poolClass
         * @param args
         */
        register<T extends gea.interfaces.manager.IGameMgrPool>(bundle: string, poolClass: {
            prototype: T;
            new (): T;
        }, ...args: any[]): T;
        /**
         * 取消注册，消除类引用，丢进回收池
         * @param bundle
         * @param poolClass
         */
        unRegister(bundle: string, poolClass: any): any;
        /**
         * 获取改类引用
         * @param poolClass
         */
        get<T extends gea.interfaces.manager.IGameMgrPool>(poolClass: {
            prototype: T;
            new (): T;
        }): T;
        /** 根据类名获取 注册的类数据 -- 一般用于子游戏获取大厅的HallData类拿取数据
         *  或者大厅获取某个子游戏的数据管理类
         */
        getByName(className: string): any;
        getByBundle(bundle: string): Map<string, any>;
        /**
         * 回收指定bundle 下注册的所有类
         * @param bundle
         */
        restoreBundle(bundle: string): any;
        /**
         * 回收全部
         */
        restoreAll(): any;
        /** 更新子游戏配置列表 */
        updateGameListInfo(list: object[]): any;
        /** 获取子游戏配置列表 */
        getGameConfigList(betStatus: gea.enums.hallType, tagType?: gea.enums.tabType): hlgame.interfaces.IConfig[];
        /** 设置子游戏层 */
        setGameLayer(value: cc.Node): any;
        /** 进入子游戏 */
        enterSubGame(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): any;
        /** 进入子游戏 */
        enterSubGameById(gameId: number, autoEnter?: boolean): any;
        /** 根据bundle获取版本号 */
        getBundlVersion(bundle: string): string;
        /** 预加载子游戏 */
        preLoadSubGame(gameId: number): any;
        /** 返回大厅 */
        goBackToHall(): any;
        /** 加载bundle配置 */
        requestBundleConfig(force?: boolean): Promise<any>;
        /** 获取bundle配置 */
        getBundleConfig(bundle: string): hlgame.interfaces.IConfig;
        /** 获取bundle配置 */
        getBundleConfigByGameId(gameId: number): hlgame.interfaces.IConfig;
        /** 我的个人信息 */
        getMyUserInfo(): hlgame.UserInfo;
        /** 当前玩家信息 */
        myUserInfo: hlgame.UserInfo;
        /** 当前大厅配置 */
        hallConfig: hlgame.interfaces.IConfig;
        /** 获取 subGameManager */
        subGameMgr: gea.interfaces.manager.ISubGameManager;
        /** 获取当前打开中的子游戏信息 */
        getCurSubGameInfo(): hlgame.interfaces.IConfig;
        handleIpcMessage(data: {
            type: string;
            webId: string | number;
            args?: any;
        }): any;
        /**
         * 重新排序游戏列表  返回是否有重新排序
         * @param isLevelUp 是否等级提升
         */
        sortGameList(isLevelUp: boolean, betStatus: gea.enums.hallType): boolean;
        /** 预加载游戏入口预制体 */
        loadGameEntrance(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): gea.interfaces.manager.IGameManager;
        /** 货币汇率 */
        exchangeRate: number;
        /** 货币符号 */
        moneySign: string;
        /** 转换货币数值文本 科学计算法 */
        exchangeMoneyStr(money: number, effectiveMin?: number): string;
        /** 转换货币数值文本 科学计算法 强制不带货币符号 - 和exchangeMoneyStr功能相同，只是不带货币标识 */
        exchangeMoneyStrNoMSign(money: number, effectiveMin?: number): string;
        /** 转换货币数值文本 科学计算法
     * 检测是否显示货币符号*/
        exchangeMoneyStrCMSign(money: number, noMoneySign?: boolean, effectiveMin?: number): string;
        /** 转换货币数值文本 科学计算法 小数后最后不保留0 */
        exchangeMoneyStrNoEndZero(money: number, effectiveMin?: number): string;
        /** 转换数值 */
        exchangeMoneyNum(money: number): number;
        /** 设置货币数值文本 科学计算法 */
        exchangeMoneyLabel(money: number, label: cc.Label, effectiveMin?: number): string;
        /** 缩短显示科学计算法 默认大于1000就转换 */
        exchangeMoneyShort(money: number, effectiveMin?: number): string;
        /** 获取所有的游戏信息列表 */
        getAllGameList(): hlgame.interfaces.IConfig[];
        /** 历史记录 bet 数值显示 */
        historyBetMoney(money: number, effectiveMin?: number): string;
        /** 历史记录 Profit 数值显示 */
        historyProfitMoney(money: number, effectiveMin?: number): string;
        /** 检查筹码是否足够
         *  返回true则表示筹码足够
        */
        /** 获取当前游戏上一局赢钱数 */
        getGameLastWin(gameId?: number): number;
        /** 设置上一局赢钱数 */
        saveGameNewWin(value: number, gameId?: number): any;
        checkMoney(money: number, autoOpenShop?: boolean): boolean;
        /** 检查钻石是否足够
         *  返回true则表示钻石足够
         */
        checkDiamond(Diamond: number, autoOpenShop?: boolean): boolean;
        /** 更新jackpot */
        updateJackpot(gameId: number, value: number[]): any;
        /** 获取指定游戏 jackpot */
        getJackPot(gameId: number): number[];
        /** 去服务器请求最新jackpot */
        requestJackPot(gameId: number): any;
        getJackpotMap(): Map<number, number[]>;
        setLocalGameVersion(bundle: string, version: string): any;
        /** 获取对应本地包版本号，返回 null 非本地包 */
        getLocalGameVersion(bundle: string): string;
        /** 是否有本地包 */
        checkIsLocalGame(bundle: string): boolean;
        /** 大厅中修改多语言标识 */
        changeLanguage(lan: string): any;
        /** 日志远程打印 */
        hackerLog(https?: string): void;
        /**
         * 子游戏操作相关点击延时，防止功能按钮多点重复点击等造成异常问题
         */
        checkGameCtrClick(): boolean;
        /**
         * 根据下注数和赢钱数，获取 子游戏 奖励倍数类型
         * @param bet   下注数
         * @param win   赢的数
         * @param Exlslot_gameProvider  slot游戏定义表
         * @param gameId    游戏ID 可空，自动获取当前游戏
         * @returns
         */
        getSlotGameWinType(bet: number, win: number, Exlslot_gameProvider: any, gameId?: number): number;
        /** 获取子游戏的奖励倍数列表 */
        getSlotGameWinTypes(Exlslot_gameProvider: any, gameId?: number): number[];
    }
}
declare namespace hlgame.interfaces {
    interface IConfigData {
        /** 所属平台名，自身平台则是填入 app*/
        platform: string;
        /** 横竖屏标识  1 竖屏 2 横屏 */
        orientation: gea.enums.orientation;
        /** 是否锁定屏幕旋转  0默认锁定   1 不锁定表示该游戏有切屏功能，游戏控制旋转 */
        sensor: gea.enums.sensor;
        /** 游戏名字*/
        gameName: string;
        game_name_eng: string;
        /** 游戏资源地址 填空app 会根据域名和规则组合地址，如果是第三方平台 bundleUrl则是该游戏的H5地址 */
        url: string;
        /** H5链接游戏的完整地址 */
        h5Url: string;
        /** 子游戏入口 prefab */
        entrancePrefab: string;
        /** 游戏icon 地址 */
        gameIcon: string;
        /** 游戏icon  多格尺寸地址 */
        gameIconExtend: string;
        /** h5 游戏入口icon */
        gameH5Icon: string;
        /** 入口类型 */
        entranceType: gea.enums.entranceType;
        /**游戏ID */
        gameId: number;
        /**bundle 名称 */
        bundle: string;
        /** 开放等级 */
        level: number;
        /** 是否常驻内存  1 是 0 否*/
        retain: number;
        /** 版本 */
        version: string;
        /** 旧版本 当前缓存内的版本号 如果没有需要更新，会和version一样 */
        oldVersion: string;
        /** 排序id 默认从左到右，数值越小，越靠左 */
        sort: number;
        /** 类型 */
        type: gea.enums.bundle;
        /** 是否需要默认顶部条，目前用于个第三方游戏配置用。 自身子游戏自己调用 */
        needTopBar: number;
        /** 所属大厅类型 1.普通大厅  2.高倍大厅 */
        hallType: gea.enums.hallType;
        /** 子签页类型： 1.hot -2 all  */
        tabType: gea.enums.tabType;
        /** 入口标签：1.hot   2 new  3其他（预留） */
        tag: gea.enums.tag;
        /** 扩展数据 根据需要使用 */
        extend: any;
        /** 游戏当前状态 状态 1.开服 2.关服 3.维护 4.删除  5.预告 */
        status: number;
        /** jackpot增量比， a,b,c,d 格式，如果未空则表示没有jackpot内容 */
        jackpot: string;
        jackpotValues: number[];
        /** 热度 */
        hot: number;
        /** 游戏分类 ID  */
        type_id: number;
        /**  最大赢奖数*/
        Maximum_win: string;
        /** h5二次大厅：波动度 1=low 2=Medium 3=high */
        Volatility: number;
        /** h5二次大厅：RTP */
        RTP: string;
        /** h5二次大厅：上架时间戳 */
        online: number;
        /** h5二次大厅：标签文本 */
        Label_desc: string;
        /** 入口Node */
        entranceNode: any;
        /** 是否已经下载过在本地 */
        isDownLoad: boolean;
        /** 是否需要更新- 版本号改变 */
        isUpdate: boolean;
        /** 是否在缓存中 */
        isInCache: boolean;
        /** 指定父层 - 子游戏是默认父层不需要设置，非子游戏的根据需要设置对应的父层 */
        parent: any;
        /** 是否本地 配置了是本地，本地开发使用，不拼接URL */
        isLocal: boolean;
        /** app版  初始下载zip包 尝试次数，默认0 如果超过3次，说明连续三次下载失败。不再下载zip。走引擎自带更新模式 */
        downZipTryCount: number;
        /** 是否加载入口资源中 */
        isInLoadGameEntrance: boolean;
        /** 是否正在该游戏中 */
        isInGame: boolean;
        /** bundle包正在加载中 */
        isInLoadBundle: boolean;
        /** 子游戏的主mainPanel界面,用于自动断线重连使用 */
        mainPanel: gea.interfaces.ui.IUIClass;
        /** 子游戏的初始化协议信息内容，某些通用界面初始化时候需要数据 */
        slotInitRes: any;
    }
    interface IConfig extends IConfigData {
        setup(config: any): void;
        reset(): void;
        setupLocal(config: {
            platform?: string;
            /** 游戏名字*/
            game_name?: string;
            /** 横竖屏标识  1 竖屏 2 横屏 */
            orientation?: gea.enums.orientation;
            /** 游戏资源地址 填空app 会根据域名和规则组合地址，如果是第三方平台 bundleUrl则是该游戏的H5地址 */
            url?: string;
            /** H5链接游戏的完整地址 */
            h5Url?: string;
            /** 是否本地 配置了是本地，url则为空 */
            isLocal?: boolean;
            /** 子游戏入口 prefab */
            entrance_prefab?: string;
            /** 游戏icon 地址 */
            game_icon?: string;
            /** 游戏icon  h5 地址 */
            game_icon_one?: string;
            /**游戏ID */
            game_id?: number;
            /** 版本 */
            version?: string;
            /**uid */
            uid?: string;
            /**bundler */
            bundle?: string;
            /** 是否已经下载过在本地 */
            isDownLoad?: boolean;
            /** 是否在缓存中 */
            isInCache?: boolean;
            /** 类型 0 子游戏  1 大厅 */
            type?: gea.enums.bundle;
            /** 指定父层 */
            parent?: any;
            /** 是否常驻内存 */
            retain?: number;
            /** 扩展数据 根据需要使用 */
            extend?: any;
            /** 入口Node */
            entranceNode?: any;
            /** 是否需要默认顶部条，目前用于个第三方游戏配置用。 自身子游戏自己调用 */
            needTopBar?: number;
            hall_type?: gea.enums.hallType;
            tab_type?: gea.enums.tabType;
            tag?: gea.enums.tag;
            sort?: number;
            entrance_type?: gea.enums.entranceType;
            status?: gea.enums.status;
            gameIconExtend?: string;
            hot?: number;
        }): void;
    }
}
declare namespace gea.manager {
    class SubGameCfgManager implements gea.interfaces.manager.ISubGameCfgManager {
        private _mapBundleCfg;
        private _mapBundleCfg2;
        private _mapGameCfg;
        private _mapHlConfig;
        private _subGameList;
        private _mapTabGameList;
        /** 高倍 */
        private _mapHeightTabGameList;
        private _localData;
        private _versionInfo;
        /** 本地缓存key */
        private _localStorageKey;
        constructor();
        startUp(localStorageKey?: string): void;
        startUpVersion(json: any): void;
        /** 根据bundle获取版本号 */
        getBundlVersion(bundle: string): string;
        /**
         * 收到服务器的子游戏列表信息
         * @param jsonData
         */
        updateGameListInfo(gamelist: any[]): void;
        /** 避免重复排序，记录一个最低可触发新解锁的等级 */
        private _lastOpenLevel;
        /** 排序 */
        sortGameList(isLevelUp?: boolean, betStatus?: number): boolean;
        /** 排布分类游戏列表 */
        layOutGameList(gameList: hlgame.interfaces.IConfig[], mapTabGameList: Map<gea.enums.tabType, hlgame.interfaces.IConfig[]>, betStatus: number): void;
        getBundleConfig(bundle: string): hlgame.interfaces.IConfig;
        /**
         * 添加bundle配置到数据中，这个接口目前用于本地运行开发调试用
         */
        addBundleConfigToMap(cfg: hlgame.interfaces.IConfig): void;
        getBundleConfigByGameId(gameId: number): hlgame.interfaces.IConfig;
        saveSubGameLoadStatus(gameConfig: hlgame.interfaces.IConfig, flag: boolean, version: string): void;
        clearSubGameLocadStatus(): void;
        getSubGameList(betStatus?: gea.enums.hallType, tagType?: gea.enums.tabType): hlgame.interfaces.IConfig[];
        /** 获取所有的游戏信息列表 */
        getAllGameList(): hlgame.interfaces.IConfig[];
        getTopBarConfig(): hlgame.interfaces.IConfig;
    }
}
declare namespace gea.enums {
    /** 大厅类型类型 */
    enum hallMode {
        /** App模式，直接在APP上显示游戏列表 */
        appMode = 1,
        /** h5链接模式 H5链接直连，目前用于第三方接入模式*/
        h5Mode = 2
    }
    /** bundle 类型 */
    enum bundle {
        /** 子游戏 */
        subGame = 0,
        /** H5独立游戏，一般是接入的第三方游戏 */
        h5Game = 1,
        /** 大厅 */
        hall = 2,
        /** H5底部条，目前用于给第三方H5游戏 */
        topBar = 3,
        /** 功能模块 */
        funMode = 4
    }
    /** 屏幕类型 横竖屏 */
    enum orientation {
        /** 竖屏 */
        PORTRAIT = 1,
        /** 横屏 */
        LANDSCAPE = 2
    }
    /** 是否锁定屏幕旋转 0 默认锁定   不锁定表示该游戏有切屏功能，游戏控制旋转 */
    enum sensor {
        /** 锁定 */
        lock = 0,
        /** 不锁定可以控制旋转 */
        unLock = 1
    }
    /** 大厅类型 */
    enum hallType {
        /** 普通场 */
        normal = 0,
        /** 高倍场 */
        hightMulti = 1,
        /** 高低倍通用 */
        both = 3
    }
    /** 大厅标签类型 */
    enum tabType {
        /** hot */
        hot = 1,
        /** 全部 */
        all = 2
    }
    /** 游戏状态 */
    enum status {
        /** 开服 */
        on = 1,
        /** 关服 */
        off = 2,
        /** 维护 */
        fit = 3,
        /** 删除下架 */
        delete = 4,
        /** 预告 */
        ForeShow = 5
    }
    /** 入口标签 */
    enum tag {
        /** 预告 */
        comingsoon = 0,
        /** hot */
        hot = 1,
        /** new */
        new = 2,
        other = 3,
        recommend = 4
    }
    /** 入口类型 */
    enum entranceType {
        /** 一格 */
        one = 1,
        /** 两格 */
        two = 2,
        /** 四格 */
        four = 3,
        /** 广告图进入 */
        banner = 10
    }
    /** 游戏分类ID */
    enum type_id {
        slot = 1,
        fishing = 2,
        tableCard = 5,
        bingo = 6,
        casino = 7,
        lobby = 100
    }
    enum AppLoadingType {
        start = 0,
        hotUpdate = 1,
        loadingHall = 2,
        enterHall = 3,
        login = 4,
        complete = 5,
        downloadApk = 6,
        hotUpdateFail = 11,
        loadingHallFail = 12,
        enterHallFail = 13,
        loginFail = 14,
        downloadApkFail = 16
    }
    enum GameLoadingType {
        start = 0,
        loadCfg = 1,
        loadRes = 2,
        login = 3,
        enterGame = 4,
        complete = 5,
        loadCfgFail = 11,
        loadResFail = 12,
        loginFail = 13,
        enterGameFail = 14
    }
    enum gameStatus {
        none = 0,
        /** 加载bundle中 */
        isInLoadBundle = 1,
        /** 加载入口gameEntrance中 */
        inInLoadGameEntrance = 2,
        /** 正在游戏中 */
        inInGame = 3
    }
    enum APKFlavor {
        DEV = "DEV",
        UAT = "UAT",
        PPRO = "PPRO"
    }
    enum language {
        en = "en",
        vi = "vi",
        pt = "pt"
    }
    /** 虚拟货币类型 */
    enum Currency {
        IGP = 4,
        Diamond = 5
    }
}
declare namespace hlgame {
    class App {
        constructor();
        /**
         * 来自app的请求调用事件,
         * 这里转发一次是为了能在游戏这边统一控制native的回调
         * @param event
         * @param args
         */
        onJsbCallHandler(event: string, ...args: any[]): void;
        launcher(): void;
        /** 1 竖屏  2 横屏 */
        orientation: gea.enums.orientation;
        landSize: cc.Size;
        protSize: cc.Size;
        /**
         * 切换横竖屏
         *  cc.macro.ORIENTATION_LANDSCAPE
         *  cc.macro.ORIENTATION_PORTRAIT
         * */
        changeOrientation(orientation: gea.enums.orientation): void;
        /** 退出APP */
        exitApp(): void;
        /** 获取APP缓存 */
        getAppCacheSize(): string;
        /** 清除APP缓存 */
        clearAppCache(): void;
        /**
         * 手机震动
         * @param time 毫秒
         */
        shakePhone(time?: number): void;
        /**
         * 复制
         * @param str
         */
        copyTextToClipboard(str: string): void;
        /**
         * 下载zip 包
         * @param url zip的url
         * @param destDir  下载的目标文件夹
         * @param bundle    对应的bundle
         */
        downloadZip(url: string, destDir: string, bundle: string): void;
        /**
         * 解压下载好的zip包到指定目录下
         * @param zipFileString zip包路径
         * @param outPathString 解压路径
         * @param bundle    解压的bundle
         * @param suffix    文件名起始序号
         * @param time      当前时间戳
         * @returns
         */
        unZipBundle(zipFileString: string, outPathString: string, bundle: string, suffix: number, time: number): string;
        /** facebook登录 */
        faceBookLogIn(): void;
        /** facebook登出 */
        faceBookLogOut(): void;
        /**
         * 谷歌登录
         */
        googleLogIn(): void;
        /**
         * 谷歌登出
         */
        googleLogOut(): void;
        /**
         * 谷歌商店购买
         */
        googleBuyStoreItem(skuId: string): void;
    }
    const app: App;
}
declare namespace gea.webView {
    /** 加载监听 */
    interface UIWebViewListener {
        onScuccess?: () => void;
        onFail?: () => void;
        onLoading?: () => void;
    }
    class UIWebView implements gea.interfaces.base.IPoolObject {
        web: cc.WebView;
        private _url_;
        /** 当前iframe窗口 */
        private contentwindow;
        /** web 加载完成回调*/
        private listener;
        /**拦截标识 (要用小写哦) */
        private scheme;
        webNode: cc.Node;
        private _width;
        private _height;
        /**当前web的标记*/
        webId: number | string;
        bundle: string;
        callbackAfterBorrow(parent: cc.Node, width: number, height: number): void;
        callbackBeforeRestore(...args: any[]): boolean;
        /**
         * 打开页面
         * @param url
         * @listener 监听器aparam
         */
        open(url: string, listener?: UIWebViewListener): void;
        /**
        * 初始当前web
        * model 显示类型
        * webId 当前页面id
        * origin 来源，嵌入的类型 1安卓，2ios，3 H5
        */
        private initWeb;
        /**
        * 来源，嵌入的类型
        * @returns 1安卓，2ios，3 H5
        */
        private getorigin;
        /**
        * 设置iframe样式
        */
        private initiframe;
        /**
        * 添加监听
        */
        private addListener;
        /**
        * 加载失败
        * @param evt
        */
        private onWebLoadedError;
        /**
        * 加载完成
        * @param evt
        */
        private onWebLoaded;
        /**
        * 加载中
        * @param evt
        */
        private onWebLoading;
        private initAPP;
        /**
        * 原生里接收到本 view下子游戏的 数据
        * @param target
        * @param url
        */
        private onJSCallback;
        /**
        * 传递数据
        * @param data
        * @returns
        */
        sendTowebMessage(data: {
            args?: any;
            type: string;
        }): void;
        closePage(): void;
        private _topHeight;
        /** 初始化topBar的控制 */
        initTopBarCtr(topHeight?: number): void;
        changeTopBarStatus(winNum: number): void;
    }
}
declare namespace gea.manager {
    class SubGameManager implements gea.interfaces.manager.ISubGameManager {
        subGameCfgMgr: SubGameCfgManager;
        /**
         * 子游戏父层
         */
        private _gameScene;
        /** 第三方游戏使用的 topBar */
        private _topBarWView;
        /** 第三方游戏使用的 webView */
        private _gameWView;
        /**
         * 加载失效时间，防止某次加载资源卡主不动
         */
        private _invalidTimer;
        /**
         * 当前子游戏配置信息
         */
        private _curGameConfig;
        /**
         * 当前是否正有子游戏加载中，目前限制不给多个加载
         */
        private _isLoading;
        private _invalidLoadTime;
        /**
         * 最后一次加载的bundle名
         */
        private _lastLoadBundle;
        /**
         * 关闭了等待被回收的bundle
         */
        private _delayReleaseBundleMap;
        get gameScene(): cc.Node;
        /** 游戏场景层  初始大厅的时候设置进来，请设置一个空图层，用于添加显示子游戏，关闭子游戏时会清空该图层 */
        setup(node: cc.Node): void;
        constructor();
        bundleZipDownComplete(bundle: string, zipPath: string, outPath: string): void;
        bundleZipDownErr(bundle: string): void;
        unZipFileToCache(bundle: string, zipPath: string, outPath: string): void;
        /**
         * 广播webview消息
         * */
        broadcastMessage(data: {
            type: string;
            webId: string | number;
            args?: any;
        }): void;
        /**
         * 进入子游戏，
         * 如果未下载过，将会先下载，默认下载后不会直接进入游戏 autoEnter 传入ture 则会自动加载进入游戏
         * 如果已经下载到本地的，直接加载进入游戏
         * @param gameConfig
         * @param autoEnter
         * @returns
         */
        enterSubGame(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): void;
        /**
         * 加载子游戏包
         * @param gameConfig
         * @param autoEnter
         * @returns
         */
        loadSubpackage(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): boolean;
        /**
         * 加载大厅功能子包  功能模块包
         * @param gameConfig
         * @param loadCb
         * @returns
         */
        loadHallSubpackage(gameConfig: hlgame.interfaces.IConfig, loadCb?: Function): boolean;
        /** 预加载游戏入口预制体 */
        loadGameEntrance(gameConfig: hlgame.interfaces.IConfig, autoEnter: boolean): void;
        /**
         * 清除当前子游戏
         */
        clearCurSubGame(): void;
        clearBundleEvent(bundle: string): void;
        getCurSubGameInfo(): hlgame.interfaces.IConfig;
        setCurSubGameInfo(value: hlgame.interfaces.IConfig): void;
        getCurInfo(): hlgame.interfaces.IConfig;
        /**
         * 预加载子游戏包
         * @param gameConfig
         * @param autoEnter
         * @returns
         */
        preLoadSubpackage(gameConfig: hlgame.interfaces.IConfig): void;
        /** 回收清理 bundle */
        private delayToReleaseBundle;
        /** 进入新游戏的时候强制清理掉上一个游戏的缓存 */
        private forceReleaseGameBundle;
        private changeSubGameLoaded;
        private checkLoadBundleStatus;
        private _orientationSetting;
        private _onEnteringBundle;
        private _onEnteringTime;
        private doEnterSubGame;
    }
}
declare namespace hlgame.interfaces {
    interface IUserInfoData {
        /** 是否自己 */
        IsMy?: boolean;
        /** 玩家协议返回的数据 */
        playerDetailRes: any;
        /** 高倍场状态：0低倍，1高倍 */
        BetStatus?: number;
        /** 筹码，游戏币 */
        Money?: number;
        /** 钻石货币 */
        Diamond?: number;
        /** 关闭的功能ID列表 */
        lockFunIds?: number[];
        AvatarUrl: string;
    }
    interface IUserInfo extends IUserInfoData {
        setup(config: {
            /** 用户ID */
            ID?: number;
            /** 账号 */
            Account?: string;
            /** 昵称 */
            Nick?: string;
            /** 等级 */
            Level?: number;
            /** 等级经验值 */
            Exp?: number;
            /** 筹码，游戏币 */
            Money?: number;
            /** 钻石货币 */
            Diamond?: number;
        }): void;
        clear(): void;
    }
}
declare namespace hlgame {
    /** 玩家信息 可以通过监听 gea.events.userInfo.xx 获得对应参数改变通知 */
    class UserInfo implements interfaces.IUserInfo {
        /** 是否自己 */
        private _IsMy?;
        /** 玩家协议返回的数据 */
        private _playerDetailRes;
        /** 高倍场状态：0低倍，1高倍 */
        private _BetStatus;
        private _DefaultAvatar;
        private _AvatarUrl;
        private _ID;
        private _VIP;
        private _Online;
        private _LastLoginTime;
        /** 筹码，游戏币 */
        private _Money;
        /** 钻石货币 */
        private _Diamond;
        /** 关闭的功能ID列表 */
        private _lockFunIds;
        get IsMy(): boolean;
        set IsMy(value: boolean);
        /** 用户ID */
        get ID(): number;
        set ID(value: number);
        get BetStatus(): number;
        set BetStatus(value: number);
        /** 昵称 */
        get Nick(): string;
        /** 昵称 */
        set Nick(value: string);
        /** 等级 */
        get Level(): number;
        /** 等级 */
        set Level(value: number);
        /** 等级经验值 */
        get Exp(): number;
        /** 等级经验值 */
        set Exp(value: number);
        /** 等级 */
        get VIP(): number;
        /** 是否在线 */
        get Online(): boolean;
        /** 最后上线时间 */
        get LastLoginTime(): number;
        /**
         * 注册时间 (时间戳, 秒)
         */
        get RegTime(): number;
        /** 最大赢奖 */
        get MaxWin(): number;
        /** 最大赢奖 */
        set MaxWin(value: number);
        /** 头像ID */
        get AvatarId(): number;
        /** 头像ID */
        set AvatarId(value: number);
        /** 头像框ID */
        get AvatarBox(): number;
        /** 头像框ID */
        set AvatarBox(value: number);
        /** 最近常玩游戏id*/
        get OftenGameId(): number;
        get DefaultAvatar(): string;
        set DefaultAvatar(value: string);
        get AvatarUrl(): string;
        set AvatarUrl(value: string);
        get lockFunIds(): number[];
        set lockFunIds(value: number[]);
        get playerDetailRes(): any;
        set playerDetailRes(value: any);
        updateExpLevel(exp: number, level: number): void;
        get Sex(): number;
        /** 上一次数据更新时间 */
        lastUpdateTime: number;
        IInfos?: {
            [Type: number]: {
                Type?: number;
                Avatar?: string;
                Identifier?: string;
                NickName?: string;
            };
        };
        /** 筹码 子游戏增加的游戏币 */
        private _gameAddMoeny;
        /** 筹码 需要延后增加的游戏币 */
        private _laterMoneyMap;
        /** 筹码 需要延后增加的游戏币 总值   不能小于0 */
        private _totalLaterMoney;
        /** 获取可以显示出来的筹码数 */
        get Money(): number;
        updateMoney(value: number, opt: number): void;
        /** 仅更新筹码数。不抛出通知 */
        set curMoney(value: number);
        /** 获取实际真正的筹码数 */
        get curMoney(): number;
        get gameAddMoeny(): number;
        set gameAddMoeny(value: number);
        /** 某些功能获得筹码后需要延后显示， 数量添加到这个变量里，
         * 需要显示时对应减去 */
        get totalLaterMoney(): number;
        /**
         * 某些功能获得筹码后需要延后显示， 数量添加到这个变量里
         * 显示完成后需要显示正常货币值则减去  设定上不能扣除-1
         * @param id    对应的功能ID 来自 pb.ChangeMoneyLogId.Id。 如果传入-1则清空掉要延迟显示的筹码信息
         * @param value 对应要调整的值, 设置负值则从前面添加的值里面扣除，扣除后小于0，会置零
         * @returns
         */
        setInLaterMoney(id: number, value?: number): number;
        /**
         * 获取指定类型对应延迟显示的筹码数
         * @param id pb.ChangeMoneyLogId.Id
         */
        getLaterMoneyById(id?: number): number;
        get Diamond(): number;
        /** 仅更新筹码数。不抛出通知 */
        set curDiamond(value: number);
        /** 获取实际真正的筹码数 */
        get curDiamond(): number;
        updateDiamond(value: number, opt: number): void;
        /** 某些功能获得筹码后需要延后显示， 数量添加到这个变量里，
         * 需要显示时对应减去 */
        get totalLaterDiamond(): number;
        /** 需要延后增加的游戏币 */
        private _laterCurrencyMap;
        /** 需要延后增加的游戏币 总值   不能小于0 */
        private _totalLaterCurrencyMap;
        /**
         * 某些功能获得筹码后需要延后显示， 数量添加到这个变量里
         * 显示完成后需要显示正常货币值则减去  设定上不能扣除-1
         * @param type  货币类型 对应道具表类型   gea.enums.Currency.Diamond
         * @param id    对应的功能ID 来自 pb.ChangeMoneyLogId.Id。 如果传入-1则清空掉要延迟显示的筹码信息
         * @param value 对应要调整的值, 设置负值则从前面添加的值里面扣除，扣除后小于0，会置零
         * @returns
         */
        setInLaterCurrency(type: number, id: number, value?: number): number;
        /**
         * 获取指定类型对应延迟显示的筹码数
         * @param type  货币类型 对应道具表类型
         * @param id pb.ChangeMoneyLogId.Id
         */
        getLaterDiamondById(type: number, id?: number): number;
        clear(): void;
        setup(config: {
            ID?: number;
            Account?: string;
            Nick?: string;
            Level?: number;
            Exp?: number;
            Money?: number;
        }): void;
    }
}
declare namespace hlgame {
    class SystemInfo {
        /** CDN 资源地址 */
        private _client_url;
        /** API/http请求地址，目前是请求游戏列表 */
        private _api_domain;
        /** 隐私协议地址 */
        private _privacypolicy;
        /** 使用说明地址 */
        private _termsOfService;
        /** 平台图片文件资源地址 */
        private _fileUrl;
        /**uid */
        private _uid;
        /**是否允许手机震动 */
        private _isVibrate;
        /**资源质量  0 普通 1 高质量  TOD 目前未开放该功能 */
        private _imageQuality;
        /** 对应app-project-creator 的版本*/
        private _version;
        /** 是否内部版本 */
        private _isOwnerBuild;
        /** 是否支持zip包下载 */
        private _isSupportZip;
        /**手机品牌 */
        private _brand;
        /**手机型号 */
        private _model;
        /**屏幕宽度 */
        private _screenWidth;
        /**屏幕高度 */
        private _screenHeight;
        /**国家码 */
        private _countryCode;
        /**用户当前环境，Test(测试环境),Product(正式环境) */
        private _env;
        /**客户端语言 */
        private _language;
        /**app唯一id */
        private _deviceId;
        /** app的版本 */
        private _appVersion;
        /** apk包的 flavor 目前有 108|UAT|PPRO */
        private _flavor;
        /** APK包的包名 */
        private _packName;
        get packName(): string;
        set packName(value: string);
        get brand(): string;
        get model(): string;
        get screenWidth(): number;
        get screenHeight(): number;
        get countryCode(): string;
        get env(): 'Test' | 'Product';
        set env(value: 'Test' | 'Product');
        get language(): string;
        set language(value: string);
        get deviceId(): string;
        set deviceId(value: string);
        get client_url(): string;
        set client_url(value: string);
        get uid(): string;
        set uid(value: string);
        get isVibrate(): boolean;
        set isVibrate(value: boolean);
        get imageQuality(): number;
        set imageQuality(value: number);
        get version(): string;
        set version(value: string);
        get appVersion(): string;
        set appVersion(value: string);
        get fileUrl(): string;
        set fileUrl(value: string);
        get api_domain(): string;
        set api_domain(value: string);
        get isOwnerBuild(): boolean;
        set isOwnerBuild(value: boolean);
        get isUAT(): boolean;
        get flavor(): string;
        set flavor(value: string);
        get isProduct(): boolean;
        get privacypolicy(): string;
        set privacypolicy(value: string);
        get termsOfService(): string;
        set termsOfService(value: string);
        private _spcialPotLangs;
        get isSpcialPot(): boolean;
        /** 设置更新多语言标识 */
        updateLanguage(lan?: string): void;
        get isSupportZip(): boolean;
        set isSupportZip(value: boolean);
        setup(config: {
            env?: 'Test' | 'Product';
            language?: string;
            deviceId?: string;
        }): void;
    }
    export const systemInfo: SystemInfo;
    export {};
}
declare namespace gea.interfaces.manager {
    interface IAssetManager {
        /**
         * @description 获取Bundle
         * @param bundle Bundle名|Bundle
         */
        getBundle(bundle: string): cc.AssetManager.Bundle;
        /**
         * 动态加载一个资源,
         * 加载已经处理了同一时间多个地方调用同一个资源加载的情况
         * 也处理了加载完成后对应的子游戏被关闭回收的情况
         * @param bundle    资源所在bundle，传空则默认使用Resource资源
         * @param path  资源路径, 以对应的bundle为根目录
         * @param type  资源类型
         * @param onProgress    进度回调
         * @param onComplete    完成回调
         */
        load(bundle: string, path: string, type: typeof cc.Asset, onProgress: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete: (error: Error, assets: cc.Asset | cc.Asset[], data?: gea.manager.ResCacheData) => void): void;
        /**
         * 马上加载单个资源,进入这个方法说明已经判断了资源是否加载过，直接加载
         * @param bundle    资源所在bundle，传空则默认使用Resource资源
         * @param path  资源路径, 以对应的bundle为根目录
         * @param type  资源类型
         * @param onProgress    进度回调
         * @param onComplete    完成回调
         */
        /**
         *  马上加载批量资源,进入这个方法说明已经判断了资源是否加载过，直接加载
         * @param bundle    资源所在bundle，传空则默认使用Resource资源
         * @param paths 资源路径列表, 以对应的bundle为根目录
         * @param onProgress    进度回调
         * @param onComplete    完成回调
         */
        doLoadList(bundle: string, paths: string[], onProgress?: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete?: (error: Error, assets: cc.Asset[]) => void): any;
        /** 文件路径加载 */
        loadDir(bundle: string, path: string, onProgress?: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete?: (error: Error, assets: cc.Asset[]) => void): any;
        preLoad(bundle: string, paths: string | string[], onProgress: (finish: number, total: number, item: cc.AssetManager.RequestItem) => void, onComplete: (error: Error, items: cc.AssetManager.RequestItem[]) => void): any;
        /**
         * 从已加载的Bundle里面获取加载对应路径的 prefab
         * @param bundle
         * @param prefabUrl
         */
        getPrefab(bundle: string, prefabUrl: string): cc.Prefab;
        /**
         * 从已加载的Bundle里面获取加载对应路径和类型的资源
         * @param bundle
         * @param patch
         * @param type
         */
        getAsset(bundle: string, patch: string, type: typeof cc.Asset): cc.Asset;
        /**
         * 回收
         * @param bundle
         * @param path
         * @param type
         */
        releaseAsset(bundle: string, path: string, type: typeof cc.Asset): any;
        getCacheMgr(): gea.interfaces.manager.ICacheManager;
        initRemote(): gea.manager.RemoteLoader;
        /**
         * 加载远程图片资源
         * @param url "http://192.168.99.7:8080/gameImage/game1.png"
         * @param bindBundle
         */
        loadRemote(url: string, bindBundle?: string): Promise<cc.SpriteFrame>;
        /**
         * 加载远程spine动画资源
         * @param path "http://192.168.99.7:8080/spine"
         * @param name  "end_page_mega_win"
         * @param bindBundle
         */
        loadRemoteSkeleton(path: string, name: string, bindBundle?: string): Promise<sp.SkeletonData>;
        /** 后台静默加载 */
        appebdSilentPreload(bundle: string, url: string, type?: typeof cc.Asset): IAssetManager;
        /** 静默检查轮询 */
        checkSlientPreLoad(): any;
        /** 清除指定bundle资源的静默加载 */
        clearGameSlientPreload(bundle: string): IAssetManager;
        /** 编辑器加载  游戏逻辑能禁用 */
        loadEditorSpineRes(url: string, callback: Function): any;
    }
}
declare namespace gea.manager {
    class GameManager implements gea.interfaces.manager.IGameManager {
        private _mapBundlePool;
        private _mapClassPool;
        private _mapPool;
        constructor();
        register<T extends gea.interfaces.manager.IGameMgrPool>(bundle: string, poolClass: {
            prototype: T;
            new (): T;
        }, ...args: any[]): T;
        unRegister(bundle: string, poolClass: any): void;
        get<T extends gea.interfaces.manager.IGameMgrPool>(poolClass: {
            prototype: T;
            new (): T;
        }): T;
        getByName(className: string): any;
        getByBundle(bundle: string): Map<string, any>;
        restoreBundle(bundle: string): void;
        restoreAll(): void;
        private _subGameMgr;
        get subGameMgr(): gea.interfaces.manager.ISubGameManager;
        /** 更新子游戏配置列表 */
        updateGameListInfo(list: object[]): void;
        /** 获取某个子游戏配置信息 */
        getBundleConfig(bundle: string): hlgame.interfaces.IConfig;
        /** 获取bundle配置 */
        getBundleConfigByGameId(gameId: number): hlgame.interfaces.IConfig;
        /** 获取子游戏配置列表 */
        getGameConfigList(betStatus?: gea.enums.hallType, tagType?: gea.enums.tabType): hlgame.interfaces.IConfig[];
        /** 获取当前打开中的子游戏信息 */
        getCurSubGameInfo(): hlgame.interfaces.IConfig;
        /** 根据bundle获取版本号 */
        getBundlVersion(bundle: string): string;
        setGameLayer(value: cc.Node): void;
        /** 进入子游戏 */
        enterSubGame(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): void;
        /** 进入子游戏 */
        enterSubGameById(gameId: number, autoEnter?: boolean): void;
        /** 预加载子游戏 */
        preLoadSubGame(gameId: number): void;
        /** 返回大厅 */
        goBackToHall(): void;
        /** 游戏列表请求时间，记录一个请求时间。5秒内即使传入 force也不重新请求 */
        _requestTime: number;
        _hasGameConfig: boolean;
        /** 加载bundle配置 */
        requestBundleConfig(force?: boolean): Promise<any>;
        resolveGameList(resolve: any, info: any): void;
        /**
        * 重新排序游戏列表  返回是否有重新排序
        * @param isLevelUp 是否等级提升
        */
        sortGameList(isLevelUp: boolean, betStatus: gea.enums.hallType): boolean;
        /** 获取所有的游戏信息列表 */
        getAllGameList(): hlgame.interfaces.IConfig[];
        /** 预加载游戏入口预制体 */
        loadGameEntrance(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): gea.interfaces.manager.IGameManager;
        hallConfig: hlgame.interfaces.IConfig;
        myUserInfo: hlgame.UserInfo;
        /** 我的个人信息 */
        getMyUserInfo(): hlgame.UserInfo;
        /** 货币符号 */
        moneySign: string;
        /** 货币汇率 */
        exchangeRate: number;
        /** 转换数值 */
        exchangeMoneyNum(money: number): number;
        fixEndZero(str: string): string;
        /** 转换货币数值文本 科学计算法 */
        exchangeMoneyStr(money?: number, effectiveMin?: number): string;
        /** 转换货币数值文本 科学计算法
         * 检测是否显示货币符号
        */
        exchangeMoneyStrCMSign(money?: number, noMoneySign?: boolean, effectiveMin?: number): string;
        /** 转换货币数值文本 科学计算法 强制不带货币符号 */
        exchangeMoneyStrNoMSign(money?: number, effectiveMin?: number): string;
        /** 转换货币数值文本 科学计算法 小数后最后不保留0 */
        exchangeMoneyStrNoEndZero(money?: number, effectiveMin?: number): string;
        /** 设置货币数值文本 科学计算法 */
        exchangeMoneyLabel(money: number, label: cc.Label, effectiveMin?: number): string;
        /** 缩短显示科学计算法 默认大于1000就转换 */
        exchangeMoneyShort(money?: number, effectiveMin?: number): string;
        /** 历史记录 bet 数值显示 */
        historyBetMoney(money?: number, effectiveMin?: number): string;
        /** 历史记录 Profit 数值显示 */
        historyProfitMoney(money?: number, effectiveMin?: number): string;
        /** 获取当前游戏上一局赢钱数 */
        getGameLastWin(gameId?: number): number;
        /** 设置上一局赢钱数 */
        saveGameNewWin(value: number, gameId?: number): void;
        /** 检查筹码是否足够
         *  返回true则表示筹码足够
        */
        checkMoney(money: number, autoOpenShop?: boolean): boolean;
        /** 检查钻石是否足够
        *  返回true则表示钻石足够
        */
        checkDiamond(Diamond: number, autoOpenShop?: boolean): boolean;
        slotGameWinTypsMap: Map<number, number[]>;
        /**
         * 获取 子游戏 奖励倍数类型
         * @param bet   下注数
         * @param win   赢的数
         * @param Exlslot_gameProvider  slot游戏定义表
         * @param gameId    游戏ID 可空，自动获取当前游戏
         * @returns
         */
        getSlotGameWinType(bet: number, win: number, Exlslot_gameProvider: any, gameId?: number): number;
        /** 获取子游戏的奖励倍数列表 */
        getSlotGameWinTypes(Exlslot_gameProvider: any, gameId?: number): number[];
        /** 子游戏jackpot信息 */
        jackpotMap: Map<number, number[]>;
        /** 更新jackpot */
        updateJackpot(gameId: number, value: number[]): void;
        /** 获取指定游戏 jackpot */
        getJackPot(gameId: number): number[];
        /** 去服务器请求最新jackpot */
        requestJackPot(gameId: number): void;
        getJackpotMap(): Map<number, number[]>;
        gameCtrclickTime: number;
        /**
         * 子游戏操作相关点击延时，防止功能按钮多点重复点击等造成异常问题
         */
        checkGameCtrClick(): boolean;
        /** 大厅中修改多语言标识 */
        changeLanguage(lan: string): void;
        /** 本地包版本配置 */
        localMap: Map<string, string>;
        setLocalGameVersion(bundle: string, version: string): void;
        /** 获取对应本地包版本号，返回 null 非本地包 */
        getLocalGameVersion(bundle: string): string;
        /** 是否有本地包 */
        checkIsLocalGame(bundle: string): boolean;
        /**
         * 当web环境时会使用
         * @param event
         */
        receiveMessage(event: any): void;
        /**
         * 处理webView消息 广播出去给大厅和其他子包
         * @param data
         */
        handleIpcMessage(data: {
            type: string;
            webId: string | number;
            args?: any;
        }): void;
        httpLogErrCount: number;
        gealog: Function;
        hackerLog(https?: string): void;
        sendHttpLog(https: string, message: string, ...optionalParams: any[]): void;
    }
}
declare namespace gea {
    function get<T extends gea.interfaces.manager.IGameMgrPool>(poolClass: {
        prototype: T;
        new (): T;
    }): T;
    function register<T extends gea.interfaces.manager.IGameMgrPool>(bundle: string, poolClass: {
        prototype: T;
        new (): T;
    }, ...args: any[]): T;
}
declare namespace gea.interfaces.manager {
    interface IGameWebSiteMgr {
        HALL: string;
        /** 图片版本文件 */
        _webSiteImgVersion: any;
        /** 初始化加载 云端图片资源版本文件 */
        initWebSiteImgVersion(): any;
        /** 获取云端图片路径 */
        getWebSiteImgLoadUrl(url: string): string;
        /** 设置加载云端图片显示
        *  bindBundle  资源绑定的Bundle  绑定后会跟随Bundle的释放而释放资源  不传则绑定在大厅
        */
        setWebSiteImg(url: string, img: cc.Sprite, bindBundle?: string, onComplete?: (assets: cc.SpriteFrame) => void): gea.interfaces.manager.IGameWebSiteMgr;
        /** 设置不可自动合批的云端图， 图片需要修改使用纹理，所有不能合图 */
        setWebSiteImgNoPackable(url: string, img: cc.Sprite, bindBundle?: string, onComplete?: (assets: cc.SpriteFrame) => void): gea.interfaces.manager.IGameWebSiteMgr;
        /** 回收清理云图 */
        clearNoPackableWebRes(bundle: string): void;
        /** 预加载云端图片 */
        preloadWebSiteImg(url: string, bindBundle?: string): gea.interfaces.manager.IGameWebSiteMgr;
    }
}
declare namespace gea.manager {
    class GameWebSiteMgr implements gea.interfaces.manager.IGameWebSiteMgr {
        HALL: string;
        /** 图片版本文件 */
        _webSiteImgVersion: any;
        /** 初始化加载 云端图片资源版本文件 */
        initWebSiteImgVersion(): void;
        /** 获取云端图片路径 */
        getWebSiteImgLoadUrl(url: string): string;
        spriteUrlMap: Map<string, string>;
        /** 设置加载云端图片显示
         *  bindBundle  资源绑定的Bundle  绑定后会跟随Bundle的释放而释放资源  不传则绑定在大厅
         */
        setWebSiteImg(url: string, img: cc.Sprite, bindBundle?: string, onComplete?: (assets: cc.SpriteFrame) => void): gea.interfaces.manager.IGameWebSiteMgr;
        preloadList: string[][];
        /** 预加载 */
        preloadWebSiteImg(url: string, bindBundle?: string): gea.interfaces.manager.IGameWebSiteMgr;
        doNextPreloadWebSiteImg(data?: any): void;
        noPackageResMap: Map<string, Map<string, cc.SpriteFrame>>;
        /** 回收清理云图 */
        clearNoPackableWebRes(bundle: string): void;
        /** 设置不可自动合批的云端图， 图片需要修改使用纹理，所有不能合图 */
        setWebSiteImgNoPackable(url: string, img: cc.Sprite, bindBundle?: string, onComplete?: (assets: cc.SpriteFrame) => void): gea.interfaces.manager.IGameWebSiteMgr;
    }
}
declare namespace gea.manager {
    class LoadingTxtManager {
        loadingMap: Map<number, Map<number, {
            total: number;
            list: any[];
        }>>;
        langMap: Map<number, string>;
        hallExlLoadTabls: any[];
        HALL: string;
        resources: string;
        curLang: string;
        /** 设置loading配置列表 请先设置了多语言之后再设置*/
        setGameLoadingTxtTab(bundle: string, gameId: number, exlLoadTabls: any[]): void;
        /**
         *  获取一条loading文本
         * @param gameId
         * @param scene 1：大厅资源加载/更新前；2：子游戏loading；3：子游戏内跑马灯
         * @returns
         */
        getGameLoadingTxt(gameId: number, scene?: number): string;
        /** 语言切换 */
        updateLanguage(): void;
    }
}
declare namespace gea.adapters.https {
    class HttpModel {
        private _url;
        private _successCallback;
        private _failCallback;
        private _endCallback;
        /**
         *
         * @param host 要发送的服务器地址
         * @param params 参数
         */
        constructor(host: string, params?: any);
        setFailCallback(callback: any): void;
        setSuccessCallback(callback: any): void;
        setEndCallback(callback: any): void;
        _httpSuccess(res: any, needParse: any, overWithClear: any, postData: any): void;
        _httpFail(err: any, overWithClear: any): void;
        /**
         *
         * @param transPortType 传输的类型?post或者get
         * @param postData 要post的数据(仅对post有效)
         * @param needParse 是否需要对服务器返回的数据解析成对象
         * @param overWithClear 是否一次http请求后自动清理(清空回调函数和地址)
         * @param canUseJsonP 是否可以使用jsonp
         */
        send(transPortType?: string, postData?: Object, needParse?: boolean, overWithClear?: boolean, canUseJsonP?: boolean, token?: string): void;
        clear(): void;
    }
    class HttpClient {
        requsetNum: number;
        appId: string;
        appKey: string;
        Code: {
            /**成功 0 */
            Ok: number;
            /** 参数错误 1 */
            ParameErr: number;
            /** 服务器逻辑错误 4 */
            ServerErr: number;
            /**登录失败  1260*/
            LoginFailed: number;
            /** 账号类型不存在 1261*/
            AccountTypeNotExists: number;
            /** 邮箱格式不正确 1262*/
            EmailFormatWrong: number;
            /** 验证码错误 */
            IncorrectVerifyCode: number;
            /** 账号或密码错误 1264*/
            IncorrectAccountOrPassword: number;
            /** 账号不存在 1265*/
            IncorrectAccount: number;
            /**注册失败 1240*/
            RegisterFailed: number;
            /** 已被注册 1241*/
            RegisterAccountExist: number;
            /** 邮箱格式不正确 1242*/
            RegisterEmailFormatWrong: number;
            /** 注册类型不存在 1243*/
            RegisterTypeNotExists: number;
        };
        /** 登录类型 */
        Identity_type: {
            /** 0试玩账号,不保存  */
            Test: number;
            /** 1游客账号(客户端去获取设备ID) */
            Guest: number;
            /** 2邮箱账号，正式 */
            Email: number;
            /** 3facebook账号，正式 */
            Facebook: number;
            /** 4谷歌账号，正式 */
            Google: number;
            /** 5手机账号，正式 */
            Phone: number;
        };
        /**
         * 获取签名
         * @returns
         */
        getSign(data: any): string;
        getRequsetNum(): number;
        /** post 数据 */
        httpPost(data: any, host: string): void;
        /**
         * http请求
         * @param data
         * @param host
         * @param endCallback
         * @param transPortType GET   or  POST
         */
        httpRequest(data: any, host: string, endCallback: Function, transPortType?: string, token?: string): void;
        /**
         * 登陆/
         * @param identity_type  登录类型 gea.http.Identity_type
         * @param identifier 身份信息/账号
         * @param credential  身份凭据/密码
         * @param endCallback
         */
        login(identity_type: number, identifier: string, credential: string, endCallback: (info: any, err: any, postData: any) => void): void;
        /**
         * 注册
         * @param identity_type
         * @param identifier
         * @param credential
         * @param endCallback
         */
        register(identity_type: number, identifier: string, credential: string, endCallback: (info: any, err: any, postData: any) => void): void;
        launch(token: string, endCallback: (info: any, err: any) => void): void;
        /** 棋牌类历史记录 */
        history(gameId: number, startTime: number, endTime: number, page: number, endCallback: (info: any, err: any, postData: any) => void): void;
        /**
         * 请求服务入口状态
         * @param endCallback
         */
        entranceStatus(endCallback: (info: any, err: any) => void): void;
        /** log记录。去重 */
        logMap: Map<string, string>;
        /**
         * 上传客户端日志 (无需token)
         * */
        clientLog(content: string, log_level?: "info" | "warn" | "error"): void;
        /** 获取游戏列表 */
        getGameList(endCallback: (info: any, err: any) => void): void;
    }
}
declare namespace hlgame.interfaces.utils {
    interface IUserInfoManager {
        /**
         * 初始化，把配置表的 头像表和头像框表设置进来
         * @param avatars
         * @param avatarBoxs
         */
        initUserInfoMgr(avatars: {
            id: number;
            url: string;
        }[], avatarBoxs: {
            id: number;
            url: string;
        }[]): any;
        /**
         * 设置请求用户数据时的延迟信息
         *
         * 当延迟时间未设置或者<=0时，默认在下一帧请求用户数据，以优化在for循环里循环请求数据的情况
         * @param time 延迟时间 单位ms default=200ms
         * @param forever 是否为以后的每次请求都设置延迟 default=false
         */
        delayTime(time?: number, forever?: boolean): IUserInfoManager;
        /**
         * 获取玩家信息
         * @param uid 单个uid或者一个uid数组
         * @param callback 回调函数
         * @param callbackScope 回调函数作用域
         * @param callbackArgs 回调函数参数,在用户数据之前
         */
        get(uid: (string | number) | (string | number)[], callback: (...infos: hlgame.UserInfo[]) => void, callbackScope?: any, ...callbackArgs: any[]): IUserInfoManager;
        /**
         * 异步延迟，模拟app获取用户数据的延迟，单位ms，默认1000ms，最小值限制为500，必须验证一下延迟的情况，仅在本地调试时生效
         * @param value
         */
        asyncTime(value: number): IUserInfoManager;
        /** 更新头像信息 */
        updateAvatar(uid: number, avatarId: number): any;
        /** 更新 登录账号类型  IdentifierInfo[]*/
        updateIInfos(uid: number, infos: any[]): hlgame.UserInfo;
        /** 获取对应UID的 账号绑定类型 如果返回空值表示没有绑定该账号类型*/
        getIdentifier(uid: number, type: number): any;
        /** 获取远端头像头像框 */
        getWebHeadUrl(url: string): string;
    }
}
declare namespace hlgame.utils {
    /**性别 */
    enum sex {
        /**女性 */
        female = 0,
        /**男性 */
        male = 1
    }
    class UserInfoManager implements hlgame.interfaces.utils.IUserInfoManager {
        RES: string;
        getWebHeadUrl(url: string): string;
        /** 设置系统头像列表 */
        initUserInfoMgr(avatars: {
            id: number;
            url: string;
        }[], avatarBoxs: {
            id: number;
            url: string;
        }[]): void;
        onPlayerDetailRes(res: any, seq: number): void;
        updateAvatar(uid: number, avatarId: number): void;
        /** 更新 登录账号类型  IdentifierInfo[]*/
        updateIInfos(uid: number, infos: any[]): hlgame.UserInfo;
        /** 获取对应UID的 账号绑定类型 如果返回空值表示没有绑定该账号类型*/
        getIdentifier(uid: number, type: number): any;
        delayTime(time?: number, forever?: boolean): UserInfoManager;
        get(uid: (string | number) | (string | number)[], callback: (...infos: hlgame.UserInfo[]) => void, callbackScope?: any, ...callbackArgs: any[]): UserInfoManager;
        asyncTime(value: number): UserInfoManager;
    }
}
declare namespace gea {
    /** 加解密 */
    const bitEncrypt: gea.interfaces.common.IBitEncrypt;
    /** UI 管理器 */
    const ui: adapters.interfaces.ui.IUIManager;
    /** 资源类管理 */
    const assetMgr: gea.interfaces.manager.IAssetManager;
    /** 本地缓存数据管理 */
    const localStorage: gea.interfaces.common.ILocalStorage;
    /** 服务器存储数据管理 */
    const serverStorage: gea.common.ServerStorage;
    /** 音效音乐管理 */
    const audioMgr: gea.interfaces.manager.IAudiosManager;
    /** 游戏管理 */
    const game: gea.interfaces.manager.IGameManager;
    /** http 请求 */
    const http: gea.adapters.https.HttpClient;
    /** 加载管理 */
    const loadMgr: gea.manager.LoadManager;
    /** 多语言管理 */
    const language: gea.common.Language;
    /** 玩家信息管理 */
    const userInfoMgr: hlgame.interfaces.utils.IUserInfoManager;
    /** 玩家信息设置- 设置名字，头像，性别 */
    const userRender: hlgame.interfaces.utils.IUserRender;
    /** loading 文本管理 */
    const loadingTxtMgr: gea.manager.LoadingTxtManager;
    /** 云端图片版本管理 */
    const gameWebSiteMgr: gea.interfaces.manager.IGameWebSiteMgr;
}
declare let prototype: any;
declare namespace gea.interfaces.common {
    /**
     * 加解密数据
     */
    interface IBitEncrypt {
        decode(content: string, key?: string): string;
        encode(content: string, key?: string): string;
    }
}
declare namespace gea.interfaces.common {
    /**
     * 本地缓存数据
     */
    interface ILocalStorage {
        getItem(key: string, defaultValue?: any): any;
        setItem(key: string, value: string | number | boolean | object): void;
        removeItem(key: string): void;
        clear(): void;
    }
}
declare namespace gea.interfaces.manager {
    interface IAudiosManager {
        /** 默认Button点击会设置通用点击音效，
        * 如果不需要的，把Button的name设置为这个，PS：是设置Button Component的name, 不是Node节点的
        * */
        NOT_CLICK_AUDIO: string;
        /** 播放  */
        play(audioName: string, bundle: string, isLoop?: boolean, volume?: number, onStartFun?: (auId?: number) => void): number;
        /** 播放背景音乐
         * force  是否强制停止当前背景音乐播放 默认ture   传入false 会判断音乐名字是否一致，一致则跳过
         * */
        playBgMusic(audioName: string, bundle: string, volume?: number, force?: boolean): {
            audioName: string;
            bundle: string;
            volume: number;
            audioId: number;
        };
        /** 获取 对应 cc.audioEngine 中播放的AudioId */
        getPlayAudioId(auid: number): number;
        stop(audioID: number): void;
        /** 暂停 */
        pause(audioID: number): void;
        /** 恢复 */
        resume(audioID: number): void;
        /** 暂停所有 */
        pauseAll(): void;
        /** 恢复所有 */
        resumeAll(): void;
        /** 停止播放所有 */
        stopAll(): void;
        /** 切换声音状态 */
        switchSoundStatus(): any;
        /** 设置声音状态 */
        setSoundStatus(isMute: boolean): any;
        /** 设置音效音量百分比 */
        setSoundVolumePer(value: number): any;
        /** 设置音量 */
        setVolume(audioID: number, volume: number): void;
        /** 切换音效状态 */
        switchSoundEffStatus(): any;
        /** 切换背景音乐状态 */
        switchBgMusicStatus(): any;
        /** 设置背景音乐音量 */
        setBgMusicVolumePer(value: number): any;
        /** 设置音效屏蔽状态 */
        switchShield(flag: boolean): any;
        /** 是否静音状态 */
        isMute: boolean;
        /** 是否静音音效 */
        isMuteSound: boolean;
        /** 是否静音背景音效 */
        isMuteBgMusic: boolean;
        /** 是否屏蔽音效音乐 效果和全静音一样,但是不会存缓存*/
        isShield: boolean;
        /**
         * 设置Button 点击时不使用默认点击音效。
         * 会把界面的 button Compone 名字改为 "notClickAudio"，以此作为标识不使用默认点击音效
         * 也可以自己手动设置
         * @param node
         */
        setNotDefaultClickAudio(node: cc.Node): gea.interfaces.manager.IAudiosManager;
        /** 设置按钮点击音效参数  bundle 和 url 不传，则表示不需要音效 */
        setButtonClickSound(btn: cc.Button, bundle?: string, url?: string): IAudiosManager;
        curBundle: string;
        curExlaudioProvider: any;
        prefixUrl: string;
        /** 重置路径 */
        resetAudioPrefixUrl(): any;
        /** 播放子游戏的音乐音效 以excel表的key值 播放 这个方法主要给子游戏使用 */
        playAuido(key: string, isLoop?: boolean, volume?: number, onStartFun?: (auId?: number) => void, isBgMusic?: boolean): number;
        /** 播放子游戏背景音效，  以excel表的key值 播放 这个方法主要给子游戏使用 */
        playGameBGM(key: string, volume?: number, force?: boolean): {
            audioName: string;
            bundle: string;
            volume: number;
            audioId: number;
        };
        updateAudioExcel(bundle: string, exlaudioProvider: any, prefixUrl?: string): any;
    }
}
declare namespace gea.interfaces.manager {
    interface ICacheManager {
        removeBundle(bundle: string): any;
        remove(bundle: string, path: string): any;
    }
}
declare namespace gea.abstracts.ui {
    abstract class ModalBase extends gea.adapters.abstracts.ui.UIBase {
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        static get uiType(): gea.enums.ui.ui_type;
    }
}
declare namespace gea.abstracts.ui {
    abstract class OverModalBase extends gea.adapters.abstracts.ui.UIBase {
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        static get uiType(): gea.enums.ui.ui_type;
    }
}
declare namespace gea.abstracts.ui {
    abstract class PanelBase extends gea.adapters.abstracts.ui.UIBase {
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        /**默认配置信息 */
        static get uiType(): gea.enums.ui.ui_type;
    }
}
declare namespace gea.events {
    /** 玩家属性变化通知事件 */
    enum userInfo {
        /** 单独监听经验改变
         *  @deprecated 统一使用 level_exp_change
        */
        exp_change = "gea.events.userInfo.exp_change",
        /** 单独监听等级改变
         *  @deprecated 统一使用 level_exp_change
        */
        level_change = "gea.events.userInfo.level_change",
        /** 等级经验改变  */
        level_exp_change = "gea.events.userInfo.level_change",
        /** 金钱改变 */
        money_change = "gea.events.userInfo.money_change",
        /** 钻石改变 */
        diamond_change = "gea.events.userInfo.diamond_change",
        /** 名字改变 */
        nick_change = "gea.events.userInfo.nick_change",
        /** 头像avatar改变 */
        avatar_change = "gea.events.userInfo.avatar_change",
        /** 头像框avatar改变 */
        avatarBox_change = "gea.events.userInfo.avatarBox_change"
    }
    /** 子游戏相关事件 */
    enum subGame {
        /**返回游戏列表 */
        game_list_info = "gea.events.subGame.game_list_info",
        /** 请求进入游戏大厅 */
        request_enter_hall = "gea.events.subGame.request_enter_hall",
        /** 返回进入游戏大厅 完成 */
        enter_hall_complete = "gea.events.subGame.enter_hall_complete",
        /** 开始进入子游戏, 子游戏管理器加载了子游戏入口的prefab并实例化添加到游戏图层 */
        begin_enter_sub_game = "gea.events.subGame.begin_enter_sub_game",
        /** 进入子游戏 完成  -- 子游戏那边入口初始化进入完成抛出通知 */
        enter_sub_game_comolete = "gea.events.subGame.enter_sub_game_comolete",
        /** 关闭过度切换界面 -- 关闭后子游戏加载界面才能关闭，否则会出现看不到子游戏加载界面的情况 */
        hide_change_enter_panel = "gea.events.subGame.hide_change_enter_panel",
        /** 重新显示html logo页面 目前用于h5二次大厅跳转子游戏 */
        re_show_html_game_logo = "gea.events.subGame.re_show_html_game_logo",
        /** 开始准备退出子游戏 用于发出通知 */
        begin_exit_sub_game = "gea.events.subGame.begin_exit_sub_game",
        /** 某个子游戏退出清理完成 通知 */
        exit_sub_game_comolete = "gea.events.subGame.exit_sub_game_comolete",
        /** 大厅抛出跨天提醒 */
        notice_cross_day = "gea.events.subGame.notice_cross_day",
        /**下载进度 */
        down_load_progess = "gea.events.subGame.down_load_progess",
        /** 下载完成 */
        down_load_complete = "gea.events.subGame.down_load_complete",
        /** 下载失败 */
        down_load_failed = "gea.events.subGame.down_load_failed",
        /** 网页版加载失败 */
        load_game_failed = "gea.events.subGame.load_game_failed",
        /** 通用底部界面 rule按钮点击  */
        common_rule_click = "gea.events.subGame.common_rule_click",
        /** 通用底部界面 history按钮点击  */
        common_history_click = "gea.events.subGame.common_history_click",
        /** @deprecated */
        /** 通用底部界面 paytable按钮点击  */
        common_paytable_click = "gea.events.subGame.common_paytable_click",
        /** 通用底部界面 close按钮点击  */
        common_close_click = "gea.events.subGame.common_close_click",
        /** 横版 通用底部界面 sound按钮点击  */
        common_sound_click = "gea.events.subGame.common_sound_click",
        /** 横版 通用底部界面 speed按钮点击 */
        common_speed_click = "gea.events.subGame.common_speed_click",
        /** 横版 通用底部界面 spin按钮点击*/
        common_spin_click = "gea.events.subGame.common_spin_click",
        /** 横版 通用底部界面 spin按钮点击*/
        common_spin_long_click = "gea.events.subGame.common_spin_long_click",
        /** 横版 通用底部界面 stop按钮点击 */
        common_stop_click = "gea.events.subGame.common_stop_click",
        /** 横版 通用底部界面 stop按钮开关 */
        common_stop_active = "gea.events.subGame.common_stop_active",
        /** 横版 通用底部界面 下注额变更 */
        common_bet_change = "gea.events.subGame.common_bet_change",
        /** 横版 通用底部界面 奖励统计 */
        common_update_total_win = "gea.events.subGame.common_update_total_win",
        /** 横版 通用底部界面 投注变更 */
        common_update_total_bet = "gea.events.subGame.common_update_total_bet",
        /** 横版 通用底部界面 免费状态 */
        common_update_free_spin = "gea.events.subGame.common_update_free_spin",
        /** 横版 通用底部界面 盈利描述 */
        common_update_desc_label = "gea.events.subGame.common_update_desc_label",
        /** 通用竖版bet AUTO 按钮点击 */
        common_auto_click = "gea.events.subGame.common_auto_click",
        /** 通用竖版bet 极速 按钮点击 */
        common_turbo_click = "gea.events.subGame.common_turbo_click",
        /** 通用竖版bet 减少 按钮点击 */
        common_bet_mul_click = "gea.events.subGame.common_bet_mul_click",
        /** 通用竖版bet 增加 按钮点击 */
        common_bet_add_click = "gea.events.subGame.common_bet_add_click",
        /** 通用竖版bet  停止自动 */
        common_stop_auto = "gea.events.subGame.common_stop_auto",
        /** 声音设置改变，通知 */
        common_sound_update = "gea.events.subGame.common_sound_update",
        /** 游戏当前状态通知
         *  STOP = "stop",
            NORMAL = "normal",
            START = "start"
          */
        common_game_status_update = "gea.events.subGame.common_game_status_update",
        /** 子游戏通知 显示货币增加
         *  子游戏获得货币需要延迟显示，所以获得的时候先存起来，但是总额上扣除不显示，
         *  由子游戏通知增加  可传具体数字分步增加，也可传0全部增加
         *  gea.game.myUserInfo.gameAddMoeny  可拿到当前获得但是未在总量中显示的筹码数
         */
        game_update_add_moeny = "gea.events.subGame.game_update_add_moeny",
        /** 子游戏通知 显示货币增加 - 根据传入类   带参数  释放货币数量  对应变更类型(类型来自 pb.ChangeMoneyLogId.Id)
         *  子游戏获得货币需要延迟显示，所以获得的时候先存起来，但是总额上扣除不显示，
         *  由子游戏通知增加  可传具体数字分步增加，也可传0全部增加
         *  gea.game.myUserInfo.gameAddMoeny  可拿到当前获得但是未在总量中显示的筹码数
         */
        game_update_add_moeny_LOG = "gea.events.subGame.game_update_add_moeny_LOG",
        /** 请求打开商店  携带参数    类型（0 1 2）,商品ID */
        request_open_shop = "gea.events.subGame.request_open_shop",
        /** 请求某个游戏最新jackpot值列表 */
        request_game_jackpot = "gea.events.subGame.request_game_jackpot",
        /** 抛出jackpot更新事件 */
        update_game_jackpot = "gea.events.subGame.update_game_jackpot",
        /** 通知子游戏加载界面关闭 */
        notice_preloading_close = "gea.events.subGame.notice_preloading_close",
        /** 通知 子游戏切换横竖屏  1 竖屏  2 横屏  */
        notice_change_rotate = "gea.events.subGame.notice_change_rotate",
        /** 通知 子游戏进入免费模式界面 免费次数提示界面关闭时候抛出 */
        notice_game_enter_free_spin = "gea.events.subGame.notice_game_enter_free_spin",
        /** 通知 子游戏进入从免费模式回到普通模式， 带上免费总赢钱数  免费totalwin 弹窗关闭时候弹出 */
        notice_game_form_free_to_normal = "gea.events.subGame.notice_game_form_free_to_normal",
        /** 通知 子游戏 bigwin界面关闭 时抛出 */
        notice_game_big_win_close = "gea.events.subGame.notice_game_big_win_close",
        /** 请求 顶部栏 禁止或者恢复 设置界面的打开按钮可用状态  1 禁用  0 恢复  */
        request_lock_release_setting = "gea.events.subGame.request_lockOrRelease_setting",
        /** 子游戏请求摇奖，由大厅统一处理发送协议  */
        request_slot_draw = "gea.events.subGame.request_slot_draw",
        /** 请求子游戏历史记录请求
        *  @deprecated
        */
        request_slot_history = "gea.events.subGame.request_slot_history",
        /** HTTP方式请求子游戏历史记录请求，由大厅统一处理发送协议 带参
         *  startTime: number, endTime: number, page: number, endCallback: (info: any, err, postData) => void
        */
        request_http_slot_history = "gea.events.subGame.request_http_slot_history",
        /** HTTP 方式返回子游戏历史记录请求内容 */
        update_http_slot_history = "gea.events.subGame.update_http_slot_history",
        /** 其他模块子游戏  调用打开大厅功能模块的某些界面，目前是用于h5二次大厅加载显示锦标赛的部分界面
         *  因为竞标赛模块没有一个初始界面的加载来承载它的数据也没有可以显示加载界面的地方，所以需要特殊处理
         *  { bundle: string, uiNames?: string, uiClass?: gea.interfaces.ui.IUIClass, uiParent?: cc.Node, uiPos?: cc.Vec2,uiSize?:cc.size, preLoadPos?: cc.Vec2 }
         */
        open_sub_panel = "gea.events.subGame.open_sub_panel"
    }
}
declare namespace gea.abstracts.ui {
    abstract class PreLoadingBase extends gea.adapters.abstracts.ui.UIBase {
        /** 不可被hideAll 关闭，只能单独指定关闭 */
        static get excludeHideAll(): boolean;
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        static get uiType(): gea.enums.ui.ui_type;
        static get customTweenHide(): any;
        static lastPreLoadingPane: any;
        progressTxt: cc.Label;
        background: cc.Node;
        loadingTxt: cc.Label;
        progressBar: cc.ProgressBar;
        versionTxt: cc.Label;
        /** 每项加载失败重试次数 */
        fialeRetryCount: number;
        progressStrs: string[];
        progressFailStrs: string[];
        progressPer: number[];
        progressTotalPer: number[];
        completeStrs: string[];
        progressGap: number;
        curType: number;
        nextUpdateTime: number;
        onShowTime: number;
        curProgress: number;
        curFailCount: number;
        curProgressStrs: string[];
        completeIndex: number;
        closeGapTime: number;
        closePreGap: number;
        /** 预加载文件夹下标 */
        loadDirIndex: number;
        slotInited: boolean;
        retryFunMap: Map<gea.enums.GameLoadingType, Function>;
        isCallbackAfterShow: boolean;
        /**加载界面上显示的多语言图 要优先加载显示 */
        isLoadLanguageComplete: boolean;
        /** 是否需要恢复整体 */
        isNeedResetMute: boolean;
        isNeedResetMuteSound: boolean;
        isNeedResetMuteBgMusic: boolean;
        /** 设定最长加载时间 */
        maxPreloadingTime: number;
        isDoloadSuccess: boolean;
        /** 是否已经关闭了大厅相关 */
        isHallUIISClose: boolean;
        /** 子游戏初始化成功事件名 */
        get slot_init_event(): string;
        /** 子游戏初始化失败事件名 */
        get slot_init_failed(): string;
        /** gameid */
        get gameId(): number;
        /** 配置类 */
        get ExlLoader(): any;
        /** 配置 loading类 */
        get ExlloadingProvider(): any;
        /** 配置多语言类 */
        get ExllangTableProvider(): any;
        /** 配置音效类 */
        get ExlaudioProvider(): any;
        /** 主预加载文件，必须预加载的内容 */
        get mainPreloadList(): any;
        get slientLoadList(): {
            url: string;
            type: typeof cc.Asset;
        }[];
        /** 预加载文件列表，超过N秒未加载完成将不再等待 */
        get preloadList(): any;
        /** 预加载文件夹列表 */
        get preloadDirList(): any;
        /** 加载完成后需要打开的主界面 */
        get mainPanel(): gea.interfaces.ui.IUIClass;
        /** 协议枚举类 */
        get PBEnums(): any;
        /** 当前 loading界面 */
        get PreLoadingPane(): any;
        /**初始化游戏协议请求 */
        initSlotReq(): void;
        constructor();
        /** 关闭界面 */
        doClose(): void;
        /** 添加内容 到底部区域  自适应  返回底部node*/
        addToBottomCompent(nodeList: cc.Node[]): cc.Node;
        initNetMapping(): void;
        doLoadingFail(): void;
        needResetLangAssets: cc.Node[];
        start(): void;
        update(dt: number): void;
        callbackBeforeShow(...args: any[]): void;
        callbackAfterShow(...args: any[]): void;
        callbackBeforeHide(): void;
        callbackAfterHide(): void;
        doNoticeShowComplete(): void;
        onTimeUpdateProgress(): void;
        updateLoading(progress: number, type: number): void;
        updateProgress(): void;
        onLoading(): void;
        /**
         * 加载配置信息
         * */
        loadConfig(): void;
        /**
         * 预加载
         */
        loadUI(): void;
        doLoadPreloadList(): void;
        doPreloadEnd(): void;
        loadSuccess(): void;
        tranStringTxt(keyName: string, sp: cc.Node, ...args: any[]): void;
        /** 游戏服务器初始化完成 */
        onSlotInit(): void;
        /** 游戏服务器初始化失败 */
        onSlotInitFailed(): void;
        onSlotInitRes(res: any): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UIAnimationClip extends gea.adapters.abstracts.ui.UIExtendBase {
        playOnLoad: boolean;
        updatePreview(): void;
        private _clipUrl;
        get clipUrl(): string;
        set clipUrl(value: string);
        private _animation;
        get animation(): cc.Animation;
        start(): void;
        onLoadComplete(animation: cc.Animation): void;
        loadAsset(): void;
        resetInEditor(): void;
        resChange(): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UIBigSprite extends gea.adapters.abstracts.ui.UIExtendBase {
        private _spriteUrl;
        get spriteUrl(): string;
        set spriteUrl(value: string);
        private _sprite;
        get sprite(): cc.Sprite;
        private _type;
        get type(): cc.Sprite.Type;
        set type(value: cc.Sprite.Type);
        private _sizeMode;
        get sizeMode(): cc.Sprite.SizeMode;
        set sizeMode(value: cc.Sprite.SizeMode);
        private _trim;
        get trim(): boolean;
        set trim(value: boolean);
        updatePreview(): void;
        _width: number;
        _height: number;
        start(): void;
        onSpineLoadComplete(spine: cc.Sprite): void;
        loadSprite(): void;
        resetInEditor(): void;
        spriteChange(): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UILoopRotation extends cc.Component implements gea.interfaces.ui.IUI {
        speed: number;
        update(dt: any): void;
        stop(): void;
        callbackBeforeHide(...args: any[]): void;
        callbackAfterHide(...args: any[]): void;
        get customTweenShow(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        get customTweenHide(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        /**
          * 添加到舞台前的回调/UI已经在显示中,再次调用show,也会回调
          * @param args
          */
        callbackBeforeShow(...args: any[]): void;
        /**
         * 添加到舞台后的回调//UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackAfterShow(...args: any[]): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UIHistoryListComponent extends gea.adapters.abstracts.ui.UIBase {
        empty: cc.Node;
        item: cc.Prefab;
        scrollView: cc.ScrollView;
        content: cc.Node;
        get dataInfo(): any;
        slot_history_event: string;
        readonly Res_SlotHistory: string;
        _commentName: string;
        get commentName(): string;
        start(): void;
        onScrollEndedHandler(evet: any, eventType: number): void;
        slotListMap: Map<string, []>;
        historyInfoMap: Map<string, any>;
        curReqRecordLen: number;
        needNextReqPage: number;
        needCheckNextData: any;
        /** 预处理数据 */
        SlotHistoryRes(data: any, req: number): void;
        get itemPool(): cc.NodePool;
        _itemList: any[];
        /** 当前需要显示的数量 */
        _endShowIndex: number;
        /** 当前已经显示的数量 */
        _starShowIndex: number;
        _itemMap: {};
        _scrollViewCollisonBox: cc.Rect;
        curPage: number;
        maxPage: number;
        pageCount: number;
        isUpdateIng: boolean;
        itemHeight: number;
        offsetX: number;
        onSlotHistory(): void;
        lateUpdate(dt: any): void;
        getCurPage(): number;
        checkVisible(listItem: cc.Node): boolean;
        getShopItemNode(index: number): cc.Node;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UIHistoryListHttpComponent extends gea.adapters.abstracts.ui.UIBase {
        empty: cc.Node;
        item: cc.Prefab;
        scrollView: cc.ScrollView;
        content: cc.Node;
        get dataInfo(): any;
        slot_history_event: string;
        _commentName: string;
        get commentName(): string;
        start(): void;
        onScrollEndedHandler(evet: any, eventType: number): void;
        curReqRecordLen: number;
        needNextReqPage: number;
        needCheckNextData: any;
        /** 预处理数据 */
        SlotHistoryRes(data: any): void;
        get itemPool(): cc.NodePool;
        _itemList: any[];
        /** 当前需要显示的数量 */
        _endShowIndex: number;
        /** 当前已经显示的数量 */
        _starShowIndex: number;
        _itemMap: {};
        _scrollViewCollisonBox: cc.Rect;
        curPage: number;
        maxPage: number;
        pageCount: number;
        isUpdateIng: boolean;
        itemHeight: number;
        offsetX: number;
        onSlotHistory(): void;
        lateUpdate(dt: any): void;
        getCurPage(): number;
        checkVisible(listItem: cc.Node): boolean;
        getShopItemNode(index: number): cc.Node;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UILandBetComponent extends gea.adapters.abstracts.ui.UIBase {
        betContent: cc.Node;
        chipContent: cc.Node;
        totalWinContent: cc.Node;
        maxBetBtn: cc.Node;
        turboBtn: cc.Node;
        autoBtn: cc.Node;
        startBtn: cc.Node;
        autoContent: cc.Node;
        freeContent: cc.Node;
        h5MoreMenu: cc.Node;
        get dataInfo(): any;
        START_STATE: {
            STOP: string;
            NORMAL: string;
            START: string;
        };
        betJumlah: number;
        jumlahList: number[];
        jumlahIdx: number;
        /** 是否需要有自动次数选择和显示 */
        private _needAutoSelect;
        get needAutoSelect(): boolean;
        set needAutoSelect(value: boolean);
        /** 自动次数 */
        autoCount: number;
        LOCAL_ISTURBO: string;
        /** start 按钮点击动画 动画名 */
        clickAni: string;
        /** start 按钮鼠标悬停动画 动画名 */
        onTouchAni: string;
        /** start 按钮状态 */
        roundState: string;
        normalSpeed: number;
        startSpeed: number;
        maskColor: cc.Color;
        h5MoreMenuCont: cc.Node;
        h5MoreBtn: cc.Node;
        turboOn: cc.Node;
        turboOff: cc.Node;
        addBtn: cc.Node;
        subBtn: cc.Node;
        autoOn: cc.Node;
        autoOff: cc.Node;
        soundOn: cc.Node;
        soundOff: cc.Node;
        /** 最大下注按钮的不可用遮罩 默认自动根据最大投注按钮的图层自动创建
         *  如果特殊游戏自己设置，请在 initView 之前设置
         */
        maxBetMask: cc.Node;
        /** 投注显示块的不可用遮罩 默认自动根据下注块的图层自动创建
         *  如果特殊游戏自己设置，请在 initView 之前设置
        */
        betContentMask: cc.Node;
        h5MoreBtnMask: cc.Node;
        turboBtnMask: cc.Node;
        autoBtnMask: cc.Node;
        addBtnMask: cc.Node;
        subBtnMask: cc.Node;
        private _isTurbo;
        CLICK_TIME: number;
        /** 是否自动 */
        get isAuto(): boolean;
        /** 是否极速 */
        get isTurbo(): boolean;
        set isTurbo(value: boolean);
        _commentName: string;
        get commentName(): string;
        betLabel: cc.Label;
        totalWinLabel: cc.Label;
        chipLabel: cc.Label;
        freeNumTxt: cc.Label;
        autoNumTxt: cc.Label;
        /** 底部需要根据是否免费模式改变状态的按钮列表 */
        downBtnList: cc.Button[];
        spinRotation: UILoopRotation;
        spinGrey: cc.Node;
        /** 点击spine */
        spinClickEffect: sp.Skeleton;
        /** 鼠标悬停spine */
        spinTouchEffect: sp.Skeleton;
        needStatusBtns: cc.Button[];
        /** 投注额加减按钮不需要默认禁用状态图 */
        addSubBtnNotNeedMask: boolean;
        start(): void;
        initView(): void;
        /**
         *  添加默认spin按钮动画
         */
        addDefaultSpinEff(bundle?: string, clickSpinUrl?: string, touchSpinUrl?: string): void;
        addLimitMaskNode(maskNode: cc.Node, parentSprite: cc.Sprite, zIndex: number): void;
        /** H5检查 */
        checkH5(): void;
        addButtonClickEvent(btnNode: cc.Node, handler: string): void;
        findLabelInCont(cont: cc.Node): cc.Label;
        /** 普通摇奖返回- 处理自动次数 */
        SlotDrawRes(data: any): void;
        subGameAutoCountSelect(num: number): void;
        updateAutoNumTxt(): void;
        /**筹码变化 */
        onMoneyChange(money?: any, opt?: any): void;
        /** 更新筹码显示 */
        initChip(chip?: number): void;
        updateBetJumlah(): void;
        /** 加减筹码显示 */
        setChip(chip: number): void;
        /** 最近一次totalwin */
        totalWin: number;
        /** 显示totalwin  如果有其他效果显示，复写该方法 */
        onShowTotalWin(win: number, totalWin: number): void;
        onShowFreeNum(num: number): void;
        changeDownButtonStatus(): void;
        /** 增加锁定按钮不可点击的时间 毫秒 */
        addLockBttonTime(time: number): void;
        /**转动按钮状态 */
        betStartIconState(state: string): void;
        /** 显示点击效果 */
        showSpineClickEffect(): void;
        /** 显示鼠标悬停效果 */
        showSpinTouchEffect(flag: boolean): void;
        /** 刷新 + -  投注额按钮状态 */
        refreshBetAddMulBtn(jumlahIdx: number, jumlahList: any[]): void;
        /** 投注额改变 */
        onBetJumlahChange(jumlahIdx: number, jumlahList: any[]): void;
        /** 更新自动按钮状态 */
        updateAutoStatus(isAuto: boolean): void;
        /** 更新极速按钮状态 */
        updateTurboStatus(isTurbo: boolean): void;
        /** 是否可以点击 */
        checkCanClick(): boolean;
        private onMouseEnter;
        /** 鼠标进入悬停 */
        onDoMouseEnter(): void;
        private onMouseLeave;
        /** 鼠标离开 */
        onDoMouseLevel(): void;
        /** 投注额框点击*/
        onBetContentClick(): void;
        /** + 按钮点击 */
        onBetAddClick(): void;
        /** - 按钮点击 */
        onBetMulClick(): void;
        /** 极速按钮点击 */
        onTurboClickHandler(): void;
        /** 自动按钮点击 */
        onAutoClickHandler(): void;
        /** 最大下注按钮 */
        onBetMaxClickHandler(): void;
        onHideH5MoreClick(): void;
        onH5MoreClickHandler(): void;
        onSoundClickHandler(): void;
        onQuitClickHandler(): void;
        onHistoryClickHandler(): void;
        onRuleClickHandler(): void;
        /** start 按钮 点击 */
        onStartSpinClick(): void;
        callbackBeforeHide(...args: any[]): void;
        callbackAfterHide(...args: any[]): void;
        get customTweenShow(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        get customTweenHide(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        /**
          * 添加到舞台前的回调/UI已经在显示中,再次调用show,也会回调
          * @param args
          */
        callbackBeforeShow(...args: any[]): void;
        /**
         * 添加到舞台后的回调//UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackAfterShow(...args: any[]): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UIMoneyRunout extends cc.Component implements gea.interfaces.ui.IUI {
        timeout: number;
        preStr: string;
        endStr: string;
        isNoMoneySign: boolean;
        label: cc.Label;
        curMoney: number;
        oldMoney: number;
        deltaTime: number;
        frame: number;
        /** 记录最大字符数，小于时补位，避免出现数字滚动的时候 时长时短的问题 */
        maxLen: number;
        endCallBack: Function;
        onLoad(): void;
        stop(): void;
        reset(): void;
        setMoney(money: number, time?: number, preStr?: string, endStr?: string): void;
        update(dt: number): void;
        updateLabel(money: number): void;
        callbackBeforeHide(...args: any[]): void;
        callbackAfterHide(...args: any[]): void;
        get customTweenShow(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        get customTweenHide(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        /**
          * 添加到舞台前的回调/UI已经在显示中,再次调用show,也会回调
          * @param args
          */
        callbackBeforeShow(...args: any[]): void;
        /**
         * 添加到舞台后的回调//UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackAfterShow(...args: any[]): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UIPrefab extends gea.adapters.abstracts.ui.UIExtendBase {
        updatePreview(): void;
        private _prefabUrl;
        get prefabUrl(): string;
        set prefabUrl(value: string);
        start(): void;
        onLoadComplete(node: cc.Node): void;
        loadAsset(): void;
        resetInEditor(): void;
        resChange(): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UIRewardNotice extends cc.Component implements gea.interfaces.ui.IUI {
        win: cc.Node;
        totalWin: cc.Node;
        winLayout: cc.Node;
        winLabel: cc.Label;
        noticeLable: cc.Label;
        winLabelRut: UIMoneyRunout;
        _noticeWidth: number;
        /** 跑马灯文本和遮罩的左右间隔 */
        gap: number;
        totlalWin: number;
        moneyAudioId: number;
        _betJumlah: number;
        tween: cc.Tween;
        private _gameId;
        get gameId(): number;
        set gameId(value: number);
        get noticeWidth(): number;
        start(): void;
        initView(): void;
        /** 设置跑马灯区域尺寸 默认  900*57 */
        changeNoticeContent(width: number, height?: number, gap?: number): UIRewardNotice;
        /** 获取当前投注额  */
        getBetJumlah(): number;
        /** totalwin 数字滚动结束 */
        runoutEnd(): void;
        /** 播放 totalwin 数字滚动音效 */
        playWinMoneySound(): void;
        /** 显示win, 单轮游戏win需要判断显示滚动数字 传入 true */
        showReward(win: number, needCheckRul?: boolean): void;
        /** 显示totalwin */
        showTotalReward(win: number, isBigWin?: boolean): void;
        /** 显示 totalwin/ win 时播放动画效果
         * type  0 bigwin  1 赢得5倍以上下注额 2 其他中奖
        */
        playEffect(type: number): void;
        /**
         * 隐藏 获奖提示，显示跑马灯内容
         */
        setNoticeActive(): void;
        /** 显示跑马灯 */
        showNotice(msg?: string): void;
        /** 跑马灯滚动 */
        doNoticeLableTween(): void;
        /** 强制切换跑马灯文本 如果显示win或者totalwin中，则无效 */
        onNoticeEvent(msg: any): void;
        /** 免费结束回到普通页面 */
        onGameFromFreeToNormal(freeSpinsAmount: number): void;
        /** 获取投注额 */
        onSlotDrawRes(res: any, seq: any): void;
        callbackBeforeHide(...args: any[]): void;
        callbackAfterHide(...args: any[]): void;
        get customTweenShow(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        get customTweenHide(): gea.interfaces.tween.ITweener | Array<gea.interfaces.tween.ITweener> | undefined;
        /**
          * 添加到舞台前的回调/UI已经在显示中,再次调用show,也会回调
          * @param args
          */
        callbackBeforeShow(...args: any[]): void;
        /**
         * 添加到舞台后的回调//UI已经在显示中,再次调用show,也会回调
         * @param args
         */
        callbackAfterShow(...args: any[]): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UISpine extends gea.adapters.abstracts.ui.UIExtendBase {
        aniName: string;
        isLoop: boolean;
        updatePreview(): void;
        private _spineUrl;
        get spineUrl(): string;
        set spineUrl(value: string);
        private _spine;
        get spine(): sp.Skeleton;
        start(): void;
        onSpineLoadComplete(spine: sp.Skeleton): void;
        loadSpine(): void;
        resetInEditor(): void;
        spineChange(): void;
    }
}
declare namespace gea.abstracts.ui {
    abstract class UnderModalBase extends gea.adapters.abstracts.ui.UIBase {
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        static get uiType(): gea.enums.ui.ui_type;
    }
}
declare namespace gea.abstracts.ui {
    abstract class ViewBase extends gea.adapters.abstracts.ui.UIBase {
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        static get uiType(): gea.enums.ui.ui_type;
    }
}
declare namespace gea.abstracts.ui {
    abstract class WindowBase extends gea.adapters.abstracts.ui.UIBase {
        /**默认配置信息 */
        protected static DEFAULT_SETUP: {
            modal?: boolean;
        };
        static get uiType(): gea.enums.ui.ui_type;
    }
}
declare namespace gea.interfaces.ui {
    interface IHallBetComponent {
        node: cc.Node;
        btns: cc.Button[];
        /** 自动次数label */
        autoNumTxt: cc.Label;
        /** 是否需要有自动次数选择和显示 */
        needAutoSelect: boolean;
        LOCAL_ISTURBO: string;
        /** start 按钮状态
         *   export enum START_STATE {
            STOP = "stop",
            NORMAL = "normal",
            START = "start"
            }
         */
        roundState: string;
        /** 正常状态下 start按钮中心图转动速度 */
        normalSpeed: number;
        /** 滚轴转动状态下 start按钮中心图转动速度 */
        startSpeed: number;
        /** start 按钮点击动画 动画名 */
        clickAni: string;
        /** start 按钮鼠标悬停动画 动画名 */
        onTouchAni: string;
        turboOn: cc.Node;
        turboOff: cc.Node;
        addBtnBg: cc.Node;
        subBtnBg: cc.Node;
        autoOn: cc.Node;
        autoOff: cc.Node;
        startBtn: cc.Node;
        spinRotation: any;
        spinGrey: cc.Node;
        /** 点击spine */
        spinClickEffect: sp.Skeleton;
        /** 鼠标悬停spine */
        spinTouchEffect: sp.Skeleton;
        /** 设置start按钮 */
        changeStartBtn(btn: cc.Node, pos?: cc.Vec2): any;
        /** 设置 start 按钮动画资源 */
        changeStartBtnSkeletons(skeletons?: sp.SkeletonData[]): any;
        /** 设置satrt按钮资源 */
        changeStartBtnSprame(spriteFrames: cc.SpriteFrame[]): any;
        /**
         * 设置自动次数显示的背景和次数的字体。 返回 次数的label
         * @param bundle
         * @param bgUrl
         * @param numFontUrl
         * @param bgPos
         * @param numTxtPos
         * @returns
         */
        changeAutoNumSprame(bundle: string, bgUrl?: string, numFontUrl?: string, bgPos?: cc.Vec2, numTxtPos?: cc.Vec2): cc.Label;
        /**转动按钮状态 */
        betStartIconState(state: string): any;
        /** 显示点击效果 */
        showSpineClickEffect(): any;
        /** 显示鼠标悬停效果 */
        showSpinTouchEffect(flag: boolean): any;
        /** 刷新 + -  投注额按钮状态 */
        refreshBetAddMulBtn(jumlahIdx: number, jumlahList: any[]): any;
        /** 更新自动按钮状态 */
        updateAutoStatus(isAuto: boolean): any;
        /** 更新极速按钮状态 */
        updateTurboStatus(isTurbo: boolean): any;
        /** 鼠标进入悬停 */
        onDoMouseEnter(): any;
        /** 鼠标离开 */
        onDoMouseLevel(): any;
        /** 自动 点击*/
        onAutoClick(): any;
        /** 极速 点击*/
        onTurboClick(): any;
        /** 投注额 减 点击*/
        onBetMulClick(): any;
        /** 投注额 加 点击*/
        onBetAddClick(): any;
        /** start 按钮 点击 */
        onStartSpinClick(): any;
    }
}
declare namespace gea.interfaces.ui {
    interface IHallBottomBarPanel {
        node: cc.Node;
        soundBtnBg: cc.Node;
        soundBtnOff: cc.Node;
        btnImgList: cc.Sprite[];
        btnLabelList: cc.Label[];
        /** 设置底部栏按钮颜色 */
        setBottomColor(color: cc.Color, labelOpacity?: number): any;
        onSoundClick(): any;
        onQuitBtn(): any;
        onHistoryClick(): any;
        onRuleClick(): any;
        onCloseClick(): any;
    }
}
declare namespace gea.interfaces.ui {
    interface IHallBottomPanel {
        node: cc.Node;
        betLabel: cc.Label;
        historyLabel: any;
        moneyLabel: any;
        betLayout: cc.Node;
        betPage1: cc.Node;
        betPage2: cc.Node;
        betComp: IHallBetComponent;
        botBarComp: IHallBottomBarPanel;
        moneyLayout: cc.Node;
        menu: cc.Node;
        pageBtn1: cc.Node;
        pageBtn2: cc.Node;
        menuOpen: boolean;
        clickTime: number;
        betJumlah: number;
        jumlahList: number[];
        jumlahIdx: number;
        roundState: string;
        /** 是否自动 */
        isAuto: boolean;
        /** 是否极速 */
        isTurbo: boolean;
        /** 刷新货币layout */
        updateMoneyLayout(): any;
        /** 更改menu按钮， 传入自定义的两个按钮node */
        changeMenuBtn(btn1: cc.Node, btn2: cc.Node): cc.Node;
        /** 更改menu按钮   传入按钮url ,
         * urlBg 为menu底图,传入null 则不需要底图，清除底图  传入 带有res的图片链接，则加载对应的资源， 传入其他字符串则使用默认自带底图
         * */
        changeMenuBtnUrl(url1: string, url2: string, urlBg: string, bundle: string): cc.Node;
        /** 更换货币界面排布参数 */
        changeMoneyLayout(opt: {
            paddingRightH5?: number;
            paddingRight?: number;
            paddingLeft?: number;
            paddingLeftH5?: number;
            spacingXH5?: number;
            spacingX?: number;
        }): cc.Layout;
        /** 更换货币背景 url 传入null 说明不需要背景，去掉货币背景框，由子游戏自己去定义 */
        changeMoneyItemBg(url: string, bundle: string): cc.Node[];
        /** 更换货币栏icon */
        changeMoneyIcon(url1?: string, url2?: string, url3?: string, bundle?: string): cc.Node[];
        /** 底部控制栏显示旋转按钮- 用于可切换方向的游戏 */
        showRotateBtn(spacingX?: number, force?: boolean): any;
        /** 更新自身筹码数量 */
        updateMoney(newNum?: number): any;
        /** 更新 totalwin 数量 */
        onShowTotalWin(win: any): any;
        /**刷新金币列表 */
        onShowMoney(): any;
        /** 刷新 + -  投注额按钮状态 */
        refreshBetAddMulBtn(): any;
        /** 显示隐藏 操作栏 目前用于免费游戏隐藏 功能按钮和start按钮 */
        setBetLayoutActive(flag: boolean): any;
        /** 投注额改变 */
        onBetJumlahChange(): any;
        /** menu 按钮点击 */
        onMenuClick(): any;
        /** 投注额框点击*/
        onBetClick(): any;
        /** + 按钮点击 */
        onBetAddClick(): any;
        /** - 按钮点击 */
        onBetMulClick(): any;
        /** 极速按钮点击 */
        onTurboClick(): any;
        /** 自动按钮点击 */
        onAutoClick(): any;
        /** 关闭按钮点击 */
        onCloseClick(): any;
    }
}
declare namespace gea.interfaces.ui {
    interface IHallRewardNoticePanel {
        node: cc.Node;
        win: cc.Node;
        totalWin: cc.Node;
        winLayout: cc.Node;
        winLabel: any;
        noticeLable: cc.Label;
        noticeWidth: number;
        /** 跑马灯文本和遮罩的左右间隔 */
        gap: number;
        totlalWin: number;
        moneyAudioId: number;
        gameId: number;
        dataInfo: any;
        /** 设置跑马灯区域尺寸 默认  900*57 */
        changeNoticeContent(width: number, height?: number, gap?: number): IHallRewardNoticePanel;
        /** totalwin 数字滚动结束 */
        runoutEnd(): any;
        /** 播放 totalwin 数字滚动音效 */
        playWinMoneySound(): any;
        /** 显示win */
        showReward(win: number): any;
        /** 显示totalwin */
        showTotalReward(win: number, isBigWin: boolean): any;
        /** 显示 totalwin/ win 时播放动画效果
         * type  0 bigwin  1 赢得5倍以上下注额 2 其他中奖
        */
        playEffect(type: number): any;
        /**
         * 隐藏 获奖提示，显示跑马灯内容
         */
        setNoticeActive(): any;
        /** 显示跑马灯 */
        showNotice(msg?: string): any;
        /** 强制切换跑马灯文本 如果显示win或者totalwin中，则无效 */
        onNoticeEvent(msg: any): any;
    }
}
declare namespace hlgame.interfaces.utils {
    interface IComUtil {
        /** 转换科学计算法   'K', 'M', 'B', 'T', 'Q'
         * num: number, bDot: number = 3, fDot: number = 2, strLenMax: number = -1, effectiveMin: number = 100000000
        */
        getUnitedNumStr(num: number, bDot?: number, fDot?: number, strLenMax?: number, effectiveMin?: number, notEndZero?: boolean): string;
        /**
         * 格式化数字  3位添加一个逗号
         * @param num
         * @returns
         */
        formatNumWithComma(num: number, fDot?: number): string;
        /**
         * 转换间隔时间（秒） 用于倒计时 只显示小时内的，不显示天数
         * @param time 注意：传入的是间隔秒数，不是时间戳
         * @param typeStr  格式字符串 默认格式  [hour]:[minutes]:[seconds]
         * 例子  如需要显示  XX天XX时XX分XX秒  typeStr 传入 [hour]时[minutes]分[seconds]秒
         */
        formatGapTimeStr(time: number, typeStr?: string): string;
        /**
         * 转换时间戳（秒）
         * @param timeStamp
         * @param type  1 2023/2/9 23:00 格式 2 2023-2-9 23:00 格式
         * @param endToDay  只显示到天，不显示时分秒
         */
        formatTimeStampStr(timeStamp: number, type?: number, endToDay?: boolean): string;
        /**
         * 截取字符串宽度
         * @param str
         * @param maxWid
         */
        utfSubLen(str: string, maxWid: number): string;
        /**
         * 打乱数组 默认直接打乱原数组，需要创建新数组 copy 请传true
         * @param arr
         * @param copy 是否拷贝新数据，不改原数组
         * @returns
         */
        disorderArray(arr: any[], copy?: boolean): any[];
        /**
         * 立即刷新文本，设置完文本内容后可以马上获取到实际宽搞
         * @param lable
         */
        forceUpdateRenderData(lable: any): any;
        /** 适配宽度 */
        fitLabelWidth(label: cc.Label | cc.RichText, maxWidth: number): any;
        /**
         * 获取随机数
         * @param from
         * @param to
         * @returns
         */
        random(from: number, to: number): number;
        /**
         * 解析检测URL参数
         * @param url
         * @returns
         */
        urlSearchParams(url: string): Map<string, any>;
        /**
          * 一个简单的震屏接口  抖动9次
          * gap 震动幅度  5
          * gapTime 单次抖动时间  0.02
          * action 可以自己传入震动action 列表
          *         cc.moveTo(gapTime, cc.v2(gap, gap + 2)),
                    cc.moveTo(gapTime, cc.v2(-gap - 1, gap + 2)),
                    cc.moveTo(gapTime, cc.v2(-gap - 7, gap - 2)),
                    cc.moveTo(gapTime, cc.v2(gap - 2, -gap - 1)),
                    cc.moveTo(gapTime, cc.v2(-gap, gap)),
                    cc.moveTo(gapTime, cc.v2(gap - 3, -gap + 3)),
                    cc.moveTo(gapTime, cc.v2(-gap - 3, -gap * 2)),
                    cc.moveTo(gapTime, cc.v2(gap - 2, gap * 2)),
                    cc.moveTo(0, cc.v2(0, 0))
          */
        shakeScreen(gap?: number, gapTime?: number, action?: any): any;
        /**
         * 适配等比拉伸全屏，按照传入node的尺寸
         * @param bgNode
         */
        fixFillFull(bgNode: cc.Node): any;
        /**字节数组转字符串 */
        Uint8ArrayToString(fileData: Uint8Array): string;
    }
}
declare namespace hlgame {
    class Config implements interfaces.IConfig {
        private _platform;
        private _game_name;
        private _game_name_eng;
        private _orientation;
        private _url;
        private _h5Url;
        private _game_id;
        private _uid;
        private _bundle;
        private _open_level;
        private _entrance_prefab;
        private _game_icon;
        private _game_h5_icon;
        private _gameIconExtend;
        private _entrance_type;
        /** 版本号 */
        private _version;
        private _oldVersion;
        /** 热度 */
        private _hot;
        private _retain;
        private _extend;
        private _needTopBar;
        private _type_id;
        private _Maximum_win;
        private _Volatility;
        private _RTP;
        private _online;
        private _Label_desc;
        private _type;
        private _hall_type;
        private _tab_type;
        private _tag;
        private _sort;
        private _status;
        private _jackpot;
        private _jackpotValues;
        private _parent;
        private _isLocal;
        private _entranceNode;
        private _isDownLoad;
        private _isUpdate;
        private _downZipTryCount;
        private _isInCache;
        private _isInGame;
        private _isInLoadBundle;
        private _isInLoadGameEntrance;
        private _mainPanel;
        private _slotInitRes;
        get slotInitRes(): any;
        set slotInitRes(value: any);
        get mainPanel(): gea.interfaces.ui.IUIClass;
        set mainPanel(value: gea.interfaces.ui.IUIClass);
        get isInLoadGameEntrance(): boolean;
        set isInLoadGameEntrance(value: boolean);
        get isInLoadBundle(): boolean;
        set isInLoadBundle(value: boolean);
        get isInGame(): boolean;
        set isInGame(value: boolean);
        private _sensor;
        get sensor(): gea.enums.sensor;
        set sensor(value: gea.enums.sensor);
        get downZipTryCount(): number;
        set downZipTryCount(value: number);
        get isUpdate(): boolean;
        set isUpdate(value: boolean);
        get hallType(): gea.enums.hallType;
        set hallType(value: gea.enums.hallType);
        get tabType(): gea.enums.tabType;
        set tabType(value: gea.enums.tabType);
        get tag(): gea.enums.tag;
        set tag(value: gea.enums.tag);
        get sort(): number;
        set sort(value: number);
        get platform(): string;
        set platform(value: string);
        get url(): string;
        set url(value: string);
        get h5Url(): string;
        set h5Url(value: string);
        get gameId(): number;
        get uid(): string;
        get bundle(): string;
        get entrancePrefab(): string;
        set entrancePrefab(value: string);
        get gameIcon(): string;
        get gameH5Icon(): string;
        get isDownLoad(): boolean;
        set isDownLoad(value: boolean);
        get isInCache(): boolean;
        set isInCache(value: boolean);
        set version(value: string);
        get type(): gea.enums.bundle;
        get parent(): any;
        set parent(value: any);
        get version(): string;
        get hot(): number;
        set hot(value: number);
        get extend(): any;
        get retain(): any;
        get entranceNode(): any;
        set entranceNode(layer: any);
        get needTopBar(): number;
        set needTopBar(value: number);
        get gameName(): string;
        get game_name_eng(): string;
        get isLocal(): boolean;
        set isLocal(value: boolean);
        get orientation(): number;
        set orientation(value: number);
        get entranceType(): gea.enums.entranceType;
        set entranceType(value: gea.enums.entranceType);
        get level(): number;
        get gameIconExtend(): string;
        get status(): gea.enums.status;
        set status(value: gea.enums.status);
        get jackpot(): string;
        set jackpot(value: string);
        get jackpotValues(): number[];
        /** 是否视讯游戏 */
        get isVideoGame(): boolean;
        get oldVersion(): string;
        set oldVersion(value: string);
        get Maximum_win(): string;
        get Volatility(): number;
        get RTP(): string;
        get type_id(): number;
        get online(): number;
        get Label_desc(): string;
        reset(): void;
        setup(config: any): void;
        setupLocal(config: {
            platform?: string;
            game_name?: string;
            orientation?: number;
            url?: string;
            isLocal?: boolean;
            entrance_prefab?: string;
            game_icon?: string;
            game_icon_one?: string;
            game_id?: number;
            uid?: string;
            bundle?: string;
            isDownLoad?: boolean;
            isInCache?: boolean;
            isSubGame?: number;
            parent?: any;
            version?: string;
            retain?: number;
            extend?: any;
            entranceNode?: any;
            type?: gea.enums.bundle;
            needTopBar?: number;
            hall_type?: gea.enums.hallType;
            tab_type?: gea.enums.tabType;
            tag?: gea.enums.tag;
            sort?: number;
            entrance_type?: gea.enums.entranceType;
            status?: gea.enums.status;
            hot?: number;
        }): void;
    }
}
declare namespace hlgame {
    function startup(urlParams: any, hallMode: gea.enums.hallMode): void;
    /**
     * 登录App
     * @param net 要登录的网络实例
     */
    function login(net: gea.interfaces.net.IGmeNet): void;
}
declare namespace hlgame.Md5 {
    function hex_md5(s: any): string;
    function b64_md5(s: any): string;
    function str_md5(s: any): string;
    function hex_hmac_md5(key: any, data: any): string;
    function b64_hmac_md5(key: any, data: any): string;
    function str_hmac_md5(key: any, data: any): string;
}
declare namespace gea.common {
    /** 注册用 管理类  使用   gea.game.register 注册使用 */
    abstract class GameMgrPool extends cc.Component implements gea.interfaces.manager.IGameMgrPool {
        callbackAfterBorrow(...args: any[]): void;
        callbackBeforeRestore(): boolean;
        /** 初始化接口方法  子类重写该方法 */
        startup(...args: any[]): void;
        /** 注册的bundle名 */
        bundle: string;
        /** 类名称  设置了类名称会被其他Bundle所获取 */
        className: string;
    }
}
declare namespace gea.interfaces.manager {
    interface IGameMgrPool {
        /**
         * 借用后的回调函数
         * @param args 可选参数
         * @example
         * gea.pool.borrow(poolClass)
         */
        callbackAfterBorrow(...args: any[]): void;
        /**
         * 归还前的回调函数,如果返回true，则表示可以立即还入对象池
         * @param args 可选参数
         * @example
         * gea.pool.restore(poolObject)
         */
        callbackBeforeRestore(...args: any[]): boolean;
        /** 绑定的bundle名 */
        bundle: string;
        /** 类名称  设置了类名称会被其他Bundle所获取 */
        className: string;
    }
}
declare namespace gea.interfaces.manager {
    interface ISubGameCfgManager {
        startUp(): any;
        updateGameListInfo(list: object[]): any;
        getBundleConfig(bundle: string): hlgame.interfaces.IConfig;
        saveSubGameLoadStatus(gameConfig: hlgame.interfaces.IConfig, flag: boolean, version: string): any;
        getAllGameList(): hlgame.interfaces.IConfig[];
        startUpVersion(json: any): any;
        /** 根据bundle获取版本号 */
        getBundlVersion(bundle: string): string;
        /**
         * 添加bundle配置到数据中，这个接口目前用于本地运行开发调试用
         */
        addBundleConfigToMap(cfg: hlgame.interfaces.IConfig): any;
    }
}
declare namespace gea.interfaces.manager {
    interface ISubGameManager {
        subGameCfgMgr: ISubGameCfgManager;
        setup(node: cc.Node): void;
        /**
         * 进入子游戏，
         * 如果未下载过，将会先下载，默认下载后不会直接进入游戏 autoEnter 传入ture 则会自动加载进入游戏
         * 如果已经下载到本地的，直接加载进入游戏
         * @param gameConfig
         * @param autoEnter
         * @returns
         */
        enterSubGame(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): any;
        /** 加载子游戏包*/
        loadSubpackage(gameConfig: hlgame.interfaces.IConfig, autoEnter?: boolean): any;
        /** 清除关闭当前子游戏 */
        clearCurSubGame(): void;
        /** 获取当前打开中的子游戏信息 */
        getCurSubGameInfo(): hlgame.interfaces.IConfig;
        /** 预加载游戏入口预制体 */
        loadGameEntrance(gameConfig: hlgame.interfaces.IConfig, autoEnter: boolean): any;
        /** 设置当前游戏信息  禁用 开放给后台日志项目使用的*/
        setCurSubGameInfo(value: hlgame.interfaces.IConfig): any;
        /**
         * 加载大厅功能子包  功能模块包
         * @param gameConfig
         * @param loadCb
         * @returns
         */
        loadHallSubpackage(gameConfig: hlgame.interfaces.IConfig, loadCb?: Function): boolean;
    }
}
