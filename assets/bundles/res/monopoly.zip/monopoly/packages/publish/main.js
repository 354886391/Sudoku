'use strict';
let config = require('./config').config
let path = require('path');
let fs = require('fs');
const { build } = require('node-xlsx');
// import { test } from '../../tools/publish-project';
let buildResults;
let _totalParse = 0;
let _callback;
let listBundle = []
let result;
const assetsPath = path.join(__dirname, '../../assets');

function parsePorgress() {
    _totalParse--
    if (_totalParse === 0) {
        excuteNextBuildResult()
    }
}

function excuteNextBuildResult() {
    const bundle = listBundle.pop()
    if (bundle) {
        buildResults = bundle.buildResults;
        parseTexture(config.compress.exclude.png, result.compress.exclude.png);
        parseAutoAtlas(config.compress.exclude.autoAlats, result.compress.exclude.autoAlats);
        if (_totalParse === 0) {
            excuteNextBuildResult()
        }
    } else {
        fs.writeFileSync(path.join(__dirname, 'configPublish.json'), JSON.stringify(result, null, '\t'))
        _callback()
    }
}

function onBeforeBuildFinish(options, callback) {
    result = {
        /**图片压缩配置 */
        compress: {
            /**不压缩的资源 */
            exclude: {
                /**不压缩的png */
                png: [],
                /**不压缩的图集  */
                autoAlats: []
            },
        },
    }
    _callback = callback;
    if (options.bundles && options.bundles instanceof Array) {
        listBundle.push(...options.bundles)
    } else {
        listBundle.push(options.buildResults)
    }
    excuteNextBuildResult()
}

function _getTextureFromSpriteFrames(buildResults, assetInfos) {
    let textures = {};
    for (let i = 0; i < assetInfos.length; ++i) {
        let info = assetInfos[i];
        if (buildResults.containsAsset(info.uuid)) {
            let depends = buildResults.getDependencies(info.uuid);
            if (depends.length > 0) {
                // sprite frame should have only one texture
                textures[depends[0]] = true;
            }
        }
    }
    return Object.keys(textures);
}

function parsePrefab(list, listResult) {
    let temp = []
    list.forEach((value) => {
        parsePrefabAll(path.join(assetsPath, value), temp)
    })
    temp.forEach((value) => {
        parsePrefabSingle(listResult, value)
    })
}

function parsePrefabAll(filePath, listDest) {
    if (!fs.existsSync(filePath)) {
        filePath = filePath + '.prefab'
        if (!fs.existsSync(filePath)) {
            Editor.warn(filePath, '不存在')
        } else {
            listDest.push(filePath.split('assets')[1].replace(/^\\/, '').replace(/\\/g, '\/'))
        }
    } else {
        if (fs.statSync(filePath).isDirectory()) {
            fs.readdirSync(filePath).forEach((subPath) => {
                parsePrefabAll(path.join(filePath, subPath), listDest)
            })
        } else if (path.extname(filePath) === '.prefab') {
            listDest.push(filePath.split('assets')[1].replace(/^\\/, '').replace(/\\/g, '\/'))
        }
    }
}

function parsePrefabSingle(list, value) {
    let prefabUrl = 'db://assets/' + value
    let prefabUuid = Editor.assetdb.urlToUuid(prefabUrl);
    if (!buildResults.containsAsset(prefabUuid)) {
        return
    }
    list.push(value)
    var depends = buildResults.getDependencies(prefabUuid);

    for (var i = 0; i < depends.length; ++i) {
        var uuid = depends[i];
        // 获得工程中的资源相对 URL（如果是自动图集生成的图片，由于工程中不存在对应资源，将返回空）
        var url = Editor.assetdb.uuidToUrl(uuid);
        // 获取资源类型
        var type = buildResults.getAssetType(uuid);
        // 获得工程中的资源绝对路径（如果是自动图集生成的图片，同样将返回空）
        var rawPath = Editor.assetdb.uuidToFspath(uuid);
        // 获得构建后的原生资源路径（原生资源有图片、音频等，如果不是原生资源将返回空）
        var nativePath = buildResults.getNativeAssetPath(uuid);
        if (!!nativePath) {
            const key = path.basename(nativePath, path.extname(nativePath))
            // if (list.indexOf(key) == -1) {
            list.push(key)
            // }
        }
        // Editor.log(`depends on: ${rawPath} ---> ${nativePath || 'empty'} (${type})`);
    }
}

function parseTexture(list, listResult) {
    let filePath;
    let dbPath;
    list.forEach((value, index, arr) => {
        // value = 'db://assets/' + value
        filePath = path.join(assetsPath, value);
        if (fs.existsSync(filePath) == false) {
            Editor.error(value, '不存在');
        } else {
            dbPath = 'db://assets/' + value.replace(/\/$/, '');
            if (fs.statSync(filePath).isDirectory()) {
                dbPath += '/**/*';
            }
            _totalParse++
            Editor.assetdb.queryAssets(dbPath, 'texture', (err, assetInfos) => {
                if (err) {
                    Editor.error(err.stack);
                } else {
                    let pushValue = true
                    for (let i = 0; i < assetInfos.length; ++i) {
                        let tex = assetInfos[i].uuid;
                        if (buildResults.containsAsset(tex)) {
                            if (pushValue) {
                                pushValue = false
                                listResult.push(value)
                            }
                            let nativePath = buildResults.getNativeAssetPath(tex);
                            // Editor.log(`Texture of "${assetInfos[i].url}": ${nativePath}`);
                            listResult.push(path.basename(nativePath, '.png'))
                        }
                    }
                }
                parsePorgress()
            });
        }
    });
}

function parseAutoAtlas(list, listResult) {
    let filePath;
    let dbPath;
    list.forEach((value) => {
        filePath = path.join(assetsPath, value);
        if (fs.existsSync(filePath) == false) {
            Editor.error(filePath, '不存在');
        } else {
            if (fs.statSync(filePath).isFile()) {
                Editor.error(value, '图集配置请用文件夹路径，不要指定到具体的文件名');
            } else {
                _totalParse++
                dbPath = 'db://assets/' + value + '/**/*';
                Editor.assetdb.queryAssets(dbPath, 'sprite-frame', (err, assetInfos) => {
                    if (err) {
                        Editor.error(err.stack);
                    } else {
                        let textures = _getTextureFromSpriteFrames(buildResults, assetInfos);
                        let pushValue = true
                        for (let i = 0; i < textures.length; ++i) {
                            if (pushValue) {
                                pushValue = false
                                listResult.push(value)
                            }
                            let nativePath = buildResults.getNativeAssetPath(textures[i]);
                            // Editor.log(`AutoAtlas of ${value}: ${nativePath}, ${textures[i]}`);
                            listResult.push(path.basename(nativePath, '.png'))
                        }
                    }
                    parsePorgress()
                })
            }
        }
    });
}

module.exports = {
    load() {
        Editor.Builder.on('build-finished', onBeforeBuildFinish)
    },
    unload() {
        Editor.Builder.removeListener('build-finished', onBeforeBuildFinish);
    }
}
