"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
var path = require("path");
var projectUtils_1 = require("../utils/projectUtils");
var listContent = [
    '/** generate by parseMessage.py, do not moidfy */',
    'export abstract class PBEnums {',
];
var tab1 = ' '.repeat(4);
var tab2 = ' '.repeat(8);
function generatePBEnums(mapProtoInfo, pbEnumsPath, pbenumName) {
    var listMapping = [];
    var codeListMapping = [];
    var listPath = [];
    var setPakcageName = new Set();

    if (pbenumName){
        listContent[1] = listContent[1].replace("PBEnums", pbenumName)
    }

    // req/res枚举
    var repeatMapping = new Map();
    mapProtoInfo.forEach(function (listProtoInfo, protoFilePath) {
        listContent.push(tab1 + "/** " + path.relative(projectUtils_1._projectRootPath, protoFilePath).replace(/\\/g, '/') + " */");
        listProtoInfo.forEach(function (protoInfo) {
            //子游戏 协议pack名字在生成时强制改成子游戏名称
            protoInfo.packageName = projectUtils_1._subGamePrefix + "pb"
            setPakcageName.add(protoInfo.packageName);
            if (protoInfo.pbEnumName) {
                listContent.push(tab1 + "static readonly " + protoInfo.pbEnumName + ": string = '" + protoInfo.messageName + protoInfo.messageCode + "'");
            }
            if (!repeatMapping.has(protoInfo.messageName)) {
                repeatMapping.set(protoInfo.messageName, true);
                listMapping.push(tab2 + "'" + protoInfo.messageName + protoInfo.messageCode + "': { parser: " + protoInfo.packageName + "." + protoInfo.encoderDcoderName + ", msgCode: " + (protoInfo.messageCode || '0') + " },");
                if (protoInfo.path) {
                    listPath.push(tab2 + "'" + protoInfo.messageName + "': '" + protoInfo.path + "',");
                }
            }
            if (protoInfo.isRes == '1'){
                codeListMapping.push(tab2 + "[" + protoInfo.messageCode + "]: '" + (protoInfo.messageName || '') + protoInfo.messageCode + "',");
                // listMapping.push(tab2 + "[" + protoInfo.messageCode + "]: { parser: " + protoInfo.packageName + "." + protoInfo.encoderDcoderName + ", msgName: '" + (protoInfo.messageName || '') + "' },");
            }
        });
    });
    setPakcageName.forEach(function (value) {
        listContent.splice(1, 0, "import { " + value + " } from './" + value + "'" );
    });
    // Mappiing
    listContent.push.apply(listContent, [tab1 + "// mapping",
        tab1 + "static readonly Mapping = {"].concat(listMapping, [tab1 + "}"]));
    listContent.push.apply(listContent, [tab1 + "// CodeMapping",
        tab1 + "static readonly CodeMapping = {"].concat(codeListMapping, [tab1 + "}"]));
    // Path
    // listContent.push(
    //     `${tab1}// path`,
    //     `${tab1}static readonly Path = {`,
    //     ...listPath,
    //     `${tab1}}`,
    // )
    // end
    listContent.push("}", '');
    fs.writeFileSync(pbEnumsPath, listContent.join('\n'), { encoding: 'utf-8' });
}
exports.generatePBEnums = generatePBEnums;
