"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
var path = require("path");
var consoleUtils_1 = require("../utils/consoleUtils");
var listProto = [];
var mapProtoInfo = new Map();
var setRoom = new Set();
function parseProto(dirProto) {
    if (fs.existsSync(dirProto)) {
        if (fs.statSync(dirProto).isDirectory()) {
            arrangeProtos(dirProto);
            parseNextProto();
            return mapProtoInfo;
        }
        else {
            console.log(consoleUtils_1.formatConsole([dirProto + "\u4E0D\u662F\u4E00\u4E2A\u76EE\u5F55\uFF0C\u8BF7\u4F20\u5165\u76EE\u5F55"]));
        }
    }
    else {
        console.log(consoleUtils_1.formatConsole(["\u627E\u4E0D\u5230\u6587\u4EF6/\u6587\u4EF6\u5939:" + dirProto]));
    }
    return null;
}
exports.parseProto = parseProto;
function arrangeProtos(dirProto) {
    var filePath;
    fs.readdirSync(dirProto).forEach(function (fileName) {
        filePath = path.join(dirProto, fileName);
        if (fs.statSync(filePath).isDirectory()) {
            arrangeProtos(filePath);
        }
        else if (path.extname(filePath) === '.proto') {
            listProto.push(filePath);
        }
    });
}
function parseNextProto() {
    var filePath = listProto.shift();
    if (filePath != null) {
        var listProtoInfo_1 = [];
        mapProtoInfo.set(filePath, listProtoInfo_1);
        var fileContent = fs.readFileSync(filePath, { encoding: 'utf-8' });
        var packageName_1 = fileContent.match(/package [^=]+;/)[0].replace('package', '').replace(';', '').trim();
        if (path.basename(filePath) === 'gateway.proto') {
            listProtoInfo_1.push(
                {
                    messageName: 'Upstream',
                    pbEnumName: '',
                    encoderDcoderName: 'Upstream',
                    packageName: packageName_1,
                }, {
                messageName: 'Downstream',
                pbEnumName: '',
                encoderDcoderName: 'Downstream',
                packageName: packageName_1,
            });
        }
        else {
            // 支持格式: a-z A-Z _ - .
            var messageTitle_1;
            var messageCodeNum;
            var listMatch = fileContent.match(/[0-9]+\s*message [a-z A-Z]+(Res|Req)\s*{[^{]*}/gm);

            listMatch.forEach(function (messageContent, index) {
                let splArr = messageContent.split('message')

                messageCodeNum = Number(splArr[0].replace("\n", ""))
                messageContent = splArr[1]
                // matchResult_1 = matchPath(messageContent);

                messageTitle_1 = messageContent.split('{')[0].replace('message', '').trim();

                listProtoInfo_1.push({
                    messageCode: messageCodeNum,
                    isRes: messageTitle_1.replace(/.*/, function (subString) {
                        if (subString.endsWith('Res')) {
                            return 1;
                        }
                        else {
                            return 0;
                        }
                    }),
                    messageName: packageName_1 + "." + messageTitle_1,
                    pbEnumName: messageTitle_1.replace(/.*/, function (subString) {
                        if (subString.endsWith('Res')) {
                            return 'Res_' + subString.replace(/(Res)$/, '');
                        }
                        else if (subString.endsWith('Req')) {
                            return 'Req_' + subString.replace(/(Req)$/, '');
                        }
                    }),
                    encoderDcoderName: messageTitle_1,
                    packageName: packageName_1,
                });
            });
        }
        parseNextProto();
    }
}
