/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 10:24:42
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2024-04-17 11:25:16
 * @Description: 更新大厅模块代码资源
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
var path = require("path");
var CmdUtils_1 = require("./utils/CmdUtils");
var FileUtils_1 = require("./utils/FileUtils");
var projectUtils_1 = require("./utils/projectUtils");
var tmpDir = path.join(__dirname, '../tmpForUpdate').replace(/\\/g, '/');
function update() {
    FileUtils_1.rmFile(tmpDir);
    CmdUtils_1.cmd("git clone https://192.168.99.100/game/hall-project-creator.git " + tmpDir, function () {
        switch (projectUtils_1._projectType) {
            case 'creator':
                updateCreator();
                break;
            default:
                console.error(projectUtils_1._projectType + ' is undefinded');
                break;
        }
        FileUtils_1.rmFile(tmpDir);
    });
}
function updateCreator() {
    var root = path.join(__dirname, '..');
    FileUtils_1.rmFile(path.join(root, "assets/hall"));
    fs.renameSync(path.join(tmpDir, "assets/hall"), path.join(root, "assets/hall"))

}
if (process.argv[1] === __filename) {
    update();
}
