"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var archiver = require("archiver");
var fs = require("fs");
var path = require("path");
var consoleUtils_1 = require("../utils/consoleUtils");
var projectUtils_1 = require("../utils/projectUtils");
var publish_project_1 = require("./publish-project");
var FileUtils_1 = require("../utils/FileUtils");

function zipPackage(step) {
    consoleUtils_1.printStep(step++, '生成' + projectUtils_1._subGameBundle + '压缩包');
    var output = fs.createWriteStream(path.join(projectUtils_1._projectRootPath, projectUtils_1._subGameBundle+'.zip'));
    var tempDir = path.join(projectUtils_1._projectRootPath, "temp", projectUtils_1._subGameBundle)
    //zip 包删除 js.map文件
    FileUtils_1.rmFile(tempDir)
    FileUtils_1.copyFile(path.join(publish_project_1._pathPublish, 'assets', projectUtils_1._subGameBundle), tempDir)
    FileUtils_1.rmFile(path.join(tempDir, "index.js.map"))
    var archive = archiver('zip', { zlib: { level: 9 } });
    archive.pipe(output);
    archive.directory(tempDir, false);
    archive.finalize();
    output.on('close', function () {
        console.log(path.join(projectUtils_1._projectRootPath, projectUtils_1._subGameBundle+'.zip'), (archive.pointer() / 1024 / 1024).toFixed(2) + 'M(' + (archive.pointer() / 1024).toFixed(2) + 'KB)');
    });
}

function createVersion(step) {
    consoleUtils_1.printStep(step++, '生成' + projectUtils_1._subGameBundle + ' 版本号文件');
    var pathUrl = path.join(publish_project_1._pathPublish, 'assets', projectUtils_1._subGameBundle)
    //读取版本号
    getVersion(pathUrl).then((version) => {
        console.info("createVersion ", version)
        fs.writeFileSync(path.join(pathUrl, "version.json"), version, { encoding: 'utf-8' });
        this.zipPackage(step++)
    })
}

function getVersion(filePath) {
    return new Promise((resolve) => {
        var version
        //根据文件路径读取文件，返回文件列表
        fs.readdir(filePath, function (err, files) {
            if (err) {
                console.warn(err)
            } else {
                //遍历读取到的文件列表
                files.forEach(function (filename) {
                    if (filename.includes('index')) {
                        version = filename.replace('index.', '')
                        version = version.replace('.js', '')
                        resolve(version)
                    }
                })
            }
        })
    });

}
exports.zipPackage = zipPackage;
exports.createVersion = createVersion;
