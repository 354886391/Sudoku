# sub-game-project-creator
### 软件需求: nodejs V11.15.0

### 1.1 规范与约定
+ 命名:字段命名采用驼峰格式
+ 子游戏项目结构
  - subgame
    - adapters      配置总文件-脚本生成
    - excelData     配置表单个文件-脚本生成
    - proto         协议生成文件-脚本生成，协议的proto 文件请存放在根目录下的proto 文件夹
    - res           资源目录
    - src           代码目录

### 1.2 开发工具
+ vscode 安装`【多米插件】`, 扩展--从VSIX安装-- 选择种子项目根目录 `duomi-plugin-0.0.1.vsix`

### 1.3 新建项目
+ 使用`【多米插件】`-- 内置工具入口--新建项目  输入子项目名字也就是 `bundle` 名, 然后输入 项目前缀名(前缀名字首字母大写)，然后选择保存目录。

+ `bundle` 名使用小写，避免出现大小写错误问题。
+ 默认进入prefab名字 GameEntrance.prefab, 默认挂载代码类名 XX_GameEntrance.ts 。
+ src/common/XX_Gameconfig.ts 配置子游戏的相关信息

+ 插件会执行以下操作
  - 1 从git拉取种子项目到选择的目录下，以 输入的 `bundle` 名为项目名称
  - 2 把项目内的的 subgame 目录名字修改为 `bundle` 名字，删除  subgame.meta 文件
  - 3 初始化submodule项目 sub-game-prefix
  - 4 把 subgame.js 内配置的子游戏bundle名字改成要生成的 `bundle` 名字
  - 5 在 sub-game-prefix/SubGamePrefix.ts 内添加上 项目前缀和项目名字
  - 6 把原 subgame 目录内的所有类文件修改加上项目前缀名，并删除对应的 .meta 文件
  - 7 修改 Main.ts 内的 subgame 为设置的 `bundle` 名字

+ 生成完成之后打开creator刷新一下资源文件，之后执行 git push, 就会生成提交到git目录上，不需要手动去git上创建。

+ 如果需要修改项目前缀名，使用 `【多米插件】`-- 内置工具入口--修改子游戏前缀， 输入新的前缀名，可以批量修改带有前缀的文件名
+ 注意，修改了前缀要对应去修改`sub-game-prefix/SubGamePrefix.ts`里面设置的前缀配置

####重要:
+ 确保根目录下 subgame.js 设置 bundle 名字的正确，确保和 sub-game-prefix/SubGamePrefix.ts 里面对应的前缀配置一致
+ 这两样要保证对应正确，否则会导致配置脚本和协议脚本生成文件或目录会错误

### 1.4 初始化项目
+ 项目创建后需执行以下`【多米插件】`内的`【初始化项目】`以安装开发中的依赖项
+ 或者直接终端执行 npm install
+ 如果出现提示 found 1 high severity vulnerability
+ 直接运行 npm audit fix 就好了
+ 因为"unzip": "^0.1.11" 使用了fstream v0.1.31, 该版本目前已经升级到 1.0.12,但是 unzip还没有新版更新

+ 初始化完成之后，打开creator刷新一下文件，重新设置一下子项目内几个预置物的脚本引用

+ 生成协议时如果出现 ` cmd error: {"errno":"ENOENT","code":"ENOENT"` 错误，全局安装一下  npm install -g protobufjs@6.8.8

+ 本地开发调试时，网络配置初始化在 hlgame/adapters/Starup.ts下

+ 子游戏的运行流程   Startup.ts(初始化服务器一些信息)--> Main.ts(主场景加载)-->请求加载bundle列表信息,获取大厅版本号，设置本地子游戏bundle信息到游戏列表中
                    -->加载大厅bundle-->大厅初始化从游戏列表中加载本地子游戏bundle-->加载初始化本地游戏bundle-->运行游戏

### 1.5 表格与协议生成
+ 使用`【多米插件】`导出excel表格和生产proto信息
+ 子游戏初始化参考 PreLoading 里面的写法
+ 游戏加载的时候，要先加载游戏配置表信息，如果有的话。
+ 配置表管理类要先注册使用，使用 gea.game.register(GameConfig.bundle, ExlLoader)注册，
+ gea.game.get(ExlLoader).loadAll 加载，具体可以参考 PreLoading
+ 每一张表都会根据sheet的名字生成一个 ExlXXX.ts 名字的TS文件，里面会有表格数据，导出一个 ExlXXXXProvider 类可以获取表格数据
+ 子游戏回收时表格里面的数据会被管理类清空
+ 配置表 原始表使用excel表格方式，格式参考根目录下的 `配置表`
+ 协议  原始协议文件*.proto放置在跟目录下 `proto`

### 1.6 项目模块规范
#### 1.6.1 UI管理
+ UI界面使用 gea.ui 管理，UI类界面根据界面继承  gea.abstracts.ui.xx ,注意UI界面一定要添加，具体的UI层级关系可查看 gea.enums.ui.ui_type

```ts
    static get prefabUrl(): string {
        return 'prefab/loading/PreLoading'
    }
    /**bundle 名称 */
    static get bundle(): string {
        return GameConfig.bundle
    }
```
+ 一个是配置对应的prefab，一个是设置对应的子游戏bundle

+ 所有界面不要直接继承 cc.Component,都需要继承gea.abstracts.ui.xx 的一个界面，并且初始化时给自身设置 对应的`bundle`名,这样子游戏在回收时候才能自动回收到该界面的事件时间协议等监听。


#### 1.6.2  多语言处理
+ 多语言文本由配置表生成，图片资源放置在 res/local下，以语言标识为文件夹
+ UI 界面上的的UI类带有多语言列表设置, 静态不变的可以把多语言Label和图片加进列表里面，界面创建初始化时会自动替换对应多语言
+ 也可以直接在文本上挂载 LangTranStr脚本，图片挂载 LangTranPic 脚本
+ 动态调整或者参数拼接的多语言可以使用  gea.language.tranStringTxt
+ 动态调整的多语言图片可以使用  gea.language.tranPicTxt

#### 1.6.3 工具类
+ 事件监听使用  gea.instance
+ 时间函数使用  gea.timer
+ 缓动函数使用  gea.tween
+ 协议监听使用  gea.net
+ 音效播放  gea.audioMgr
+ 类方法管理器  gea.game
+
+ bundle在回收时会自动吧以上的监听相关移除，开发时不用做特殊处理
+ 只有使用默认的gea.ui和gea.game以及继承BaseComponent会自动带入bundle名字，才能做统一移除
+ 或者类方法定义上  public bundle:string = GameConfig.bundle

#### 1.6.4 单例类的使用
+ 子游戏开发不要使用单例类，和静态类，为方便开发，可以使用 gea.game 的类方法管理
+ 创建自己的方法类 继承 gea.interfaces.manager.IGameMgrPool
+ 用 gea.register(GameConfig.bundle, 类名, 参数信息（选填）)， 带入bundle名称是为了回收时统一管理回收。
```ts
export default class HallData extends gea.common.GameMgrPool {

    startup(): void {
        //管理类初始化时调用
    }

    callbackBeforeRestore(){
        //管理类被回收时调用
    }
}
```
+ 注册
```ts
    gea.register(this.bundle, HallData)
```
+ 使用 gea.get(类名)  可以获取到该实例后的类访问里面的方法，使用上和单例类一样
```ts
   gea.get(HallData)
```

#### 1.6.5 资源加载使用
+ 子游戏动态加载自身资源使用 gea.assetMgr.load, 资源获取接口都在 gea.assetMgr
```ts
    gea.assetMgr.setSpriteFrame   //设置加载本地图片
    gea.assetMgr.setRemoteSpriteFrame   //设置远程资源图
    gea.assetMgr.loadSkeleton       //加载spine动画
    gea.assetMgr.loadRemoteSkeleton       //加载远程spien动画资源
```
### 1.6.6 其他接口
+ hlgame.systemInfo     信息获取，可获取到手机信息，语言，设备ID，屏幕宽高等
+ gea.game.getMyUserInfo()      自身数据信息获取
+ gea.localStorage      本地缓存，存储获取存储在本地缓存的数据
+ gea.serverStorage     服务器存储，可存储一些不太重要的杂项数据到服务器
+ gea.userInfoMgr       玩家信息管理，当有好友或者有其他玩家信息时可用这个管理
+ hlgame.utils.comUtil  一些通用方法函数

#### 1.6.7 公共界面
+ 通用公共界面，由大厅那边注册的公共面板给子游戏使用
+ gea.enums.ui.common_ui 里面有对应的界面枚举、
+ 调用方式  gea.ui.openCommonUI(gea.enums.ui.common_ui.HallBottomBarPanel)

### 1.6.8 加载大厅的资源
```ts
      gea.assetMgr.load(this.bundle, 'res/font/Paytone', cc.Font, null, (err, assets: cc.Font) => {
                        this.font = assets
                        label.font = this.font
                    })
```

### 1.6.9 加载进度管理
+ 项目的preloading界面继承 公共库的 gea.abstracts.ui.PreLoadingBase
+ 游戏的主界面在初始完成后需要抛出进度完成事件
```ts
    callbackAfterShow() {
        gea.instance.dispatch(gea.events.ui.game_loading_progress, 1, gea.enums.GameLoadingType.complete)
    }
```

# 项目打包
1 执行 `【多米插件】`内的`【发布项目】`
+ .hlplugin-game/publish.hl.json  配置creator引擎的路径
+  打包会压缩所有图片资源，如果有不需要压缩的图片，请在下面文件中进行配置
+  package/publish/config.js
2 执行 `【多米插件】`内的`【一键发布上传】`
+ 会自动先执行`【发布项目】`,发布完成后会自动上传到测试服FTP目录下，并修改列表的版本信息
---
