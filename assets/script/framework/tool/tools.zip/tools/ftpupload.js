#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path = require('path');
const ftp = require('ftp');//连接FTP
const client = new ftp();
const fs = require('fs');
const http = require('http')
var projectUtils_1 = require("./utils/projectUtils");
var consoleUtils_1 = require("./utils/consoleUtils");

client.on('ready',()=>{
    console.log('ftp client is ready');
    // client.mkdir('native',false,function(){})
});
client.on('close',()=>{
    console.log('ftp client has close')
});
client.on('end',()=>{
    console.log('ftp client has end')
});
client.on('error',(err)=>{
    console.log('ftp client has an error : '+ JSON.stringify(err))
});
client.connect({
    host : '192.168.99.106',//
    port : '21',
    user : 'client666',
    password : 'daxiong1',
    keepalive : 1000
});
//列出目标目录
async function list(dirpath){
    let {err : ea,dir } = await cwd(dirpath);
    return new Promise((resolve,reject)=>{
        client.list((err,files)=>{
            resolve({err : err,files : files})
        })
    });
}
//切换目录
function cwd(dirpath){
    return new Promise((resolve,reject)=>{
        client.cwd(dirpath,(err,dir)=>{
            resolve({err : err,dir : dir});
        })
    });
}
//创建目录
async function mkdir(dirpath){
    return new Promise((resolve,reject)=>{
        client.mkdir(dirpath,(err,dir)=>{
            resolve({err : err,dir : dir});
        })
    });
}
//获取目录
async function getPath(dirpath){
    return new Promise((resolve,reject)=>{
        client.get(dirpath,(err)=>{
            resolve({err : err});
        })
    });
}
//下载文件
async function get(filePath){
    const dirpath = path.dirname(filePath);
    // const fileName = path.join(__dirname, path.basename(filePath));
    const fileName = path.basename(filePath);
    console.info(fileName)
    let {err : ea,dir} = await cwd(dirpath);
    return new Promise((resolve,reject)=>{
        client.get(fileName,(err,rs)=>{
            let ws = fs.createWriteStream(path.join('temp',fileName));
            rs.pipe(ws);
            rs.once('close', function(){
                resolve({err : err});
            });
        });
    });
}
//将文件上传到ftp目标地址
async function put(currentFile,targetFilePath){
    targetFilePath = targetFilePath.replace(/\\/g, '/')
    const dirpath = path.dirname(targetFilePath) + '/';
    const fileName = targetFilePath//path.basename(targetFilePath);

    const rs = fs.createReadStream(currentFile);

    return new Promise((resolve,reject)=>{
        client.put(rs,fileName,(err)=>{
            resolve({err : err});
        })
    });
}

async function checkPath(dirpath){
    dirpath = dirpath.replace(/\\/g,'/')
    // let {err : ea} = await getPath(dirpath)
    // if(!ea){
    //     console.log(dirpath , '已存在');
    //     return Promise.resolve({err : ea});
    // }
    let {err : ea2} = await mkdir(dirpath)
    if(ea2){
        return;
    }
    return Promise.resolve({err : ea2});
}

async function getVersion (filePath){
    return new Promise((resolve)=>{
        var version
        //根据文件路径读取文件，返回文件列表
        fs.readdir(filePath, function (err, files) {
            if (err) {
                console.warn(err)
            } else {
                //遍历读取到的文件列表
                files.forEach(function (filename) {
                    if(filename.includes('index')){
                        version = filename.replace('index.','')
                        version = version.replace('.js','')
                        resolve(version)
                    }
                })
            }
        })
    });

}

var uploadFiles = []
var filesLen  = 0
var uploadPath = 'www/igh5/'
var uploadPathApp = 'www/igapp/'
var appVersionPath = '/www/igapp/gameversion.json'
var h5VersionPath = '/www/igh5/gameversion.json'
var version
var step = 1
//统计并提前创建目录
async function calculationFile (filePath,onComplete){
    var files = fs.readdirSync(filePath)
    filesLen += files.length
    //遍历读取到的文件列表
    files.forEach(async function (filename) {
        //获取当前文件的绝对路径
        var filedir = path.join(filePath, filename);

        //根据文件路径获取文件信息，返回一个fs.Stats对象
        // fs.stat(filedir, async function (eror, stats) {
        await filestat(filedir).then(async (stats)=>{
            if (!stats) {
                console.warn('获取文件stats失败 ' + filedir);
            } else {
                var isFile = stats.isFile();//是文件
                var isDir = stats.isDirectory();//是文件夹
                if(isDir){
                    await calculationFile(filedir,onComplete)
                    let ftpPath = path.join(uploadPath, filedir.replace(path.join(projectUtils_1._projectRootPath,'/web-mobile/assets'),''),'/')
                    await checkPath(ftpPath)
                    let ftpPath2 = path.join(uploadPathApp, filedir.replace(path.join(projectUtils_1._projectRootPath,'/web-mobile/assets'),''),'/')
                    await checkPath(ftpPath2)
                    filesLen--
                }else if(isFile){
                    uploadFiles.push(filedir)
                    filesLen--
                    // console.info(filedir)
                }
                if(filesLen<=0){
                    if(onComplete){
                        onComplete()
                    }
                }
            }
        })
    })

    return filesLen
}


async function filestat(path) {
    // console.info(path)
    return new Promise((resolve, reject) => {
      fs.stat(path, function (err, stats) {
        resolve(stats );
      });
    });
  };


async function uploadbundle (){
    console.log(consoleUtils_1.formatConsole([`${step++}. 开始版本上传。 `], 'yellow'));
    var filePath = path.join(projectUtils_1._projectRootPath,'/web-mobile/assets', projectUtils_1._subGameBundle)

    //读取版本号
    version = await getVersion(filePath)
    if (!version){
        return
    }
    console.log(consoleUtils_1.formatConsole([`${step++}. 版本号读取成功 ${version} `], 'yellow'));

    //尝试创建子游戏目录
    await checkPath(path.join(uploadPath, projectUtils_1._subGameBundle, '/'))
    await checkPath(path.join(uploadPathApp, projectUtils_1._subGameBundle, '/'))

    //统计上传文件
    await calculationFile(filePath, async ()=>{
        console.log(consoleUtils_1.formatConsole([`${step++}. ftp目录创建完成，文件数量统计完成，总共 ${uploadFiles.length} 个文件  `], 'yellow'));

        let num = 0
        if(uploadFiles && uploadFiles.length>0){
            console.log(consoleUtils_1.formatConsole([`${step++}. 开始上传包内容  `], 'yellow'));
            for (let i = 0; i < uploadFiles.length ; i++) {
                let upPath = uploadFiles[i]
                let tagPath = uploadFiles[i].replace(filePath, projectUtils_1._subGameBundle)
                let {err : eb} = await put(upPath, path.join(uploadPath,tagPath));
                if(eb){
                    console.log('put ',eb);
                }else{
                    num++
                    // console.log('文件上传成功')
                    console.log(consoleUtils_1.formatConsole([`[${i + 1}/${uploadFiles.length}] ${tagPath}`], 'green'));
                }
                await put(upPath, path.join(uploadPathApp,tagPath));
            }
            //上传zip
            let upPath = path.join(projectUtils_1._projectRootPath, projectUtils_1._subGameBundle + ".zip")
            let tagPath = path.join(projectUtils_1._subGameBundle, projectUtils_1._subGameBundle + ".zip")
            let { err: eb } = await put(upPath, path.join(uploadPath, tagPath));
            let { err: eb2 } = await put(upPath, path.join(uploadPathApp, tagPath));
            let { err: eb3 } = await put(upPath, path.join(uploadPathApp, "zip", projectUtils_1._subGameBundle + ".zip"));
        }
        console.log(consoleUtils_1.formatConsole([`${step++}. 共 ${uploadFiles.length} 个文件，成功上传${num}个， 失败${uploadFiles.length - num}`], 'yellow'));
        await modifyVersion()
    })
}

async function httpModifyVersion() {
    if (!projectUtils_1._gameId) {
        console.log(consoleUtils_1.formatConsole([`${step++}. subgame.js 没有配置 _gameId 变量 ,请先配置！！`], 'red'));
        endClose()
        return
    }

    console.log(consoleUtils_1.formatConsole([`${step++}. 开始修改版本号。  ${version}`], 'yellow'));
    http.get(`http://192.168.99.106:8200/system/game/modifyVersion?gameId=${projectUtils_1._gameId}&version=${version}`, res => {
        console.log(consoleUtils_1.formatConsole([`${step++}. 106H5 版本号修改成功！。`], 'yellow'));
        endClose()
    }).on('error', err => {
        console.log('Error: ', err.message);
        endClose()
    });

    http.get(`http://192.168.99.108:8200/system/game/modifyVersion?gameId=${projectUtils_1._gameId}&version=${version}`, res => {
        console.log(consoleUtils_1.formatConsole([`${step++}. 108APP 版本号修改成功！。 `], 'yellow'));
        endClose()
    }).on('error', err => {
        console.log('Error: ', err.message);
        endClose()
    });
}


async function modifyVersion(){
        //下载文件 bundleconfig
    let {err : ea} = await get(appVersionPath)
    if(ea){
        console.log(ea);
        return;
    }
    console.log(consoleUtils_1.formatConsole([`${step++}. gameversion.json 下载成功。`], 'yellow'));

    console.log(consoleUtils_1.formatConsole([`${step++}. 子游戏 ${projectUtils_1._subGameBundle}  版本号: [${version}] ,开始修改配置版本号。`], 'yellow'));
    var jsonPath = path.join(__dirname,'../temp/gameversion.json')

    var cfgContent = fs.readFileSync(jsonPath, { encoding: 'utf-8' })
    var cfgObj = JSON.parse(cfgContent)

    if(!cfgObj){
        cfgObj = {}
    }

    cfgObj[projectUtils_1._subGameBundle] = version

    if(cfgObj){
        fs.writeFileSync(jsonPath, JSON.stringify(cfgObj), { encoding: 'utf-8' });
        let {err : eb} = await put(jsonPath, appVersionPath);
        if(eb){
            console.log(eb);
            return;
        }
        console.log(consoleUtils_1.formatConsole([`${step++}. APP gameversion修改上传成功。`], 'yellow'));

        fs.writeFileSync(jsonPath, JSON.stringify(cfgObj), { encoding: 'utf-8' });
        let {err : eb2} = await put(jsonPath, h5VersionPath);
        if(eb2){
            console.log(eb2);
            return;
        }
        console.log(consoleUtils_1.formatConsole([`${step++}. H5 gameversion修改上传成功。`], 'yellow'));
        endClose()
    }else{
        console.log(consoleUtils_1.formatConsole([`${step++}. gameversion 配置中没有游戏配置，请先添加！`], 'red'));
    }
}

function endClose(){
    //关闭之前删除本地版本文件
    fs.unlink('temp/gameversion.json',(err)=>{
        if(!err){
            console.info("gameversion  delete")
        }
    })
    client.end()
}

if (process.argv[1] === __filename) {
    console.info(__filename)
    //先删除本地版本文件
    fs.unlink('temp/gameversion.json',(err)=>{
        if(!err){
            console.info("gameversion  delete")
        }
    })
    uploadbundle();
}
