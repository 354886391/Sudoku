#!/usr/bin/env node
"use strict";
var uuidUtils = require('./uuidUtils')
const fs = require('fs');
function reFileUUid() {
    client.end()
}


if (process.argv[1] === __filename) {
    console.info(process.argv[2])
    var filedir = process.argv[2]
    if (fs.existsSync(filedir)) {
        var content = fs.readFileSync(filedir, 'utf-8');
        var json = JSON.parse(content)
        if (json) {
            content = content.replace(json.uuid, uuidUtils.uuidv1());
        }
        fs.writeFileSync(filedir, content, { encoding: 'utf-8' });
    }
}

