"use strict";
var path = require("path");
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
if (process.argv[1] === __filename) {
    renamePrefix(path.join(__dirname, 'png'))
    console.info(path.join(__dirname, 'png'))
}


function renamePrefix(filePath, prefix, isDeep = false) {

    console.info(filePath + " " + prefix);
    var index = 0
    //根据文件路径读取文件，返回文件列表
    fs.readdir(filePath, function (err, files) {
        if (err) {
            console.warn(err)
        } else {
            //遍历读取到的文件列表
            files.forEach(function (filename) {
                //获取当前文件的绝对路径
                var filedir = path.join(filePath, filename);
                // console.info(filedir)
                //根据文件路径获取文件信息，返回一个fs.Stats对象
                fs.stat(filedir, function (eror, stats) {
                    if (eror) {
                        console.warn('获取文件stats失败 ' + filedir);
                    } else {
                        var isFile = stats.isFile();//是文件
                        var isDir = stats.isDirectory();//是文件夹
                        if (isFile) {
                            var newName = filename.replace(" ", "")
                            newName = newName.replace("(", "")
                            newName = newName.replace(")", "")
                            console.info(newName)
                            fs.rename(filePath + "/" + filename, filePath + "/" + "new/" + newName, (err) => {
                                if (err) throw err;
                                console.info('成功')
                            })
                            // index = index + 1
                        }
                    }
                })
            });
        }
    });
}
