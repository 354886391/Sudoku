/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 10:24:42
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2023-01-14 16:16:14
 * @Description: 这里写你类描述
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
var path = require("path");
var CmdUtils_1 = require("../utils/CmdUtils");
var projectUtils_1 = require("../utils/projectUtils");
var pbenumName = projectUtils_1._subGamePrefix + "PBEnums"
var PBEnumsGenerater_1 = require("./PBEnumsGenerater");
var ProtoParser_1 = require("./ProtoParser");
var FileUtils_1 = require("../utils/FileUtils");
var _dir_proto = path.join(projectUtils_1._projectRootPath, 'proto');
var _dir_proto_temp = path.join(projectUtils_1._projectRootPath, 'temp', 'proto');
var _dir_pb;
var mapProtoInfo = ProtoParser_1.parseProto(_dir_proto);
//删除temp下的临时文件
if (fs.existsSync(_dir_proto_temp)) {
    FileUtils_1.rmFile(_dir_proto_temp);
}
if (mapProtoInfo != null) {
    console.log('生成' + pbenumName + '.ts...');
    switch (projectUtils_1._projectType) {
        case 'creator':
            _dir_pb = path.join(projectUtils_1._projectRootPath, 'assets',projectUtils_1._subGameBundle,'proto');
            PBEnumsGenerater_1.generatePBEnums(mapProtoInfo, path.join(projectUtils_1._projectRootPath, 'assets',projectUtils_1._subGameBundle,'proto/' + pbenumName + '.ts'), pbenumName);
            break;
    }
    console.log('生成pb.js,pb.d.ts');
    var pbTarget = projectUtils_1._projectType === 'laya' ? 'es6' : 'commonjs';
    if (!fs.existsSync(path.join(projectUtils_1._projectRootPath, 'temp'))) {
        fs.mkdirSync(path.join(projectUtils_1._projectRootPath, 'temp'));
    }
    if (!fs.existsSync(_dir_proto_temp)) {
        fs.mkdirSync(_dir_proto_temp);
    }
    fs.readdirSync(_dir_proto).forEach(function (fileName) {
        var filePath = path.join(_dir_proto, fileName);
        var pbjsContent = fs.readFileSync(filePath, { encoding: 'utf-8' });
        if (fileName !== 'gateway.proto') {
            pbjsContent = pbjsContent.replace(/\_(\w)/g, function (all, letter) {
                return letter.toUpperCase();
            });
        }
        var fileNewPath = path.join(_dir_proto_temp, fileName);
        fs.writeFileSync("" + fileNewPath, pbjsContent, { encoding: 'utf-8' });
        console.log(fileNewPath);
    });
    var pbName = "/" + projectUtils_1._subGamePrefix + "pb.js"
    var pdDName = "/"+ projectUtils_1._subGamePrefix +"pb.d.ts"
    CmdUtils_1.cmd("pbjs" + (process.platform === 'win32' ? '.cmd' : '') + " --keep-case --force-number --no-convert --no-delimited --no-verify -r protobuf -t static-module -w " + pbTarget + " -o " + _dir_pb + pbName + " " + _dir_proto_temp + "/*.proto", "pbts" + (process.platform === 'win32' ? '.cmd' : '') + " -o " + _dir_pb + pdDName + " " + _dir_pb + pbName, function () {
            var pbjsContent = fs.readFileSync(_dir_pb + pbName, { encoding: 'utf-8' })
            pbjsContent = pbjsContent.replace(/pb \=/g, ''+projectUtils_1._subGamePrefix+'pb =');
            pbjsContent = pbjsContent.replace(/pb\./g, ''+projectUtils_1._subGamePrefix+'pb.');
            pbjsContent = pbjsContent.replace(/return pb/g, 'return '+projectUtils_1._subGamePrefix +'pb');
            pbjsContent = pbjsContent.replace(/require\(/, "gea.net.protobufjs || require(");
            fs.writeFileSync(_dir_pb + pbName, pbjsContent, { encoding: 'utf-8' });

            var pbdjsContent = fs.readFileSync(_dir_pb + pdDName, { encoding: 'utf-8' })
            pbdjsContent = pbdjsContent.replace(/pb\./g, ''+projectUtils_1._subGamePrefix+'pb.');
            pbdjsContent = pbdjsContent.replace(/namespace pb/g, 'namespace '+projectUtils_1._subGamePrefix+'pb');
            fs.writeFileSync(_dir_pb + pdDName, pbdjsContent, { encoding: 'utf-8' });
    });
}
