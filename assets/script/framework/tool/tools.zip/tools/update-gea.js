/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2022-12-15 10:24:42
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2023-10-10 12:06:34
 * @Description: 这里写你类描述
 */
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var path = require("path");
var CmdUtils_1 = require("./utils/CmdUtils");
var FileUtils_1 = require("./utils/FileUtils");
var projectUtils_1 = require("./utils/projectUtils");
var tmpDir = path.join(__dirname, '../tmpForUpdate').replace(/\\/g, '/');
function update() {
    FileUtils_1.rmFile(tmpDir);
    CmdUtils_1.cmd("git clone https://192.168.99.100/game/gea-libs.git " + tmpDir, function () {
        switch (projectUtils_1._projectType) {
            case 'creator':
                updateCreator();
                break;
            default:
                console.error(projectUtils_1._projectType + ' is undefinded');
                break;
        }
        FileUtils_1.rmFile(tmpDir);
    });
}
function updateCreator() {
    var fileRelativePathes = [0,1,2]
    var fileFrom = [
        'gea-hlgame-creator.min.js',
        'gea-hlgame-creator.min.js.map',
        'gea-hlgame-creator.d.ts',
    ];

    var fileTo = [
        'assets/hlgame/libs/gea-hlgame-creator.min.js',
        'assets/hlgame/libs/gea-hlgame-creator.min.js.map',
        'gea-hlgame-creator.d.ts',
    ];
    var root = path.join(__dirname, '..');
    fileRelativePathes.forEach(function (file) {
        FileUtils_1.copyFile(path.join(tmpDir, fileFrom[file]), path.join(root, fileTo[file]));
    });
}
if (process.argv[1] === __filename) {
    update();
}
