#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CmdUtils_1 = require("./utils/CmdUtils");
function initProject() {
    CmdUtils_1.cmd('npm install', 'npm install -g protobufjs@6.8.8', 'git config --global core.autocrlf false');
    CmdUtils_1.cmd('npm install ftp','npm install node-uuid');
    CmdUtils_1.cmd('git submodule init','git submodule update');
}
if (process.argv[1] === __filename) {
    initProject();
}
