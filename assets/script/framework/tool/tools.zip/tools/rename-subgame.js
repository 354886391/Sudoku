/*
 * @Author: dx lzx0513@qq.com
 * @Date: 2023-01-12 17:07:28
 * @LastEditors: dx lzx0513@qq.com
 * @Email: lzx0513@qq.com
 * @LastEditTime: 2023-01-13 18:42:34
 * @Description: 这里写你类描述
 */
"use strict";
var path = require("path");
Object.defineProperty(exports, "__esModule", { value: true });

var FileUtils_1 = require("./utils/FileUtils");

if (process.argv[1] === __filename) {
    // update();
    console.info(process.argv[2], process.argv[3])
    let PrefixName = process.argv[2]
    if (PrefixName) {
        PrefixName = PrefixName.slice(0, 1).toUpperCase() + PrefixName.slice(1);
    }
    FileUtils_1.renamePrefix(path.join(__dirname, '../assets'), PrefixName, false)
}
